# -*- coding: utf-8 -*-
'''
Selfbot Edition

Special Thanks to:
 • IYUS_SELF TCR™
 • Team SELF TCR™

Supported By:
 • Team SELF TCR™
 • T-C-R Squad

©2020 Recode By IYUS_SELF TCR™
'''
from important import *
import youtube_dl
import requests
import humanize
import html5lib
from gtts import gTTS
from bs4 import BeautifulSoup
import requests, json
import urllib, urllib3, urllib.parse
from thrift import transport, protocol, server
from thrift.Thrift import *
from thrift.TMultiplexedProcessor import *
from thrift.TSerialization import *
from thrift.TRecursive import *
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from Naked.toolshed.shell import execute_js
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup as bSoup
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from tmp.AdityaSplitGood import AdityaSplitGood
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import platform
import livejson
import requests, json
from BEAPI import *
parser = argparse.ArgumentParser(description='Selfbot')
parser.add_argument('-t', '--token', type=str, metavar='', required=False, help='Token | Example : Exxxx')
parser.add_argument('-e', '--email', type=str, default='', metavar='', required=False, help='Email Address | Example : example@xxx.xx')
parser.add_argument('-p', '--passwd', type=str, default='', metavar='', required=False, help='Password | Example : xxxx')
parser.add_argument('-a', '--apptype', type=str, default='', metavar='', required=False, choices=list(ApplicationType._NAMES_TO_VALUES), help='Application Type | Example : CHROMEOS')
parser.add_argument('-s', '--systemname', type=str, default='', metavar='', required=False, help='System Name | Example : Chrome_OS')
parser.add_argument('-c', '--channelid', type=str, default='', metavar='', required=False, help='Channel ID | Example : 1341209950')
parser.add_argument('-T', '--traceback', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Using Traceback | Use : True/False')
parser.add_argument('-S', '--showqr', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Show QR | Use : True/False')
args = parser.parse_args()
listAppType = ['DESKTOPWIN', 'DESKTOPMAC', 'IOSIPAD', 'CHROMEOS']

#=======================================================================================================================
settings = livejson.File('setting.json', True, False, 4)
email = settings["email"]
password = settings["password"]
programStart = time.time()
line = LINE(email,password)
myMid = line.profile.mid
myProfile = line.getProfile()
oepoll = OEPoll(line)
with open('image.json', 'r') as fp:
    image = json.load(fp)
status = livejson.File('statuss.json', True, False, 4)
Creator = status["creator"] #INPUT MID IN STATUS.JSON
#=======================================================================================================================
tmp_text = []
protectinvite = []
protectkick = []
protectjoin = []
protectqr = []
protectcancel = []
lurking = {}
readers = {}
#ban = livejson.File('blacklist.json', True, False, 4)
silent = livejson.File('silent.json', True, False, 4)
tagmeOpen = codecs.open("tag.json","r","utf-8")
tagme = json.load(tagmeOpen)
sname1 = line.getProfile().displayName
lastseen = ({
    "find": {},
    "username": {}
})
cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
flagPict = {
    "status": False
}
wait = {
    "limit": 1,
    "Images": {
        "anu": ""
    },
    "ChangeGDP": False,
    "setkey": "",
    "wblacklist": False,
    "dblacklist": False,
    "selfbot": True,
    "notifcall": False,
    "wwhitelist": False,
    "dwhitelist": False,
    "wteam": False,
    "Mentiongift": False,
    "Timeline": False,
    "dteam": False,
}
apalo = {
    "tban": [],
    "tbanc": False,
    "tunbanc": False,
    "talkban": True,
}
liffV1 = {
    "arLiff": True
}
mckontol = {
    "mckontol": True
}
joinpurge = {
    "purgee": False,
    "purgebl": True,
}
ProfileMe = {
    "coverId": "",
    "statusMessage": "",
    "PictureMe": "",
    "NameMe": "",
}
seni = {
    "temp1": False,
    "temp2": False,
    "cleave": "bye",
    "ckill": "kill",
    "cinv": "sini",
    "dtiktok": False,
    "dinsta": False,
    "footer": False
}
bool_dict = {
    True: ['Yes', 'Active', 'Success', 'Open', 'On'],
    False: ['No', 'Not Active', 'Failed', 'Close', 'Off']
}
dataTemp = {
    "pict": "https://i.ibb.co/fq886wR/TEAMGMAIL.jpg"
}
nukemode = {
    "java": False,
    "kickstk": False,
    "invitestk": False,
    "kickID": "",
    "kickVER": "",
    "kckgID": "",
    "invID": "",
    "invVER": "",
    "invtID": ""
}
sygmude = {
    "fakemention": False,
    "addfakemention": False,
    "cmdfakemention": False,
    "cabutstk": False,
    "leavestk": False,
    "fstkID": "",
    "fstkVER": "",
    "fpkgID": "",
    "cmdID": "",
    "cmdVER": "",
    "cmddID": "",
    "cbtID": "",
    "cbtVER": "",
    "cabsID": "",
}
mmin = {
    "fakemention7": "haii",
    "fakemention13": "p",
    "fakementionc": "u9b6db671badc05e225fd489e0a72a3e3",
    "addfakementionc": False,
    "cmention": False
}
profile = line.getContact(myMid)
settings['myProfile']['displayName'] = profile.displayName
settings['myProfile']['statusMessage'] = profile.statusMessage
settings['myProfile']['pictureStatus'] = profile.pictureStatus
coverId = line.profileDetail['result']['objectId']
settings['myProfile']['coverId'] = coverId
ProfileMe["statusMessage"] = myProfile.statusMessage
ProfileMe["pictureStatus"] = myProfile.pictureStatus
coverId = line.getProfileDetail()["result"]["objectId"]
ProfileMe["coverId"] = coverId
#settings['changeTempPicture']['pictureStatus'] = images
if not settings:
    print ('##----- LOAD DEFAULT JSON -----##')
    try:
        default_settings = line.server.getJson('https://17hosting.id/default.json')
        settings.update(default_settings)
        print ('##----- LOAD DEFAULT JSON (Success) -----##')
    except Exception:
        print ('##----- LOAD DEFAULT JSON (Failed) -----##')
def restartProgram():
    print ('##----- PROGRAM RESTARTED -----##')
    python = sys.executable
    os.execl(python, python, *sys.argv)
def logError(error, write=True):
    errid = str(random.randint(100, 999))
    filee = open('tmp/errors/%s.txt'%errid, 'w') if write else None
    if args.traceback: traceback.print_tb(error.__traceback__)
    if write:
        traceback.print_tb(error.__traceback__, file=filee)
        filee.close()
        with open('errorLog.txt', 'a') as e:
            e.write('\n%s : %s'%(errid, str(error)))
    print ('++ Error : {error}'.format(error=error))
def command(text):
    pesan = text.lower()
    if settings['setKey']['status']:
        if pesan.startswith(settings['setKey']['key']):
            cmd = pesan.replace(settings['setKey']['key'],'')
        else:
            cmd = 'Undefined command'
    else:
        cmd = text.lower()
    return cmd
def genImageB64(path):
    with open(path, 'rb') as img_file:
        encode_str = img_file.read()
        b64img = base64.b64encode(encode_str)
        return b64img.decode('utf-8')
#=====================================================
def youtubeMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output mude.mp3 {}'.format(link))
    try:
        line.sendAudio(to, 'mude.mp3')
        time.sleep(2)
        os.remove('mude.mp3')
    except Exception as e:
        line.sendMessage(to, "Error")
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output mude.mp4 {}'.format(link))
    try:
        line.sendVideo(to, "mude.mp4")
        time.sleep(2)
        os.remove('mude.mp4')
    except Exception as e:
        line.sendMessage(to, "Error")
def sendSticker(to, mid, sver, spkg, sid):
    contentMetadata = {
        'MSG_SENDER_NAME': line.getContact(myMid).displayName,
        'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + line.getContact(myMid).pictureStatus,
        'STKVER': sver,
        'STKPKGID': spkg,
        'STKID': sid
    }
    line.sendMessage(to, '', contentMetadata, 7)
#=====================================================
def allowLiff3(): #LIFF TROJAN
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1638870522',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def allowLiff2(): #LIFF EATER
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1586794970',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)         
def allowLiff(): #LIFF AR
    url = 'https://access.line.me/dialog/api/permissions'
    data = {
        'on': [
            'P',
            'CM'
        ],
        'off': []
    }
    headers = {
        'X-Line-Access': line.authToken,
        'X-Line-Application': line.server.APP_NAME,
        'X-Line-ChannelId': '1602687308',
        'Content-Type': 'application/json'
    }
    requests.post(url, json=data, headers=headers)
def sendTemplate(to, data):
    allowLiff()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    if liffV1["arLiff"]: view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    else: view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
    
def sendTemplate3(to, data):
    allowLiff3()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1638870522-PnjreV13', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate2(to, data):
    allowLiff2()
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1586794970-VKzbNLP7', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)
def changeProfileVideo(to):
	if settings['changeProfileVideo']['picture'] == None:
		return line.sendReplyMessage(msg.id, to,"「 Picture Not Found♪ 」")
	elif settings['changeProfileVideo']['video'] == None:
		return line.sendReplyMessage(msg.id, to,"「 Video Not Found♪ 」")
	else:
		path = settings['changeProfileVideo']['video']
		files = {'file': open(path, 'rb')}
		obs_params = line.genOBSParams({'oid': line.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
		data = {'params': obs_params}
		r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
		if r_vp.status_code != 201:
			return line.sendMessage(to,"「 Fail Update Profile♪ 」")
		path_p = settings['changeProfileVideo']['picture']
		settings['changeProfileVideo']['status'] = False
		line.updateProfilePicture(path_p, 'vp')
def changevideopp(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = line.genOBSParams({'oid': myMid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'Hello_World.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        line.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))
def fancy1(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = 'ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖqʳˢᵗᵘᵛʷˣʸᶻ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy2(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy3(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝖆𝖇𝖈𝖉𝖊𝖋𝖌𝖍𝖎𝖏𝖐𝖑𝖒𝖓𝖔𝖕𝖖𝖗𝖘𝖙𝖚𝖛𝖜𝖝𝖞𝖟'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy4(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝓪𝓫𝓬𝓭𝓮𝓯𝓰𝓱𝓲𝓳𝓴𝓵𝓶𝓷𝓸𝓹𝓺𝓻𝓼𝓽𝓾𝓿𝔀𝔁𝔂𝔃'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy5(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy6(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy7(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '🄰🄱🄲🄳🄴🄵🄶🄷🄸🄹🄺🄻🄼🄽🄾🄿🅀🅁🅂🅃🅄🅅🅆🅇🅈🅉'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy8(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy9(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝐚𝐛𝐜𝐝𝐞𝐟𝐠??𝐢𝐣𝐤𝐥??𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy10(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝙖𝙗𝙘𝙙𝙚𝙛𝙜𝙝𝙞𝙟𝙠𝙡𝙢𝙣𝙤𝙥𝙦𝙧𝙨𝙩𝙪𝙫𝙬𝙭𝙮𝙯'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy11(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝒶𝒷𝒸𝒹𝑒𝒻𝑔𝒽𝒾𝒿𝓀𝓁𝓂𝓃❤𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy12(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = 'ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy13(to, text):
    normal = 'zyxwvutsrqponmlkjihgfedcba'
    tochange = 'ƹʏxwvuƚꙅɿpqoᴎm|ʞꞁiʜǫᎸɘbɔdɒ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy14(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = 'ᎪᏴᏟᎠᎬҒᏀᎻᏆᎫᏦᏞᎷΝϴᏢϘᎡՏͲႮᏙᏔХᎽᏃ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy15(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy16(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = 'ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘϙʀsᴛᴜᴠᴡxʏᴢ'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy17(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝙖𝙗𝙘𝙙𝙚𝙛𝙜𝙝𝙞𝙟𝙠𝙡𝙢𝙣𝙤𝙥𝙦𝙧𝙨𝙩𝙪𝙫𝙬𝙭𝙮𝙯'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy18(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝘼𝘽𝘾𝘿𝙀𝙁𝙂𝙃𝙄𝙅𝙆𝙇𝙈𝙉𝙊𝙋𝙌𝙍𝙎𝙏𝙐𝙑𝙒𝙓𝙔𝙕'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy19(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲??'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy20(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy21(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)

def fancy22(to, text):
    normal = 'abcdefghijklmnopqrstuvwxyz'
    tochange = '𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻'
    for i in range(len(normal)):
        text = text.lower().replace(normal[i], tochange[i])
    line.sendMessage(to, text)
def genUrlB64(url):
    return base64.b64encode(url.encode('utf-8')).decode('utf-8')
def removeCmd2(cmd, text):
	key = settings['setKey']['key']
	if settings['setKey']['status'] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def removeCmd(text, key=''):
    if key == '':
        setKey = '' if not settings['setKey']['status'] else settings['setKey']['key']
    else:
        setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(' ')
    return text_[len(sep[0] + ' '):]
def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False
def replaceAll(text, dic):
    try:
        rep_this = dic.items()
    except:
        rep_this = dic.iteritems()
    for i, j in rep_this:
        text = text.replace(i, j)
    return text
def help():
    key = '' if not settings['setKey']['status'] else settings['setKey']['key']
    with open('help.txt', 'r') as f:
        text = f.read()
    helpMsg = text.format(key=key.title())
    return helpMsg
def til():
    if settings['setKey']['status'] == True:
        key = settings['setKey']['key']
    else:
        key = ''
    helpLoh =  "Type: Help Group♪"
    helpLoh +=  "\n	 › " + key + "ginfo"
    helpLoh +=  "\n	 › " + key + "glist"
    helpLoh +=  "\n	 › " + key + "team"
    helpLoh +=  "\n	 › " + key + "invlist"
    helpLoh +=  "\n	 › " + key + "%s「 Mention 」" % settings["changekick"]
    helpLoh +=  "\n	 › " + key + "%s「 Mention 」" % settings["changeinvite"]
    helpLoh +=  "\n	 › " + key + "%s「 Reply 」" % settings["changekickr"]
    helpLoh +=  "\n	 › " + key + "%s「 Reply 」" % settings["changeinvites"]
    helpLoh +=  "\n	 › " + key + "openqr"
    helpLoh +=  "\n	 › " + key + "closeqr"
    helpLoh +=  "\n	 › " + key + "memberlist"
    helpLoh +=  "\n	 › " + key + "pendinglist"
    helpLoh +=  "\n	 › " + key + "blocklist"
    helpLoh +=  "\n	 › " + key + "bl"
    helpLoh +=  "\n	 › " + key + "wl"
    helpLoh +=  "\n	 › " + key + "addwl「 Mention 」"
    helpLoh +=  "\n	 › " + key + "addbl「 Mention 」"
    helpLoh +=  "\n	 › " + key + "Purge on「 autokick blacklist 」"
    helpLoh +=  "\n	 › " + key + "set pro"
    helpLoh +=  "\n	 › " + key + "list pro"
    helpLoh +=  "\n	 › " + key + "changegroupname「 Name 」"
    helpLoh +=  "\n	 › " + key + "changegrouppict"
    helpLoh +=  "\n	 › " + key + "lastseen「 Mention 」"
    helpLoh +=  "\n	 › " + key + "find「 Mention 」"
    helpLoh +=  "\n	 › " + key + "%s「 Tagallmember 」" % settings["changetagall"]
    helpLoh +=  "\n	 › " + key + "lurk"
    helpLoh +=  "\n	 › " + key + "greet"
    helpLoh +=  "\n	 › " + key + "cek mention"
    helpLoh +=  "\n	 › " + key + "clear mention"
    helpLoh +=  "\n	 › " + key + "mentionnote"
    return helpLoh
def setting():
    key = '' if not settings['setKey']['status'] else settings['setKey']['key']
    with open('setting.txt', 'r') as f:
        text = f.read()
    settingMsg = text.format(key=key.title())
    return settingMsg
def help():
    if settings['setKey']['status'] == True:
        key = settings['setKey']['key']
    else:
        key = ''
    helpMsg =  "• Type: Help Command♪"
    helpMsg +=  "\n	 › " + key + "Profile"
    helpMsg +=  "\n	 › " + key + "Group"
    helpMsg +=  "\n	 › " + key + "Steal"
    helpMsg +=  "\n	 › " + key + "Remote"
    helpMsg +=  "\n	 › " + key + "Kicked"
    helpMsg +=  "\n	 › " + key + "Js"
    helpMsg +=  "\n	 › " + key + "Spam"
    helpMsg +=  "\n	 › " + key + "Setting"
    helpMsg +=  "\n	 › " + key + "Status"
    helpMsg +=  "\n	 › " + key + "Self"
    helpMsg +=  "\n	 › " + key + "Speed"
    helpMsg +=  "\n	 › " + key + "Runtime"
    helpMsg +=  "\n	 › " + key + "Custom"
    helpMsg +=  "\n	 › " + key + "Error"
    helpMsg +=  "\n	 › " + key + "Broadcast"
    helpMsg +=  "\n	 › " + key + "Friendlist"
    helpMsg +=  "\n	 › " + key + "Feature"
    helpMsg +=  "\n	 › " + key + "Mode"
    helpMsg +=  "\n	 › " + key + "List Silent"
    return helpMsg
def betak():
    if settings['setKey']['status'] == True:
        key = settings['setKey']['key']
    else:
        key = ''
    helpMsg =  "• Type: Help Steal♪"
    helpMsg +=  "\n	 › " + key + "Getpict「 Mention 」"
    helpMsg +=  "\n	 › " + key + "Getcover「 Mention 」"
    helpMsg +=  "\n	 › " + key + "Getvideo「 Mention 」"
    helpMsg +=  "\n	 › " + key + "Getmid「 Mention 」"
    helpMsg +=  "\n	 › " + key + "Getbio「 Mention 」"
    helpMsg +=  "\n	 › " + key + "Getname「 Mention 」"
    helpMsg +=  "\n	 › " + key + "bio「@/Reply」"
    helpMsg +=  "\n	 › " + key + "cover「@/Reply」"
    helpMsg +=  "\n	 › " + key + "pict「@/Reply」"
    helpMsg +=  "\n	 › " + key + "name「@/Reply」"
    return helpMsg
def js():
    if settings['setKey']['status'] == True:
        key = settings['setKey']['key']
    else:
        key = ''
    helpJS =  "Type: JS♪"
    helpJS +=  "\n	 › " + key + "%s「 Bypass 」" % settings["changebypass"]
    helpJS +=  "\n	 › " + key + "%s「 Kickall 」" % settings["changekickall"]
    helpJS +=  "\n	 › " + key + "%s「 Cancelall 」" % settings["changecancelall"]
    helpJS +=  "\nType: Remote Js♪"
    helpJS +=  "\n	 › " + key + "meluncur:「 Num 」"
    helpJS +=  "\n	 › " + key + "kickall:「 Num 」"
    helpJS +=  "\n	 › " + key + "cancelall:「 Num 」"
    return helpJS
def kon():
    key = '' if not settings['setKey']['status'] else settings['setKey']['key']
    with open('ajs.txt', 'r') as f:
        text = f.read()
    konMsg = text.format(key=key.title())
    return konMsg
def jancok():
    key = '' if not settings['setKey']['status'] else settings['setKey']['key']
    with open('bl.txt', 'r') as f:
        text = f.read()
    jancokMsg = text.format(key=key.title())
    return jancokMsg
def oasu():
    key = '' if not settings['setKey']['status'] else settings['setKey']['key']
    with open('wl.txt', 'r') as f:
        text = f.read()
    oasuMsg = text.format(key=key.title())
    return oasuMsg
def special():
    key = '' if not settings['setKey']['status'] else settings['setKey']['key']
    with open('spam.txt', 'r') as f:
        text = f.read()
    specialMsg = text.format(key=key.title())
    return specialMsg
def remote():
    key = '' if not settings['setKey']['status'] else settings['setKey']['key']
    with open('remote.txt', 'r') as f:
        text = f.read()
    remoteMsg = text.format(key=key.title())
    return remoteMsg
def mediaa():
    if settings['setKey']['status'] == True:
        key = settings['setKey']['key']
    else:
        key = ''
    memek =   "Type: Help Media ♪"
    memek +=   "\n\t › "+ key + "Detect Url Tiktok「On/Off」"
    memek +=   "\n\t › "+ key + "Detect Url Instagram「On/Off」"
    memek +=   "\n\t › "+ key + "Xnxx「Query」"
    memek +=   "\n\t › "+ key + "Porn「Query」"
    memek +=   "\n\t › " + key + "InstaUser「User」"
    memek +=   "\n\t › "+ key + "InstaPost「Link」"
    memek +=   "\n\t › " + key + "TiktokUser「User」"
    memek +=   "\n\t › " + key + "TiktokVid「Link」"
    memek +=   "\n\t › " + key + "TwitterUser「User」"
    memek +=   "\n\t › " + key + "Random Hentai"
    memek +=   "\n\t › " + key + "Wikipedia「Query」"
    memek +=   "\n\t › " + key + "Zodiac「Query」"
    memek +=   "\n\t › " + key + "Lirik「Judul」"
    memek +=   "\n\t › " + key + "Artimana「Nama」"
    memek +=   "\n\t › " + key + "Neko"
    memek +=   "\n\t › " + key + "Hentai"
    memek +=   "\n\t › " + key + "Nsfwneko"
    memek +=   "\n\t › " + key + "Wallpaper"
    memek +=   "\n\t › " + key + "Traps"
    memek +=   "\n\t › " + key + "FakeMention"
    memek +=  "\n	 › " + key + "fancy 1-22"
    memek +=  "\n	 › " + key + "fancy「 Num 」「 Text 」"
    return memek
def changekey():
    if settings['setKey']['status'] == True:
        key = settings['setKey']['key']
    else:
        key = ''
    helpAnu =  "Type: Help Change Key♪"
    helpAnu +=  "\n	 › " + key + "changetagall:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changekick:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changekickrep:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changeinvite:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changeinviterep:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changekill:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changeinvname:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changekickall:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changecancelall:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changebypass:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changelable:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changeleave:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changecolor:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changecolorb:「 Text 」"
    helpAnu +=  "\n	 › " + key + "changetext:「 Text 」"
    helpAnu +=  "\n	 › " + key + "change picttemp"
    helpAnu +=  "\nType: Status Change Key♪"
    helpAnu +=  "\n	 › Tagall: " + key + "%s" % settings["changetagall"]
    helpAnu +=  "\n	 › Kick: " + key + "%s" % settings["changekick"]
    helpAnu +=  "\n	 › Invite: " + key + "%s" % settings["changeinvite"]
    helpAnu +=  "\n	 › Kick reply: " + key + "%s" % settings["changekickr"]
    helpAnu +=  "\n	 › Invite reply: " + key + "%s" % settings["changeinvites"]
    helpAnu +=  "\n	 › kickname: %s「@/Name」" % seni["ckill"]
    helpAnu +=  "\n	 › invitename: %s「@/Name」" % seni["cinv"]
    helpAnu +=  "\n	 › Kickall: " + key + "%s" % settings["changekickall"]
    helpAnu +=  "\n	 › Cancelall: " + key + "%s" % settings["changecancelall"]
    helpAnu +=  "\n	 › Bypass: " + key + "%s" % settings["changebypass"]
    helpAnu +=  "\n	 › Flag Lable: %s" % settings["changelable"]
    helpAnu +=  "\n	 › Leave: %s" % seni["cleave"]
    helpAnu +=  "\n	 › Color Background: %s" % settings["changecolor"]
    helpAnu +=  "\n	 › Color Border: %s" % settings["changecolorb"]
    helpAnu +=  "\n	 › Color Text: %s" % settings["changetext"]
    helpAnu +=  "\n	 › Type 'find color' to search for multiple color codes"
    return helpAnu
def modekey():
    if settings['setKey']['status'] == True:
        key = settings['setKey']['key']
    else:
        key = ''
    helpUwu =  "Type: Help Change Mode♪"
    helpUwu +=  "\n	 › " + key + "temp:1"
    helpUwu +=  "\n	 › " + key + "temp:2"
    helpUwu +=  "\n	 › " + key + "footer:On"
    helpUwu +=  "\n	 › " + key + "text:On"
    helpUwu +=  "\nType: Status Change Mode♪"
    helpUwu +=  "\n	 › Mode Template: " + bool_dict[settings['temp']][1]
    helpUwu +=  "\n	 › Mode Template 2: " + bool_dict[settings['temp1']][1]
    helpUwu +=  "\n	 › Mode Footer: " + bool_dict[settings['footer']][1]
    helpUwu +=  "\n	 › Mode Text: " + bool_dict[settings['text']][1]
    return helpUwu
def parsingRes(res):
    result = ''
    textt = res.split('\n')
    for text in textt:
        if True not in [text.startswith(s) for s in ['⚔', '├', '│', '']]:
            result += '\n ' + text
        else:
            if text == textt[0]:
                result += text
            else:
                result += '\n' + text
    return result
def helpanu(to):
    label = settings["changelable"]
    txtColor = settings["changetext"]
    brcolor = settings["changecolorb"]
    bgcolor = settings["changecolor"]
    tempPict = dataTemp["pict"]
    data={"type":"flex","altText":"Help command","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus)
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": f"{brcolor}",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{label}",
                    "size": "xl",
                    "color": f"{txtColor}",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus)
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": f"{brcolor}",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Chatbot",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=chatbot"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Feature",
                            "align": "center",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=feature"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Java",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=java"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Self",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=self"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Protect",
                            "align": "center",
                            "color": f"{txtColor}",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=protect"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "MySelf",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=myself"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text","text": "Settings","size": "sm","color": f"{txtColor}","align": "center",
                        "action": {"type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=settings"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Kicked",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=kicked"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Group",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=group"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": f"{brcolor}",
            "borderWidth": "2px"
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": f"{brcolor}",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": f"{bgcolor}"
    }
  }},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus)
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": f"{brcolor}",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{label}",
                    "size": "xl",
                    "color": f"{txtColor}",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus)
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": f"{brcolor}",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Banning",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=banning"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Wban",
                            "align": "center",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=wban"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Friend",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=friend"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Utility",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=utility"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Custom",
                            "align": "center",
                            "color": f"{txtColor}",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=custom"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Spam",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=spam"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Bcast",
                        "size": "sm",
                        "color": f"{txtColor}",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=bcast"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Mention",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=mention"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Steal",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=steal"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": f"{brcolor}",
            "borderWidth": "2px"
          }
        ]
      }
    ],"cornerRadius": "xl","borderColor": f"{brcolor}","borderWidth": "4px"
  },
  "styles": {
    "body": {"backgroundColor": f"{bgcolor}"}}},{"type": "bubble","body": {
    "type": "box","layout": "vertical","contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus)
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": f"{brcolor}",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{label}",
                    "size": "xl",
                    "color": f"{txtColor}",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus)
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": f"{brcolor}",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Added",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=added"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Grouplist",
                            "align": "center",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=grouplist"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Mode",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=mode"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Leave",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=leave"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Speed",
                            "align": "center",
                            "color": f"{txtColor}",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=speed"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Help BL",
                            "size": "xs",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=help+bl"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Help WL",
                        "size": "sm",
                        "color": f"{txtColor}",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=help+wl"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Runtime",
                            "size": "sm",
                            "color": f"{txtColor}",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=runtime"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box","layout": "vertical","contents": [
                          {"type": "text","text": "Logout","size": "xs","color": f"{txtColor}","align": "center","action": {
                              "type": "uri","label": "action","uri": "line://app/1602687308-GXq4Vvk9/?type=text&text=logout"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],"borderColor": f"{brcolor}","borderWidth": "2px"
          }
        ]
      }
    ],"cornerRadius": "xl","borderColor": f"{brcolor}","borderWidth": "4px"},"styles": {"body": {"backgroundColor": f"{bgcolor}"}}}]}}
    sendTemplate(to,data)
def SendTemp(to, text):
    pantek1 = {
  "type": "flex",
  "altText": "MUDEE NI BOUSSS",
  "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "size": "xs",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "25px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " • COMMANDS •",
                "size": "xs",
                "color": settings['changetext'],
                "weight": "bold",
                "style": "normal",
                "align": "center"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "15px",
            "offsetTop": "5px",
            "offsetStart": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": settings['changetext'],
                "size": "xxs"
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "200px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "私はハンサムです",
                "size": "xs",
                "style": "normal",
                "weight": "bold",
                "align": "center",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "148px",
            "height": "25px",
            "offsetTop": "205px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n ME\n GROUP\n SETTING\n RUNTIME\n SPEED\n GROUPLIST\n CHANGE:SET\n MODE:SET\n PROFILE\n MYPROFILE\n RESTART\n LOGOUT", #1
                "size": "xxs",
                "weight": "bold",
                "color": settings['changetext'],
                "style": "normal",
                "wrap": True,
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "offsetTop": "28px",
            "offsetStart": "15px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": settings['changecolorb'],
        "cornerRadius": "15px"
      },
      "styles": {
        "body": {
          "backgroundColor": settings['changecolor'],
        }
      }
    },
    {      
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "size": "xs",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "25px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " • COMMANDS •",
                "size": "xs",
                "color": settings['changetext'],
                "weight": "bold",
                "style": "normal",
                "align": "center"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "15px",
            "offsetTop": "5px",
            "offsetStart": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": settings['changetext'],
                "size": "xxs"
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "200px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "私はハンサムです",
                "size": "xs",
                "style": "normal",
                "weight": "bold",
                "align": "center",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "148px",
            "height": "25px",
            "offsetTop": "205px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n ADDWL 「mention」\n DELWL 「mention」\n DELWL: 「num」\n WL: 「On/Off」\n ADDBL 「mention」\n DELBL 「mention」\n DELBL: 「num」\n BL: 「On/Off」\n WHITELIST\n BLACKLIST", #2
                "size": "xxs",
                "weight": "bold",
                "color": settings['changetext'],
                "style": "normal",
                "wrap": True,
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "offsetTop": "28px",
            "offsetStart": "15px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": settings['changecolorb'],
        "cornerRadius": "15px"
      },
      "styles": {
        "body": {
          "backgroundColor": settings['changecolor'],
        }
      }
    },
    {                                      
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "size": "xs",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "25px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " • COMMANDS •",
                "size": "xs",
                "color": settings['changetext'],
                "weight": "bold",
                "style": "normal",
                "align": "center"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "15px",
            "offsetTop": "5px",
            "offsetStart": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": settings['changetext'],
                "size": "xxs"
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "200px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "私はハンサムです",
                "size": "xs",
                "style": "normal",
                "weight": "bold",
                "align": "center",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "148px",
            "height": "25px",
            "offsetTop": "205px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n %s 「mention」" % settings["changekick"]+"\n %s 「reply」" % settings["changekickr"]+"\n %s 「mention」" % settings["changeinvite"]+"\n %s 「reply」" % settings["changeinvites"]+"\n %s" % settings["changekickall"]+"\n %s" % settings["changecancelall"]+"\n %s " % settings["changebypass"], #3
                "size": "xxs",
                "weight": "bold",
                "color": settings['changetext'],
                "style": "normal",
                "wrap": True,
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "offsetTop": "28px",
            "offsetStart": "15px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": settings['changecolorb'],
        "cornerRadius": "15px"
      },
      "styles": {
        "body": {
         "backgroundColor": settings['changecolor'],
        }
      }
    },
    {                                      
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "size": "xs",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "25px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " • COMMANDS •",
                "size": "xs",
                "color": settings['changetext'],
                "weight": "bold",
                "style": "normal",
                "align": "center"
              }
            ],
            "position": "absolute",
            "width": "105px",
            "height": "15px",
            "offsetTop": "5px",
            "offsetStart": "20px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": ".",
                "color": settings['changetext'],
                "size": "xxs"
              }
            ],
            "position": "absolute",
            "width": "125px",
            "height": "1px",
            "backgroundColor": settings['changecolor'],
            "offsetTop": "200px",
            "offsetStart": "15px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": " • COMMANDS •",
                "size": "xs",
                "style": "normal",
                "weight": "bold",
                "align": "center",
                "color": settings['changetext'],
              }
            ],
            "position": "absolute",
            "width": "148px",
            "height": "25px",
            "offsetTop": "205px",
            "offsetStart": "2px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "\n GROUPINFO\n OURL\n CURL\n SETPRO\n LISTPRO\n SIDER「On/Off」\n LURK\n MIMIC\n MENTIONNOTE\n %s"% settings["changetagall"], #4
                "size": "xxs",
                "weight": "bold",
                "color": settings['changetext'],
                "style": "normal",
                "wrap": True,
                "offsetTop": "0px",
                "offsetStart": "0px"
              }
            ],
            "position": "absolute",
            "offsetTop": "28px",
            "offsetStart": "15px"
          }
        ],
        "paddingAll": "0px",
        "borderWidth": "3px",
        "borderColor": settings['changecolorb'],
        "cornerRadius": "15px"
      },
      "styles": {
        "body": {         
         "backgroundColor": settings['changecolor'],
        }
      }
    }
  ]
}
}
    sendTemplate(to, pantek1)
def SendTemp32(to, text):
    data = {    
        "type": "flex",
        "altText": "M x L™",
        "contents": {
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "kilo",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                            "position": "absolute",
                            "size": "25px",
                            "aspectRatio": "1:1",
                            "aspectMode": "cover"
                          }
                        ],
                        "width": "25px",
                        "height": "25px",
                        "borderColor": settings['changecolorb'],
                        "position": "relative",
                        "cornerRadius": "150px",
                        "borderWidth": "1.25px",
                        "offsetTop": "8px",
                        "offsetStart": "5px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                            "position": "absolute",
                            "size": "25px",
                            "aspectRatio": "1:1",
                            "aspectMode": "cover"
                          }
                        ],
                        "position": "relative",
                        "width": "25px",
                        "height": "25px",
                        "cornerRadius": "150px",
                        "borderColor": settings['changecolorb'],
                        "borderWidth": "1.25px",
                        "offsetTop": "-17.2px",
                        "offsetStart": "192px"
                      },
                      {
                        "type": "text",
                        "text": " • COMMANDS •",
                        "color": settings['changetext'],
                        "size": "sm",
                        "weight": "regular",
                        "style": "normal",
                        "align": "center",
                        "offsetTop": "-40px"
                      }
                    ],
                    "borderColor": settings['changecolorb'],
                    "borderWidth": "semi-bold",
                    "cornerRadius": "xl",
                    "height": "45px"
                  }
                ],
                "spacing": "md",
                "margin": "sm"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "wrap": True,
                    "size": "sm",
                    "color": settings['changetext'],
                    "offsetStart": "5px"
                  }
                ],
                "borderColor": settings['changecolorb'],
                "borderWidth": "semi-bold",
                "cornerRadius": "xl",
                "paddingAll": "0px",
                "margin": "sm",
                "spacing": "md"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "私はハンサムです",
                    "size": "sm",
                    "color": settings['changetext'],
                    "align": "center",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "https://line.me/ti/p/~mdz-"
                    },
                    "offsetTop": "9px"
                  }
                ],
                "borderColor": settings['changecolorb'],
                "borderWidth": "semi-bold",
                "cornerRadius": "xl",
                "margin": "sm",
                "spacing": "md",
                "height": "45px"
              }
            ]
          }
        ],
        "backgroundColor": settings['changecolor'],
        "borderColor": settings['changecolorb'],
        "borderWidth": "semi-bold",
        "cornerRadius": "md"
      }
    }
  ]
}
}
    sendTemplate(to, data)
def temp3(to, text):
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    inihari = datetime.now(tz=tz)
    try:
        nametemp = line.getGroup(to).name
        picttemp = line.getGroup(to).pictureStatus
    except:
        try:
            nametemp = line.getContact(to).displayName
            picttemp = line.getContact(to).pictureStatus
        except:
            nametemp = line.profile.displayName
            picttemp = line.profile.pictureStatus
    if settings["temp1"] == True:
        data={"type":"flex","altText": settings["changelable"],"contents":{
          "type": "carousel",
          "contents": [
            {
          "type": "bubble",
          "header": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://cdn.discordapp.com/attachments/296154578947407872/814366612391723028/waawaw.jpg",
                "size": "full",
                "aspectRatio": "678:106"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(picttemp),
                    "size": "full",
                    "aspectMode": "cover"
                  }
                ],
                "position": "absolute",
                "width": "33px",
                "height": "33px",
                "cornerRadius": "100px",
                "offsetStart": "32px",
                "offsetTop": "8px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(nametemp),
                    "size": "md",
                    "color": "#FFFFFF",
                    "weight": "bold"
                  }
                ],
                "position": "absolute",
                "offsetStart": "70px",
                "offsetTop": "15px",
                "width": "110px"
              }
            ],
            "paddingAll": "0px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://line.me/R/nv/chat"
            }
          },
          "body": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Today",
                    "align": "center",
                    "size": "xxs"
                  }
                ],
                "backgroundColor": "#d6eaf5",
                "width": "50px",
                "cornerRadius": "5px",
                "offsetStart": "107px",
                "offsetTop": "3px",
                "action": {
                  "type": "uri",
                  "label": "action",
                  "uri": "https://line.me/R/ti/p/~{}".format(line.profile.userid)
                }
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": text,
                    "wrap": True,
                    "offsetStart": "2px",
                    "size": "xs"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": inihari.strftime('%H:%M'),
                        "size": "12px",
                        "align": "end",
                        "offsetEnd": "20px",
                        "position": "absolute"
                      },
                      {
                        "type": "image",
                        "url": "https://i.ibb.co/5kXzN4W/1602905613052.png",
                        "align": "end",
                        "position": "relative",
                        "size": "20px",
                        "aspectRatio": "329:241"
                      }
                    ],
                    "offsetBottom": "3px"
                  }
                ],
                "backgroundColor": "#e3ffca",
                "cornerRadius": "12px",
                "width": "180px",
                "offsetStart": "92px",
                "offsetTop": "11px",
                "paddingAll": "5px",
                "paddingBottom": "0px"
              }
            ],
            "backgroundColor": "#efe6dd",
            "paddingTop": "4px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://line.me/R/ti/p/~{}".format(line.profile.userid)
            }
          },
          "footer": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://cdn.discordapp.com/attachments/296154578947407872/814367104500498462/217108.jpg",
                "aspectRatio": "720:112",
                "size": "full",
                "aspectMode": "cover"
              }
            ],
            "paddingAll": "0px",
            "action": {
              "type": "uri",
              "label": "action",
              "uri": "https://line.me/R/ti/p/~{}".format(line.profile.userid)
            }
          },
          "styles": {
            "header": {
              "backgroundColor": "#085e55"
            }
          }}]}}
        sendTemplate(to, data)

def main_help(to):
    label = settings["changelable"]
    txtColor = settings["changetext"]
    brcolor = settings["changecolorb"]
    bgcolor = settings["changecolor"]
    tempPict = dataTemp["pict"]
    tempData = {
  "type": "bubble",
  "size": "mega",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": f"{tempPict}",
        "size": "full",
        "aspectMode": "cover",
        "aspectRatio": "1:1",
        "gravity": "center"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [],
        "position": "absolute",
        "offsetTop": "190px",
        "offsetStart": "10px",
        "borderWidth": "5px",
        "borderColor": f"{brcolor}",
        "cornerRadius": "10px",
        "paddingStart": "225px",
        "paddingAll": "45px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
            "size": "xs",
            "aspectMode": "cover"
          }
        ],
        "position": "absolute",
        "borderWidth": "2px",
        "borderColor": f"{brcolor}",
        "cornerRadius": "500px",
        "offsetTop": "80px",
        "offsetStart": "120px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "• ChatBot",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Banning",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Bcast",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Custom",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          }
        ],
        "position": "absolute",
        "offsetTop": "200px",
        "offsetStart": "20px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "• Self",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• MySelf",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Group",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Protect",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          }
        ],
        "position": "absolute",
        "offsetTop": "200px",
        "offsetStart": "125px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "text",
            "text": "• Feature",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Steal",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Kicked",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          },
          {
            "type": "text",
            "text": "• Settings",
            "size": "md",
            "color": f"{txtColor}",
            "weight": "bold"
          }
        ],
        "position": "absolute",
        "offsetTop": "200px",
        "offsetStart": "210px"
      }
    ],
    "paddingAll": "0px"
  }
}
    data = {
    "type": "flex",
    "altText": "Menu Help",
    "contents": {
        "type": "carousel",
        "contents": [
            tempData
        ]
    }
}
    sendTemplate(to,data)
def SendTemp3(to, isi):
    label = settings["changelable"]
    txtColor = settings["changetext"]
    brColor = settings["changecolorb"]
    bgColor = settings["changecolor"]
    tempPict = dataTemp["pict"]
    tz = pytz.timezone("Asia/Jakarta")
    G = line.getGroup(to)
    timeNow = datetime.now(tz=tz)
    tempData = {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": f"{tempPict}",
        "size": "full",
        "aspectMode": "cover",
        "position": "absolute",
        "aspectRatio": "10:30"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                    "aspectMode": "cover"
                  }
                ],
                "width": "50px",
                "height": "50px",
                "cornerRadius": "100px",
                "borderWidth": "2px",
                "borderColor": f"{brColor}",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{label}",
                    "size": "xl",
                    "weight": "bold",
                    "color": f"{txtColor}"
                  },
                  {
                    "type": "text",
                    "text": "Tanggal : " + datetime.strftime(timeNow,'%d-%m-%Y'),
                    "size": "xs",
                    "color": f"{txtColor}",
                    "weight": "bold"
                  }
                ],
                "margin": "md",
                "offsetStart": "5px"
              }
            ]
          }
        ],
        "paddingAll": "6px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "offsetStart": "5px",
                "size": "md",
                "color": f"{txtColor}",
                "wrap": True,
                "text": isi
              }
            ],
            "borderWidth": "1px",
            "borderColor": f"{brColor}",
            "cornerRadius": "5px"
          }
        ],
        "paddingAll": "6px"
      }
    ],
    "paddingAll": "0px",
    "borderColor": f"{brColor}",
    "cornerRadius": "17px",
    "borderWidth": "4px"
  }
}
    data = {
    "type": "flex",
    "altText": "Template Message",
    "contents": {
        "type": "carousel",
        "contents": [
            tempData
        ]
    }
}
    sendTemplate(to,data)
def send_foo(to, isi):
  if settings["temp"] == True:
    label = settings["changelable"]
    txtColor = settings["changetext"]
    brColor = settings["changecolorb"]
    bgColor = settings["changecolor"]
    tempPict = dataTemp["pict"]
    tz = pytz.timezone("Asia/Jakarta")
    G = line.getGroup(to)
    timeNow = datetime.now(tz=tz)
    tempData = {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "image",
        "url": f"{tempPict}",
        "size": "full",
        "aspectMode": "cover",
        "position": "absolute",
        "aspectRatio": "10:30"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                    "aspectMode": "cover"
                  }
                ],
                "width": "50px",
                "height": "50px",
                "cornerRadius": "100px",
                "borderWidth": "2px",
                "borderColor": f"{brColor}",
                "offsetStart": "5px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{label}",
                    "size": "xl",
                    "weight": "bold",
                    "color": f"{txtColor}"
                  },
                  {
                    "type": "text",
                    "text": "Tanggal : " + datetime.strftime(timeNow,'%d-%m-%Y'),
                    "size": "xs",
                    "color": f"{txtColor}",
                    "weight": "bold"
                  }
                ],
                "margin": "md",
                "offsetStart": "5px"
              }
            ]
          }
        ],
        "paddingAll": "6px"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "offsetStart": "5px",
                "size": "md",
                "color": f"{txtColor}",
                "wrap": True,
                "text": isi
              }
            ],
            "borderWidth": "1px",
            "borderColor": f"{brColor}",
            "cornerRadius": "5px"
          }
        ],
        "paddingAll": "6px"
      }
    ],
    "paddingAll": "0px",
    "borderColor": f"{brColor}",
    "cornerRadius": "17px",
    "borderWidth": "4px"
  }
}
    data = {
    "type": "flex",
    "altText": "Template Message",
    "contents": {
        "type": "carousel",
        "contents": [
            tempData
        ]
    }
}
    sendTemplate(to,data)
def anunanu(to,s,wait,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"sentBy":{"label": "{}".format(settings["changelable"]),"iconUrl":"https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),"linkUrl":"line://nv/profilePopup/mid=u9b6db671badc05e225fd489e0a72a3e3"}}]}
        else:
            data = {"messages": [{"type": "image","originalContentUrl": s,"previewImageUrl": s,"animated":True,"extension":"gif","sentBy":{"label": "{}".format(settings["changelable"]),"iconUrl":"https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),"linkUrl":"line://nv/profilePopup/mid=u9b6db671badc05e225fd489e0a72a3e3"}}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
def anuanu(to,s,wait,j=''):
    try:
        if j == '':
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        else:
            data = {"messages": [{"type": "video","originalContentUrl": s,"previewImageUrl": s}]}
        sendCarousel(to,data)
    except Exception as e:
        print(e)
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "{}".format(settings["changelable"]),
            "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
            "linkUrl": "line://nv/profilePopup/mid=u9b6db671badc05e225fd489e0a72a3e3"
        }
    }
    sendTemplate(to, data)
def imageFooter(to, image):
    data = {
        "type": "image",
        "originalContentUrl": "{}".format(image),
        "previewImageUrl":"{}".format(image),
        "animated":True,
        "extension":"jpg",
        "sentBy": {
            "label": "{}".format(settings["changelable"]),
            "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
            "linkUrl": "line://nv/profilePopup/mid=u9b6db671badc05e225fd489e0a72a3e3"
        }
    }
    sendTemplate(to, data)
def sendMessageCustom(to, text, icon , name):
	annda = {'MSG_SENDER_ICON': icon,
		'MSG_SENDER_NAME':  name,
	}
	line.sendMessage(to, text, contentMetadata=annda)
def mentionMembers(to, mids=[]):
    if myMid in mids: mids.remove(myMid)
    k = len(mids)//20
    for aa in range(k+1):
        if aa == 0:dd = ' 「 Mention Members 」';no=aa
        else:dd = '';no=aa*20
        msgas = dd
        for mid in mids[aa*20:(aa+1)*20]:
            no += 1
            if no == len(mids):msgas+='\n\t{}. @!'.format(no)
            else:msgas += '\n\t{}. @!'.format(no)
        sendMention(to, msgas, mids[aa*20:(aa+1)*20])
def mentionMembers2(gid, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    G = line.getGroup(gid)
    result = ' 「 Mention Members 」\n'
    mention = '@IYUS_SELF™\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '\t› %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += 'Group : \n' + G.name
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(gid, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def NoteCreate(to,cmd,msg):
    h = []
    s = []
    if cmd == 'mentionnote':
        sakui = line.getProfile()
        group = line.getGroup(msg.to);nama = [contact.mid+'||//{}'.format(contact.displayName) for contact in group.members];nama.remove(sakui.mid+'||//{}'.format(sakui.displayName))
        data = nama
        k = len(data)//20
        for aa in range(k+1):
            nos = 0
            if aa == 0:dd = '╭「 Mention Note 」─';no=aa
            else:dd = '├「 Mention Note 」─';no=aa*20
            msgas = dd
            for i in data[aa*20 : (aa+1)*20]:
                no+=1
                if no == len(data):msgas+='\n{}. @'.format(no)
                else:msgas+='\n├{}. @'.format(no)
            msgas = msgas
            for i in data[aa*20 : (aa+1)*20]:
                gg = []
                dd = ''
                for ss in msgas:
                    if ss == '@':
                        dd += str(ss)
                        gg.append(dd.index('@'))
                        dd = dd.replace('@',' ')
                    else:
                        dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[nos], 'end': gg[nos]+1,'mid': str(i.split('||//')[0])})
                nos +=1
            h = line.createPostGroup(msgas,msg.to,holdingTime=None,textMeta=s)
    else:
        cmd = cmd.replace(msg.text[:12],'')
        if 'MENTION' in msg.contentMetadata.keys()!= None:
            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
            mentionees = mention['MENTIONEES']
            no = 0
            for mention in mentionees:
                ask = no
                nama = str(line.getContact(mention["M"]))
                h.append(str(cmd.replace('@{}'.format(nama),'@')))
                for b in h:
                    cmd = str(b)
                gg = []
                dd = ''
                for ss in cmd:
                    if ss == '@':
                         dd += str(ss)
                         gg.append(dd.index('@'))
                         dd = dd.replace('@',' ')
                    else:
                         dd += str(ss)
                s.append({'type': "RECALL", 'start': gg[no], 'end': gg[no]+1,'mid': str(mention["M"])})
                no +=1
        h = line.createPostGroup(cmd,msg.to,holdingTime=None,textMeta=s)            
def albumNamaGrup(to,wait,cmd):
    ha = line.getGroupAlbum(to)
    if cmd == 'get album':
        a = [a['title'] for a in ha['result']['items']];c=[a['photoCount'] for a in ha['result']['items']]
        b = '╭「 Album Group 」'
        no=0
        for i in range(len(a)):
            no+=1
            if no == len(a):b+= '\n╰{}. {} | {}'.format(no,a[i],c[i])
            else:b+= '\n│{}. {} | {}'.format(no,a[i],c[i])
        line.sendMessage(to,"{}".format(b))
    if cmd.startswith('get album '):
        try:
            a = cmd.split(' ')
            selection = AdityaSplitGood(a[3],range(1,len(ha['result']['items'])+1))
            print(selection)
            for i in selection.parse():
                try:
                    b = random.randint(0,999)
                    s = line.getImageGroupAlbum(to,ha['result']['items'][int(a[2])-1]['id'], ha['result']['items'][int(a[2])-1]['recentPhotos'][i-1]['oid'], returnAs='path', saveAs='{}.png'.format(b))
                    print(s)
                    line.sendImage(to,'{}.png'.format(b))
                    os.remove('{}.png'.format(b))
                except:continue
        except Exception as e:print(e)
    else:
        a = cmd.split(' ')
        if len(a) == 5:
            wait["Images"]['anu']=ha['result']['items'][int(a[3])-1]['id']
            wait['ChangeGDP'] = True
            line.sendMessage(to," 「 Album 」\nSend a Picture for add to album")
def TEMPELER(to, text):
    try:
        if settings["temp"] == True:
            if "@!" in text:
                pesan = text.replace("@!","")
            else:
                pesan = text
            send_foo(to, pesan)
        if settings["temp1"] == True:
            if "@!" in text:
                pesan = text.replace("@!","")
            else:
                pesan = text
            temp3(to, pesan)
        if settings["footer"] == True:
            if "@!" in text:
                pesan = text.replace("@!","")
            else:
                pesan = text
            sendFooter(to, pesan)
        if settings["text"] == True:
            if "@!" in text:
                pesan = text.replace("@!","")
            else:
                pesan = text
            line.sendMessage(to, pesan)
    except Exception as e:print(e)
def sendMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@IYUS_SELF™ "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def sendMentionV2(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@IYUS_SELF™ "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    line.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
def cloneProfile(mid):
    contact = line.getContact(mid)
    profile = line.getProfile()
    profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
    line.updateProfile(profile)
    if contact.pictureStatus:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus)
        line.updateProfilePicture(pict)
    coverId = line.getProfileDetail(mid)['result']['objectId']
    line.updateProfileCoverById(coverId)
def backupProfile():
    profile = line.getContact(myMid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    coverId = line.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
def debug():
	get_profile_time_start = time.time()
	get_profile = line.getProfile()
	get_profile_time = time.time() - get_profile_time_start
	get_profile_took = time.time() - get_profile_time_start
	return "Type: Speed♪\n\t• Took : %.3fms♪\n\t• Taken: %.5f♪" % (get_profile_took,get_profile_time)
def cloneProfile(mid):
    contact = line.getContact(mid)
    if contact.videoProfile == None:
        line.cloneContactProfile(mid)
    else:
        profile = line.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        line.updateProfile(profile)
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = line.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = line.getProfileDetail(mid)['result']['objectId']
    line.updateProfileCoverById(coverId)
def ClonerV2(to):
    try:
        contact = line.getContact(to)
        profile = line.profile
        profileName = line.profile
        profileStatus = line.profile
        profileName.displayName = contact.displayName
        profileStatus.statusMessage = contact.statusMessage
        line.updateProfile(profileName)
        line.updateProfile(profileStatus)
        profile.pictureStatus = line.downloadFileURL('http://dl.profile.line-cdn.net/{}'.format(contact.pictureStatus, 'path'))
        if line.getProfileCoverId(to) is not None:
            line.updateProfileCoverById(line.getProfileCoverId(to))
        line.updateProfilePicture(profile.pictureStatus)
        print("Success Clone Profile {}".format(contact.displayName))
        return line.updateProfile(profile)
        if contact.videoProfile == None:
            return "Get Video Profile"
        path2 = "http://dl.profile.line-cdn.net/" + profile.pictureStatus
        line.updateProfilePicture(path2, 'vp')
    except Exception as error:
        print(error)
def backupProfile():
    profile = line.getContact(myMid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = line.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)
def restoreProfile():
    profile = line.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        line.updateProfileAttribute(8, profile.pictureStatus)
        line.updateProfile(profile)
    else:
        line.updateProfile(profile)
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = line.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    line.updateProfileCoverById(coverId)
def restoreProfile():
    profile = line.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    line.updateProfile(profile)
    if settings['myProfile']['pictureStatus']:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'])
        line.updateProfilePicture(pict)
    coverId = settings['myProfile']['coverId']
    line.updateProfileCoverById(coverId)
def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
 for izumii in msg.text.lower().split(" "):
    trojan = command(text)
    cmd = " ".join(trojan.split())
 for cmd in trojan.split(' & '):
    if cmd == 'silent':
        if to in silent['silent']:
            TEMPELER(to, 'you have to Mute this group :)\nPlease Usage Commands "!unmute" ')
        else:
            silent['silent'].append(to)
            TEMPELER(to, 'Bot cant Not Operation again♪')
    elif cmd == 'unsilent':
        if to not in silent['silent']:
            TEMPELER(to, "you haven't  this group :)")
        else:
            silent['silent'].remove(to)
            TEMPELER(to, 'Bot can Operation again♪')
    if to in silent['silent']:
        return
    if cmd == 'logout':
      if msg._from in myMid:
        TEMPELER(to,"Selfbot has been logout♪")
        sys.exit('##----- PROGRAM STOPPED -----##')
    elif cmd == 'logoutdevicee':
      if msg._from in myMid:
        line.logout()
        sys.exit('##----- CLIENT LOGOUT -----##')
    elif cmd == 'restart':
      if msg._from in myMid:
        TEMPELER(to,"Bot will restarting, please wait until the bot can operated♪")
        settings['restartPoint'] = to
        restartProgram()
    elif cmd == 'list silent':
        groups = silent['silent']
        ret_ = "Silent List :\n"
        no = 0 + 1
        for gid in groups:
            group = line.getGroup(gid)
            ret_ += "\n{}. {} // {}".format(str(no), str(group.name), str(len(group.members)))
            no += 1
        ret_ += "\n\n{} Set To Disabled\nUsage: Silent or Unsilent".format(str(len(groups)))
        TEMPELER(to, ret_)
#================Menu Help================
    elif cmd == 'help':
                    Help = help()
                    TEMPELER(to,Help)
    elif cmd == 'group':
                    sumpah = til()
                    TEMPELER(to,sumpah)
    elif cmd == 'feature':
                    ngentot = mediaa()
                    TEMPELER(to,ngentot)
    elif cmd == 'setting':
      if msg._from in myMid:
                    kontol = setting()
                    TEMPELER(to,kontol)
    elif cmd == 'kick':
                    puki = kick()
                    TEMPELER(to,puki)
    elif cmd == 'steal':
                    Betak = betak()
                    TEMPELER(to,Betak)
    elif cmd == 'kicked':
                    ret = "• Type: Help Kick "
                    ret += "\n  「 Status 」\n\n"
                    if nukemode["kickID"] == "":ret += "  KICK STKID : EMPTY\n"
                    else:ret += "  KICK STKID : {}\n".format(str(nukemode["kickID"]))
                    if nukemode["invID"] == "":ret += "  INVITE STKID : EMPTY\n"
                    else:ret += "  INVITE STKID : {}\n".format(str(nukemode["invID"]))
                    ret += "\n › {key}Kick stk「 On/Off 」"
                    ret += "\n › {key}Invite stk「 On/Off 」"
                    ret += "\n › {key}Kickall"
                    ret += "\n › {key}Cancelall"
                    ret += "\n › {key}%s「 Mention/Name」" % seni["ckill"]
                    ret += "\n › {key}%s「 Name 」" % seni["cinv"]
                    ret += "\n › {key}Cancel「 Name 」"
                    ret += "\n › {key}Vkick「 Mention 」"
                    ret += "\n › {key}Rkick「 Mention 」"
                    ret += "\n › {key}Mkick「 Mention 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'bl':
                    ret = "• Type: Help Blacklist "
                    ret += "\n › {key}blacklist"
                    ret += "\n › {key}clearbl"
                    ret += "\n › {key}detectbl"
                    ret += "\n › {key}autopurge「 On/Off 」"
                    ret += "\n › {key}joinpurge「 On/Off 」"
                    ret += "\n › {key}addbl「 @/Reply/C 」"
                    ret += "\n › {key}delbl「 @/Num/Reply/C 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'get':
                    ret = "• Type: Get Group "
                    ret += "\n › {key}get note"
                    ret += "\n › {key}get announ"
                    ret += "\n › {key}get gcall"
                    ret += "\n › {key}get note「 num 」"
                    ret += "\n › {key}get announ「 num 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'js':
                    ret = "• Type: JS♪"
                    ret += "\n  「 Status 」\n\n"
                    if nukemode["java"] == "":ret += "  JavaMode : OFF\n"
                    else:ret += "  JavaMode : {}\n".format(str(nukemode["java"]))
                    ret += "\n › {key}%s「 Bypass 」" % settings["changebypass"]
                    ret += "\n › {key}%s「 Kickall 」" % settings["changekickall"]
                    ret += "\n › {key}%s「 Cancelall 」" % settings["changecancelall"]
                    ret += "\n › {key}javamode「 On/Off 」"
                    ret += "\n• Type: Remote Js♪"
                    ret += "\n › {key}meluncur:「 Num 」"
                    ret += "\n › {key}kickall:「 Num 」"
                    ret += "\n › {key}cancelall:「 Num 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'fakemention':
                    ret = "• Type: Help Fake Tag "
                    ret += "\n  「 Status 」\n"
                    if sygmude["fstkID"] == "":ret += "  STKID : EMPTY\n"
                    else:ret += "  STKID : {}\n".format(str(sygmude["fstkID"]))
                    if mmin["fakementionc"] == "":ret += "  CONTACT : EMPTY\n\n"
                    else:ret += "  CONTACT : {}\n\n".format(line.getContact(mmin["fakementionc"]).displayName)
                    if mmin["fakementionc"] == "":ret += "  COMMAND : EMPTY\n"
                    else:ret += "  CMD CONTACT : {}\n".format(str(mmin["fakemention13"]))
                    if mmin["fakemention7"] == "":ret += "  COMMAND : EMPTY\n"
                    else:ret += "  CMD STICKER : {}\n".format(str(mmin["fakemention7"]))
                    ret += "\n  「 Fakemention Sticker 」"
                    ret += "\n•  {key}Add Cmd Faketag"
                    ret += "\n•  {key}Addfaketag stk"
                    ret += "\n•  {key}Faketag stk「 on / off 」"
                    ret += "\n•  {key}Cmd Faketag:「 text 」"
                    ret += "\n  「 Fakemention Contact 」"
                    ret += "\n•  {key}Addfaketag contact"
                    ret += "\n•  {key}Faketag contact「 on / off 」"
                    ret += "\n•  {key}ChangeFakeContact:「 text 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'wl':
                    ret = "• Type: Help Whitelist "
                    ret += "\n › {key}whitelist"
                    ret += "\n › {key}clearwl"
                    ret += "\n › {key}detectwl"
                    ret += "\n › {key}addwl「 @/Reply/C 」"
                    ret += "\n › {key}delwl「 @/Num/Reply/C 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'self':
                    ret = "• Type: Help Self "
                    ret += "\n › {key}MyProfile"
                    ret += "\n › {key}Profile"
                    ret += "\n › {key}Changevp"
                    ret += "\n › {key}Rename @/Reply | [name]"
                    ret += "\n › {key}Renamelist"
                    ret += "\n › {key}Cek Rename"
                    ret += "\n › {key}AutoAdd"
                    ret += "\n › {key}clone @"
                    ret += "\n › {key}unclone"
                    ret += "\n › {key}MySticker"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'team':
                    ret = "• Type: Help Team "
                    ret += "\n › {key}teamlist"
                    ret += "\n › {key}clearteam"
                    ret += "\n › {key}addteam「 @/Reply/C 」"
                    ret += "\n › {key}delteam「 @/Num/Reply/C 」"
                    ret += "\n › {key}changeteam:「 Text 」"
                    ret += "\n › {key}%s「 Command For Invite Team 」" % settings["changeteam"]
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'tban':
                    ret = "• Type: Help Tban "
                    ret += "\n › {key}tbanlist"
                    ret += "\n › {key}cleartban"
                    ret += "\n › {key}addtban「 @/Reply/C 」"
                    ret += "\n › {key}tunban「 @/Num/Reply/C 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'remote':
                    ret = "• Type: Help Remote "
                    ret += "\n › openqr:「 Num 」"
                    ret += "\n › closeqr:「 Num 」"
                    ret += "\n › ginfo:「 Num 」"
                    ret += "\n › infomem:「 Num 」"
                    ret += "\n › mentionall:「 Num 」"
                    ret += "\n › unsend:「 Num 」「 Numb 」"
                    ret += "\n › spamcall:「 Num 」「 Numb 」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'spam':
                    ret = "• Type: Help Spam "
                    ret += "\n › {key}Spamcall「 Num 」"
                    ret += "\n › {key}Spamcallto「Num」「Mention」"
                    ret += "\n › {key}Spamtag「Num」「Mention」"
                    ret += "\n › {key}Spamtext「Num」「Text」"
                    ret += "\n › {key}Spam 1「Num」「Text」"
                    ret += "\n › {key}Spam 2「Num」"
                    TEMPELER(to,parsingRes(ret).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'custom':
                    sayang = changekey()
                    TEMPELER(to,sayang)
    elif cmd == 'mode':
                    mek = modekey()
                    TEMPELER(to,mek)
#================BATAS================
    elif cmd == mmin["fakemention7"]:
                if sygmude["fakemention"] == True:
                        stk_id = sygmude["fstkID"]
                        stk_ver = sygmude["fstkVER"]
                        pkg_id = sygmude["fpkgID"]
                        mids = []
                        G = line.getGroup(to)
                        mems = [a.mid for a in G.members]
                        if mems != []:
                            for t in mems:
                                mids.append(t)
                        if myMid in mems:
                            mids.remove(myMid)
                        target = len(mids)//140+1
                        text = " << fake mention >>"
                        mention = "@iyusNiBous\n"
                        no = 0
                        for x in range(target):
                            mentioness = []
                            for mid in mids[x*140:(x+1)*140]:
                                no += 1
                                text += "    • . %i %s"%(no, mention)
                                slen = len(text) - 12
                                elen = len(text) + 3
                                mentioness.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
                            if mentioness:
                                try:
                                    msg.contentMetadata["STKID"] = int(stk_id)+1
                                    msg.contentMetadata['STKVER'] = stk_ver
                                    msg.contentMetadata['STKPKGID'] = pkg_id
                                    stkid = str(msg.contentMetadata["STKID"])
                                    sver = msg.contentMetadata['STKVER']
                                    spkg = msg.contentMetadata['STKPKGID']
                                    line.sendMessage2(to, text, {'MENTION': json.dumps({'MENTIONEES': mentioness}),'STKID': stkid, 'STKVER': sver, 'STKPKGID': spkg}, 7)
                                except Exception as e:print(e)
    elif cmd == mmin["fakemention13"]:
        if mmin["cmention"] == True:
            mids = []
            G = line.getGroup(to)
            mems = [a.mid for a in G.members]
            if mems != []:
                for t in mems:
                    mids.append(t)
            if myMid in mems:
                mids.remove(myMid)
            target = len(mids)//140+1
            text = " << fake mention >>"
            mention = "@iyusNiBous\n"
            no = 0
            for x in range(target):
                mentioness = []
                for mid in mids[x*140:(x+1)*140]:
                    no += 1
                    text += "    • . %i %s"%(no, mention)
                    slen = len(text) - 12
                    elen = len(text) + 3
                    mentioness.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
                if mentioness:
                    try:
                        line.sendMessage2(to, text, {'MENTION': json.dumps({'MENTIONEES': mentioness}),'mid': mmin["fakementionc"]}, 13)
                    except Exception as e:print(e)
    elif cmd == "addfaketag contact":
        mmin["addfakementionc"] = True
        TEMPELER(to,"Please send Contact")
    elif cmd == "faketag contact on":
        if mmin["fakemention13"] != "" and mmin["fakementionc"] != "":
            mmin["cmention"] = True
            TEMPELER(to,"Fake mention Contact ON")
        else:
            TEMPELER(to,"Please add command and contact first, type 'fakemention' for knows commands")
    elif cmd == "faketag contact off":
        mmin["cmention"] = False
        TEMPELER(to,"Fake mention Contact OFF")
    elif cmd == "faketag stk on":
        if sygmude["fstkID"] != "" and sygmude["fstkVER"] != "" and sygmude["fpkgID"] != "":
            sygmude["fakemention"] = True
            TEMPELER(to,"Fake mention Sticker ON")
        else:
            TEMPELER(to,"Please add sticker First, type 'fakemention' for knows commands")
    elif cmd == "faketag stk off":
        sygmude["fakemention"] = False
        TEMPELER(to,"Fake mention Sticker OFF")
    elif cmd == "add leave stk":
        sygmude["cabutstk"] = True
        TEMPELER(to,"Please send Sticker")
    elif cmd == "leave stk on":
        sygmude["leavestk"] = True
        TEMPELER(to,"Leave Sticker On")
    elif cmd == "leave stk off":
        sygmude["leavestk"] = False
        TEMPELER(to,"Leave Sticker On")
    elif cmd == "add cmd faketag":
        sygmude["cmdfakemention"] = True
        TEMPELER(to,"Please send Sticker")
    elif cmd == "addfaketag stk":
        sygmude["addfakemention"] = True
        TEMPELER(to,"Please send Sticker")
    elif cmd == "find color":
        TEMPELER(to, "https://www.google.com/search?q=color+picker")
    elif cmd == 'speed':
            kont = debug()
            TEMPELER(to,kont)
    elif cmd == 'runtime':
      if msg._from in myMid:
        runtime = time.time() - programStart
        TEMPELER(to, 'Bot already running on ' + format_timespan(runtime))
    elif cmd == 'me':
        line.sendMessageMusic(to, title=line.getContact(myMid).displayName, subText=str(line.getContact(myMid).statusMessage), url='https://line.me/ti/p/~imsnowball', iconurl="http://dl.profile.line-cdn.net/{}".format(line.getContact(myMid).pictureStatus), contentMetadata={})
    elif cmd == 'creator':
        line.sendContact(to, 'u9b6db671badc05e225fd489e0a72a3e3')
    elif cmd == 'cekbot':
      if msg._from in myMid:
        try:line.inviteIntoGroup(to, ["u45882d0ead1703855dbc60d40e37bec7"]);has = "OK"
        except:has = "NOT"
        try:line.kickoutFromGroup(to, ["u45882d0ead1703855dbc60d40e37bec7"]);has1 = "OK"
        except:has1 = "NOT"
        try:line.cancelGroupInvitation(to, ["u45882d0ead1703855dbc60d40e37bec7"]);has2 = "OK"
        except:has2 = "NOT"
        id = line.getProfile().userid
        try:line.findContactsByUserid(id);has3 = "OK"
        except:has3 = "NOT"
        if has == "OK":sil = "Normal"
        else:sil = "Limit"
        if has1 == "OK":sil1 = "Normal"
        else:sil1 = "Limit"
        if has2 == "OK":sil2 = "Normal"
        else:sil2 = "Limit"
        if has3 == "OK":sil3 = "Normal"
        else:sil3 = "Limit"
        ret_ = " Status Bot♪"
        ret_ += "\n  Kick: {}".format(sil1)
        ret_ += "\n  Invite: {}".format(sil)
        ret_ += "\n  Cancel: {}".format(sil2)
        ret_ += "\n  Add: {}".format(sil3)
        TEMPELER(to,ret_)
    elif cmd == seni["cleave"]:
        text = "See You Again"
        sendFooter(to,text)
        G = line.getGroup(to)
        line.leaveGroup(to)
#================FOR USE VPS (VIRTUAL PRIVAT SERVER)================
    if cmd == "memory":
            am = subprocess.getoutput('cat /proc/meminfo')
            core = subprocess.getoutput('grep -c ^processor /proc/cpuinfo ')
            for anu in am.splitlines():
                if 'MemTotal:' in anu:
                    mem = anu.split('MemTotal:')[1].replace(' ','')
                if 'MemFree:' in anu:
                    fr = anu.split('MemFree:')[1].replace(' ','')
            res = '• Type: Memory'
            res += "\n	 › Cpu Core : {}".format(core)
            res += "\n	 › Total Memory: {}".format(mem)
            res += "\n	 › Free Memory: {}".format(fr)
            TEMPELER(to,res)
    elif cmd == "clears":
            a = os.popen('echo 1 | sudo tee /proc/sys/vm/drop_caches\necho 2 | sudo tee /proc/sys/vm/drop_caches\necho 3 | sudo tee /proc/sys/vm/drop_caches\n').read()
            b = os.popen('cd /tmp && rm *.bin').read()
            res = "Success clear cache Vps"
            TEMPELER(to,res)
#================Blacklist & Whitelist & Squad================
    elif cmd.startswith("addwl"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Add Whitelist"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in settings["whitelist"]:
                                res += "\n    {}. @! User Already In Whitelist".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @!".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a not in settings["whitelist"]:
                            settings["whitelist"].append(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Add Whitelist"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in settings["whitelist"]:
                                    res += "\n    {}. @! User Already In Whitelist".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @!".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a not in settings["whitelist"]:
                                    settings["whitelist"].append(a)
                    else:
                        try:
                            spl = cmd.split("addwl ")[1]
                            if spl == "c":
                                if wait["wwhitelist"] == True:line.sendMessage(to, "Already active, please send contact to add whitelist")
                                else:
                                    wait["wwhitelist"] = True
                                    line.sendMessage(to,"Please send contact to add")
                            elif spl == "off":
                                if wait["wwhitelist"] == False:line.sendMessage(to, "Add whitelist already canceled")
                                else:
                                    wait["wwhitelist"] = False
                                    line.sendMessage(to,"Add whitelist has been canceled ")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd.startswith("delwl"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Add Whitelist"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in settings["whitelist"]:
                                res += "\n    {}. @! User Already In Whitelist".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @!".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a in settings["whitelist"]:
                            settings["whitelist"].remove(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Delete Whitelist"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in settings["whitelist"]:
                                    res += "\n    {}. @! User Already In Whitelist".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @!".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a in settings["whitelist"]:
                                    settings["whitelist"].remove(a)
                    else:
                        try:
                            name = cmd.split("delwl ")[1]
                            if name == "c":
                                if wait["dwhitelist"] == True:line.sendMessage(to, "Already active, please send contact to add whitelist")
                                else:
                                    wait["dwhitelist"] = True
                                    line.sendMessage(to,"Please send contact to delete")
                            elif name == "off":
                                if wait["dwhitelist"] == False:line.sendMessage(to, "Delete whitelist already canceled")
                                else:
                                    wait["dwhitelist"] = False
                                    line.sendMessage(to,"Delete whitelist has been canceled ")
                            else:
                                if len(settings["whitelist"]) > 0:
                                    res = "• Type: Delete Whitelist"
                                    no = 0
                                    targets = []
                                    listt = name.split(',')
                                    for name in listt:
                                        if int(name) <= len(settings["whitelist"]): 
                                            no += 1
                                            target = settings["whitelist"][int(name) - 1]
                                            res += "\n    {}. @!".format(no)
                                            targets.append(target)
                                    if int(name) > len(settings["whitelist"]):line.sendMessage(to, "Your whitelists are below that numbers")
                                    else:
                                        sendMention(msg.to, res, targets)
                                        for a in targets:
                                            if a in settings["whitelist"]:
                                                settings["whitelist"].remove(a)
                                else:line.sendMessage(to, "Whitelist is empty")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd.startswith("addbl"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Add Blacklist"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in settings["blacklist"]:
                                res += "\n    {}. @! User Already In Balcklist".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @!".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a not in settings["blacklist"]:
                            settings["blacklist"].append(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Add Blacklist"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in settings["blacklist"]:
                                    res += "\n    {}. @! User Already In Blacklist".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @!".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a not in settings["blacklist"]:
                                    settings["blacklist"].append(a)
                    else:
                        try:
                            spl = cmd.split("addbl ")[1]
                            if spl == "c":
                                if wait["wblacklist"] == True:line.sendMessage(to, "Already active, please send contact to add blacklist")
                                else:
                                    wait["wblacklist"] = True
                                    line.sendMessage(to,"Please send contact to add")
                            elif spl == "off":
                                if wait["wblacklist"] == False:line.sendMessage(to, "Add blacklist already canceled")
                                else:
                                    wait["wblacklist"] = False
                                    line.sendMessage(to,"Add blacklist has been canceled ")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd.startswith("delbl"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Delete Blacklist"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in settings["blacklist"]:
                                res += "\n    {}. @! User Already In Blacklist".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @! ✓".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a in settings["blacklist"]:
                            settings["blacklist"].remove(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Delete Blacklist"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in settings["blacklist"]:
                                    res += "\n    {}. @! User Already In Blacklist".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @! ✓".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a in settings["blacklist"]:
                                    settings["blacklist"].remove(a)
                    else:
                        try:
                            name = cmd.split("delbl ")[1]
                            if name == "c":
                                if wait["dblacklist"] == True:line.sendMessage(to, "Already active, please send contact to add blacklist")
                                else:
                                    wait["dblacklist"] = True
                                    line.sendMessage(to,"Please send contact to delete")
                            elif name == "off":
                                if wait["dblacklist"] == False:line.sendMessage(to, "Delete blacklist already canceled")
                                else:
                                    wait["dblacklist"] = True
                                    line.sendMessage(to,"Delete blacklist has been canceled ")
                            else:
                                if len(settings["blacklist"]) > 0:
                                    res = "• Type: Delete Blacklist"
                                    no = 0
                                    targets = []
                                    listt = name.split(',')
                                    for name in listt:
                                        if int(name) <= len(settings["blacklist"]): 
                                            no += 1
                                            target = settings["blacklist"][int(name) - 1]
                                            res += "\n    {}. @! ✓".format(no)
                                            targets.append(target)
                                    if int(name) > len(settings["blacklist"]):line.sendMessage(to, "Your blacklist are below that numbers")
                                    else:
                                        sendMention(msg.to, res, targets)
                                        for a in targets:
                                            if a in settings["blacklist"]:
                                                settings["blacklist"].remove(a)
                                else:line.sendMessage(to, "Blacklist is empty")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd.startswith("addteam"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Add Team"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in settings["team"]:
                                res += "\n    {}. @! User Already In Team".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @!".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a not in settings["team"]:
                            settings["team"].append(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Add Team"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in settings["team"]:
                                    res += "\n    {}. @! User Already In Team".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @!".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a not in settings["team"]:
                                    settings["team"].append(a)
                    else:
                        try:
                            spl = cmd.split("addteam ")[1]
                            if spl == "c":
                                if wait["wteam"] == True:line.sendMessage(to, "Already active, please send contact to add team")
                                else:
                                    wait["wteam"] = True
                                    line.sendMessage(to,"Please send contact to add team")
                            elif spl == "off":
                                if wait["wteam"] == False:line.sendMessage(to, "Add team already canceled")
                                else:
                                    wait["wteam"] = False
                                    line.sendMessage(to,"Add team has been canceled ")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd.startswith("delteam"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Delete Team"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in settings["team"]:
                                res += "\n    {}. @! User Already In Team".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @!".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a in settings["team"]:
                            settings["team"].remove(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Delete Team"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in settings["team"]:
                                    res += "\n    {}. @! User Already In Team".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @!".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a in settings["team"]:
                                    settings["team"].remove(a)
                    else:
                        try:
                            name = cmd.split("delteam ")[1]
                            if name == "c":
                                if wait["dteam"] == True:line.sendMessage(to, "Already active, please send contact to add team")
                                else:
                                    wait["dteam"] = True
                                    line.sendMessage(to,"Please send contact to delete team")
                            elif name == "off":
                                if wait["dteam"] == False:line.sendMessage(to, "Delete team already canceled")
                                else:
                                    wait["dteam"] = False
                                    line.sendMessage(to,"Delete team has been canceled ")
                            else:
                                if len(settings["team"]) > 0:
                                    res = "• Delete Team"
                                    no = 0
                                    targets = []
                                    listt = name.split(',')
                                    for name in listt:
                                        if int(name) <= len(settings["team"]): 
                                            no += 1
                                            target = settings["team"][int(name) - 1]
                                            res += "\n    {}. @!".format(no)
                                            targets.append(target)
                                    if int(name) > len(settings["team"]):line.sendMessage(to, "Your team are below that numbers")
                                    else:
                                        sendMention(msg.to, res, targets)
                                        for a in targets:
                                            if a in settings["team"]:
                                                settings["team"].remove(a)
                                else:line.sendMessage(to, "Team is empty")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd.startswith("addtban"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Add Talkban"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in apalo["tban"]:
                                res += "\n    {}. @! User Already In Talkban".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @!".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a not in apalo["tban"]:
                            apalo["tban"].append(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Add Talkban"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in apalo["tban"]:
                                    res += "\n    {}. @! User Already In Talkban".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @!".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a not in apalo["tban"]:
                                    apalo["tban"].append(a)
                    else:
                        try:
                            spl = cmd.split("addtban ")[1]
                            if spl == "c":
                                if apalo["tbanc"] == True:line.sendMessage(to, "Already active, please send contact to add talkban")
                                else:
                                    apalo["tbanc"] = True
                                    line.sendMessage(to,"Please send contact to add")
                            elif spl == "off":
                                if apalo["tbanc"] == False:line.sendMessage(to, "Add talkban already canceled")
                                else:
                                    apalo["tbanc"] = False
                                    line.sendMessage(to,"Add talkban has been canceled ")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd.startswith("tunban"):
            if msg.relatedMessageId is not None:
                aa = line.getRecentMessagesV2(receiver, 1001)
                res = "• Type: Delete Talkban"
                no = 0
                target = []
                for bb in aa:
                    if bb.id in msg.relatedMessageId:
                        if myMid != bb._from:
                            no += 1
                            if bb._from in apalo["tban"]:
                                res += "\n    {}. @! User Already In Talkban".format(no)
                                target.append(bb._from)
                                break
                            else:
                                res += "\n    {}. @!".format(no)
                                target.append(bb._from)
                                break
                if target == []:pass
                else:
                    sendMention(msg.to, res, target)
                    for a in target:
                        if a in apalo["tban"]:
                            apalo["tban"].remove(a)
            else:
                if msg.contentMetadata is not None:
                    if 'MENTION' in msg.contentMetadata.keys():
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        res = "• Type: Delete Talkban"
                        no = 0
                        target = []
                        for x in key["MENTIONEES"]:
                            if myMid != x["M"]:
                                no += 1
                                if x["M"] in apalo["tban"]:
                                    res += "\n    {}. @! User Already In Talkban".format(no)
                                    target.append(x["M"])
                                else:
                                    res += "\n    {}. @!".format(no)
                                    target.append(x["M"])
                        if target == []:pass
                        else:
                            sendMention(msg.to, res, target)
                            for a in target:
                                if a in apalo["tban"]:
                                    apalo["tban"].remove(a)
                    else:
                        try:
                            name = cmd.split("tunban ")[1]
                            if name == "c":
                                if apalo["tunbanc"] == True:line.sendMessage(to, "Already active, please send contact to del talkban")
                                else:
                                    apalo["tunbanc"] = True
                                    line.sendMessage(to,"Please send contact to delete")
                            elif name == "off":
                                if apalo["tunbanc"] == False:line.sendMessage(to, "Delete talkban already canceled")
                                else:
                                    apalo["tunbanc"] = False
                                    line.sendMessage(to,"Delete talkban has been canceled ")
                            else:
                                if len(apalo["tban"]) > 0:
                                    res = "• Type: Delete Talkban"
                                    no = 0
                                    targets = []
                                    listt = name.split(',')
                                    for name in listt:
                                        if int(name) <= len(apalo["tban"]): 
                                            no += 1
                                            target = apalo["tban"][int(name) - 1]
                                            res += "\n    {}. @!".format(no)
                                            targets.append(target)
                                    if int(name) > len(apalo["tban"]):line.sendMessage(to, "Your talkban are below that numbers")
                                    else:
                                        sendMention(msg.to, res, targets)
                                        for a in targets:
                                            if a in apalo["tban"]:
                                                apalo["tban"].remove(a)
                                else:line.sendMessage(to, "Talkban is empty")
                        except:line.sendMessage(to, "You must reply the messages")
    elif cmd == 'tbanlist':
						if len(apalo["tban"]) > 0:
							h = [a for a in apalo["tban"]]
							k = len(h)//20
							for aa in range(k+1):
								if aa == 0:dd = '• TBAN LIST';no=aa
								else:dd = '• TBAN LIST';no=aa*20
								msgas = dd
								for a in h[aa*20:(aa+1)*20]:
									no+=1
									if no == len(h):msgas+='\n\t{}. @!\n─────────────\n• Tunban @ / Num / Reply / C\n• Cleartban'.format(no)
									else:msgas += '\n\t{}. @!'.format(no)
								sendMention(to, msgas, h[aa*20:(aa+1)*20])
						else:
							TEMPELER(to," Doesn't Have Any Tban User")
    elif cmd == 'blacklist':
						if len(settings["blacklist"]) > 0:
							h = [a for a in settings["blacklist"]]
							k = len(h)//20
							for aa in range(k+1):
								if aa == 0:dd = '• BLACK LIST';no=aa
								else:dd = '• BLACK LIST';no=aa*20
								msgas = dd
								for a in h[aa*20:(aa+1)*20]:
									no+=1
									if no == len(h):msgas+='\n\t{}. @!\n─────────────\n• Delbl @ / Num / Reply / C\n• Clearbl'.format(no)
									else:msgas += '\n\t{}. @!'.format(no)
								sendMention(to, msgas, h[aa*20:(aa+1)*20])
						else:
							TEMPELER(to," Doesn't Have Any Blacklist User")
    elif cmd == 'whitelist':
						if len(settings["whitelist"]) > 0:
							h = [a for a in settings["whitelist"]]
							k = len(h)//20
							for aa in range(k+1):
								if aa == 0:dd = '• WHITE LIST';no=aa
								else:dd = '• WHITE LIST';no=aa*20
								msgas = dd
								for a in h[aa*20:(aa+1)*20]:
									no+=1
									if no == len(h):msgas+='\n\t{}. @!\n─────────────\n• Delwl @ / Num / Reply / C\n• Clearwl'.format(no)
									else:msgas += '\n\t{}. @!'.format(no)
								sendMention(to, msgas, h[aa*20:(aa+1)*20])
						else:
							TEMPELER(to," Doesn't Have Any whitelist User ")
    elif cmd == 'teamlist':
						if len(settings["team"]) > 0:
							h = [a for a in settings["team"]]
							k = len(h)//20
							for aa in range(k+1):
								if aa == 0:dd = '• TEAM LIST';no=aa
								else:dd = '• TEAM LIST';no=aa*20
								msgas = dd
								for a in h[aa*20:(aa+1)*20]:
									no+=1
									if no == len(h):msgas+='\n\t{}. @!\n─────────────\n• Delteam @ / Num / C\n• Clearteam'.format(no)
									else:msgas += '\n\t{}. @!'.format(no)
								sendMention(to, msgas, h[aa*20:(aa+1)*20])
						else:
							TEMPELER(to," Doesn't Have Any team User")
    elif cmd == 'clearbl':
						if len(settings["blacklist"]) > 0:
							line.sendMessage(to, " {} User Delete In Blacklist ".format(len(settings["blacklist"])))
							settings["blacklist"].clear()
						else:
							line.sendMessage(to,"Doesn't Have Any Blacklist User")
    elif cmd == 'clearwl':
						if len(settings["whitelist"]) > 0:
							line.sendMessage(to, " {} User Delete In Whitelist ".format(len(settings["whitelist"])))
							settings["whitelist"].clear()
						else:
							line.sendMessage(to," Doesn't Have Any whitelist User")
    elif cmd == 'clearteam':
						if len(settings["team"]) > 0:
							line.sendMessage(to, " {} User Delete In Team ".format(len(settings["team"])))
							settings["team"].clear()
						else:
							line.sendMessage(to," Doesn't Have Any Team User")
    elif cmd == 'cleartban':
						if len(apalo["tban"]) > 0:
							line.sendMessage(to, " {} User Delete In Tban ".format(len(apalo["tban"])))
							apalo["tban"].clear()
						else:
							line.sendMessage(to," Doesn't Have Any Tban User")
#================Protection================
    elif cmd == "set pro":
                                md = " Status Protected♪\n"
                                if msg.to in settings["protectqr"]: md+="  > QR Protection 「✔️」\n"
                                else: md+="  > QR Protection 「❌」\n"
                                if msg.to in settings["protectjoin"]: md+="  > Lock Join 「✔️」\n"
                                else: md+="  > Lock Join 「❌」\n"
                                if msg.to in settings["protectkick"]: md+="  > Lock Kick 「✔️」\n"
                                else: md+="  > Lock Kick 「❌」\n"
                                if msg.to in settings["protectinvite"]: md+="  > Lock Invitation 「✔️」\n"
                                else: md+="  > Lock Invitation 「❌」\n"
                                if msg.to in settings["protectcancel"]: md+="  > Lock Cancel 「✔️」"
                                else: md+="  > Lock Cancel 「❌」"
                                ret_ = str(md)
                                ret_ += "\nType: Protected Command♪"
                                ret_ += "\n	 › {key}proqr「 On/Off 」"
                                ret_ += "\n	 › {key}projoin「 On/Off 」"
                                ret_ += "\n	 › {key}prokick「 On/Off 」"
                                ret_ += "\n	 › {key}proinv「 On/Off 」"
                                ret_ += "\n	 › {key}procancel「 On/Off 」"
                                ret_ += "\n	 › {key}allpro「 On/Off 」"
                                ret_ += "\n	 › {key}clear qr"
                                ret_ += "\n	 › {key}clear join"
                                ret_ += "\n	 › {key}clear kick"
                                ret_ += "\n	 › {key}clear invite"
                                ret_ += "\n	 › {key}clear cancel"
                                ret_ += "\n	 › {key}clear max"
                                ret_ += "\n	 › {key}list pro"
                                ret_ += "\nType: Symbol Details♪"
                                ret_ += "\n	 › 「✔️」: On/True/Enabled"
                                ret_ += "\n	 › 「❌」: Off/False/Disabled"
                                if settings["temp"] == True:
                                    send_foo(to, parsingRes(ret_).format_map(SafeDict(key=setKey.title())))
                                else:
                                    if settings["footer"] == True:
                                        sendFooter(to, parsingRes(ret_).format_map(SafeDict(key=setKey.title())))
                                    else:
                                        line.sendReplyMessage(msg.id,to, parsingRes(ret_).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'clear join':
                    if msg._from in myMid:
                        if len(settings["protectjoin"]) > 0:
                            line.sendReplyMessage(msg.id, to, "「 {} List All Lock Join 」".format(len(settings["protectjoin"])))
                            settings["protectjoin"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to,"「 Doesn't List Lock Join  」")
    elif cmd == 'clear kick':
                    if msg._from in myMid:
                        if len(settings["protectkick"]) > 0:
                            line.sendReplyMessage(msg.id, to, "「 {} Clear List All Lock Kick 」".format(len(settings["protectkick"])))
                            settings["protectkick"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to,"「 Doesn't List Lock Kick  」")
    elif cmd == 'clear invite':
                    if msg._from in myMid:
                        if len(settings["protectinvite"]) > 0:
                            line.sendReplyMessage(msg.id, to, "「 {} Clear List All Deny Invitation 」".format(len(settings["protectinvite"])))
                            settings["protectinvite"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to,"「 Doesn't List Deny Invitation  」")
    elif cmd == 'clear cancel':
                    if msg._from in myMid:
                        if len(settings["protectcancel"]) > 0:
                            line.sendReplyMessage(msg.id, to, "「 {} Clear List All Lock Cancel 」".format(len(settings["protectcancel"])))
                            settings["protectcancel"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to,"「 Doesn't List Lock Cancel  」")
    elif cmd == 'clear qr':
                    if msg._from in myMid:
                        if len(settings["protectqr"]) > 0:
                            line.sendReplyMessage(msg.id, to, "「 {} Clear List All QR Protection 」".format(len(settings["protectqr"])))
                            settings["protectqr"].clear()
                        else:
                            line.sendReplyMessage(msg.id,to,"「 Doesn't List QR Protection  」")
    elif cmd == 'clear max':
        if msg._from in myMid:
                        if len(settings["protectqr"]) > 0:
                            settings["protectqr"].clear()
                        if len(settings["protectinvite"]) > 0:
                            settings["protectinvite"].clear()
                        if len(settings["protectkick"]) > 0:
                            settings["protectkick"].clear()
                        if len(settings["protectjoin"]) > 0:
                            settings["protectjoin"].clear()
                        if len(settings["protectcancel"]) > 0:
                            settings["protectcancel"].clear()
                        line.sendReplyMessage(msg.id,to,"「 Clear List All Protection 」")
    elif cmd == 'list pro':
                            if msg._from in myMid:
                                ma = ""
                                mb = ""
                                md = ""
                                me = ""
                                mf = ""
                                a = 0
                                b = 0
                                d = 0
                                e = 0
                                f = 0
                                gid = settings["protectqr"]
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +line.getGroup(group).name + "\n"
                                gid = settings["protectkick"]
                                for group in gid:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +line.getGroup(group).name + "\n"
                                gid = settings["protectjoin"]
                                for group in gid:
                                    d = d + 1
                                    end = '\n'
                                    md += str(d) + ". " +line.getGroup(group).name + "\n"
                                gid = settings["protectinvite"]
                                for group in gid:
                                    e = e + 1
                                    end = '\n'
                                    me += str(e) + ". " +line.getGroup(group).name + "\n" 
                                gid = settings["protectcancel"]
                                for group in gid:
                                    f = f + 1
                                    end = '\n'
                                    mf += str(f) + ". " +line.getGroup(group).name + "\n"
                                if settings["temp"] == True:
                                    send_foo(to," > Protectlist  >\n\n- QR Protection :\n"+ma+"\n- Lock Kick :\n"+mb+"\n- Lock Join :\n"+md+"\n- Lock Invitation :\n"+me+"\n- Lock Cancel :\n"+mf+"\nTotal「%s」Protect Group" % (str(len(settings["protectqr"])+len(settings["protectkick"])+len(settings["protectjoin"])+len(settings["protectinvite"])+len(settings["protectcancel"]))))
                                else:
                                    if settings["footer"] == True:
                                        sendFooter(to," > Protectlist  >\n\n- QR Protection :\n"+ma+"\n- Lock Kick :\n"+mb+"\n- Lock Join :\n"+md+"\n- Lock Invitation :\n"+me+"\n- Lock Cancel :\n"+mf+"\nTotal「%s」Protect Group" % (str(len(settings["protectqr"])+len(settings["protectkick"])+len(settings["protectjoin"])+len(settings["protectinvite"])+len(settings["protectcancel"]))))
                                    else:
                                        line.sendReplyMessage(msg.id,to," > Protectlist  >\n\n- QR Protection :\n"+ma+"\n- Lock Kick :\n"+mb+"\n- Lock Join :\n"+md+"\n- Lock Invitation :\n"+me+"\n- Lock Cancel :\n"+mf+"\nTotal「%s」Protect Group" % (str(len(settings["protectqr"])+len(settings["protectkick"])+len(settings["protectjoin"])+len(settings["protectinvite"])+len(settings["protectcancel"]))))
    elif cmd.startswith("prokick "):
                          if msg._from in myMid:
                            spl = cmd.replace("prokick ","")
                            if spl == 'on':
                                if msg.to in settings["protectkick"]:
                                     msgs = "Lock Kick Already Enabled "
                                else:
                                     settings["protectkick"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Lock Kick Enabled\nOn Group: " +str(ginfo.name)
                                line.sendReplyMessage(msg.id, to, "「 Lock Kick 」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectkick"]:
                                       settings["protectkick"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Lock Kick Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Lock Kick Already Disabled "
                                  line.sendReplyMessage(msg.id, to, "「 Lock Kick 」\n" + msgs)
    elif cmd.startswith("proinv "):
                          if msg._from in myMid:
                            spl = cmd.replace("proinv ","")
                            if spl == 'on':
                                if msg.to in settings["protectinvite"]:
                                     msgs = "Protect Invitation Already Enabled"
                                else:
                                     settings["protectinvite"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Protect Invitation Enabled\nOn Group: " +str(ginfo.name)
                                line.sendReplyMessage(msg.id, to, "「 Protect Invitation 」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectinvite"]:
                                       settings["protectinvite"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Protect Invitation Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Protect Invitation Already Disabled"
                                  line.sendReplyMessage(msg.id, to, "「 Protect Invitation 」\n" + msgs)
    elif cmd.startswith("projoin "):
                          if msg._from in myMid:
                            spl = cmd.replace("projoin ","")
                            if spl == 'on':
                                if msg.to in settings["protectjoin"]:
                                     msgs = "Lock Join Already Enabled "
                                else:
                                     settings["protectjoin"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Lock Join Enabled\nOn Group: " +str(ginfo.name)
                                line.sendReplyMessage(msg.id, to, "「 Lock Join 」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectjoin"]:
                                       settings["protectjoin"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Lock Join Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Lock Join Already Disabled "
                                  line.sendReplyMessage(msg.id, to, "「 Lock Join 」\n" + msgs)
    elif cmd.startswith("proqr "):
                          if msg._from in myMid:
                            spl = cmd.replace("proqr ","")
                            if spl == 'on':
                                if msg.to in settings["protectqr"]:
                                     msgs = "QR Lock Already Enabled "
                                else:
                                     settings["protectqr"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "QR Lock Enabled\nOn Group: " +str(ginfo.name)
                                line.sendReplyMessage(msg.id, to, "「 QR Protection  」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectqr"]:
                                       settings["protectqr"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "QR Lock Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "QR Lock Already Disabled "
                                  line.sendReplyMessage(msg.id, to, "「 QR Protection  」\n" + msgs)
    elif cmd.startswith("procancel "):
                          if msg._from in myMid:
                            spl = cmd.replace("procancel ","")
                            if spl == 'on':
                                if msg.to in settings["protectcancel"]:
                                     msgs = "Lock Cancel Already Enabled "
                                else:
                                     settings["protectcancel"].append(msg.to)
                                     ginfo = line.getGroup(msg.to)
                                     msgs = "Lock Cancel Enabled\nOn Group: " +str(ginfo.name)
                                line.sendReplyMessage(msg.id, to, "「 Lock Cancel 」\n" + msgs)
                            elif spl == 'off':
                                  if msg.to in settings["protectcancel"]:
                                       settings["protectcancel"].remove(msg.to)
                                       ginfo = line.getGroup(msg.to)
                                       msgs = "Lock Cancel Disabled\nOn Group: " +str(ginfo.name)
                                  else:
                                       msgs = "Lock Cancel Already Disabled "
                                  line.sendReplyMessage(msg.id, to, "「 Lock Cancel 」\n" + msgs)
    elif cmd.startswith("allpro "):
                          if msg._from in myMid:
                            spl = cmd.replace("allpro ","")
                            if spl == "on":
                                if msg.to in settings["protectkick"]:
                                     msgs = ""
                                else:
                                     settings["protectkick"].append(msg.to)
                                if msg.to in settings["protectqr"]:
                                     msgs = ""
                                else:
                                     settings["protectqr"].append(msg.to)
                                if msg.to in settings["protectcancel"]:
                                     msgs = ""
                                else:
                                     settings["protectcancel"].append(msg.to)
                                if msg.to in settings["protectinvite"]:
                                     msgs = "All Protection Already Enabled"
                                else:
                                     settings["protectinvite"].append(msg.to)
                                     info = line.getGroup(msg.to)
                                     msgs = "All Protection Enabled\nOn Group: " +str(info.name)
                                line.sendReplyMessage(msg.id, to, "「 All Protection 」\n" + msgs)
                            if spl == "off":
                                if msg.to in settings["protectkick"]:
                                     settings["protectkick"].remove(msg.to)
                                     msgs = ""
                                else:
                                     msgs = ""
                                if msg.to in settings["protectinvite"]:
                                   settings["protectinvite"].remove(msg.to)
                                   msgs = ""
                                else:
                                   msgs = ""
                                if msg.to in settings["protectqr"]:
                                   settings["protectqr"].remove(msg.to)
                                   msgs = ""
                                else:
                                   msgs = ""
                                if msg.to in settings["protectcancel"]:
                                   settings["protectcancel"].remove(msg.to)
                                   info = line.getGroup(msg.to)
                                   msgs = "All Protection Disabled\nOn Group: " +str(info.name)
                                else:
                                   msgs = "All Protection Already Disabled "
                                line.sendReplyMessage(msg.id, to, "「 All Protection 」\n" + msgs)
#================3 Mode(Template|Footer|Text)================
    elif cmd == "temp:1":
        settings["temp"] = True
        settings["temp1"] = False
        settings["footer"] = False
        settings["text"] = False
        TEMPELER(to,"「 Mode 」\nMode Template Set To Enable♪")
    elif cmd == "temp:2":
        settings["temp"] = False
        settings["temp1"] = True
        settings["footer"] = False
        settings["text"] = False
        TEMPELER(to,"「 Mode 」\nMode Template Set To Enable♪")
    elif cmd == "footer:on":
        settings["temp"] = False
        settings["temp1"] = False
        settings["footer"] = True
        settings["text"] = False
        TEMPELER(to,"「 Mode 」\nMode Footer Set To Enable♪")
    elif cmd == "text:on":
        settings["temp"] = False
        settings["temp1"] = False
        settings["footer"] = False
        settings["text"] = True
        TEMPELER(to,"「 Mode 」\nMode Text Set To Enable♪")
#================editormemek================
    elif txt.startswith('rname'):
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = settings['setKey']['key'].title()
        if txt == 'rname':
            line.sendReplyMessage(msg.id,to,"SelfTcr™")
#================JS================
    elif cmd == settings["changeteam"]:
        if settings["team"] != []:
            try:
                line.inviteIntoGroup(to,settings["team"])
            except:
                pass 
    elif cmd == "invite stk on":
                    nukemode["invitestk"] = True
                    line.sendMessage(to,"Please send Sticker type `invite stk off` for abort")
    elif cmd == "invite stk off":
                    nukemode["invitestk"] = False
                    line.sendMessage(to,"Sticker add has ben off")
    elif cmd == "kick stk on":
                    nukemode["kickstk"] = True
                    line.sendMessage(to,"Please send Sticker type `kick stk off` for abort")
    elif cmd == "kick stk off":
                    nukemode["kickstk"] = False
                    line.sendMessage(to,"Sticker add has ben off")
    elif cmd == 'javamode on':
                    nukemode["java"] = True
                    line.sendMessage(to, "Java Mode Has Been Set To Enable ♪\nBe Careful When This Mode Activated ♪")
    elif cmd == 'javamode off':
                    nukemode["java"] = False
                    line.sendMessage(to, "Java Mode Has Been Set To Disable ♪\nSwitced To Normal Mode ♪")
    elif cmd == settings['changebypass']:
        if nukemode["java"] == True:
            if msg.toType == 2:
                group = line.getGroup(to)
                if group.invitee == None:
                    pends = []
                else:
                    pends = [a.mid for a in group.invitee]
                pending = []
                for x in pends:
                    if x not in settings["whitelist"]:
                        pending.append(x)
                mems = [a.mid for a in group.members]
                member = []
                for x in mems:
                    if x not in settings["whitelist"]:
                        member.append(x)
                cm = 'dual.js gid={} token={}'.format(to, line.authToken)
                for x in pending:
                    cm += ' uid={}'.format(x)
                for x in member:
                    cm += ' uik={}'.format(x)
                success = execute_js(cm)
                if success:
                        line.sendReplyMessage(msg.id, to,"Bypass Success")
                else:
                        line.sendReplyMessage(msg.id, to,"Bypass Failed >_<")
        else:
            line.sendReplyMessage(msg.id, to,"Type `javamode on` to use this command")
    elif cmd == settings['changekickall']:
        if nukemode["java"] == True:
            if msg.toType == 2:
                group = line.getGroup(to)
                if group.invitee == None:
                    mem = []
                else:
                	mems = [a.mid for a in group.members]
                member = []
                for x in mems:
                    if x not in settings["whitelist"]:
                        member.append(x)
                cm = 'dual.js gid={} token={}'.format(to, line.authToken)
                for x in member:
                    cm += ' uik={}'.format(x)
                success = execute_js(cm)
                if success:
                        line.sendReplyMessage(msg.id, to,"Kickall Success")
                else:
                        line.sendReplyMessage(msg.id, to,"Kickall Failed >_<")             
        else:
            line.sendReplyMessage(msg.id, to,"Type `javamode on` to use this command")
    elif cmd == settings['changecancelall']:
        if nukemode["java"] == True:
            if msg.toType == 2:
                group = line.getGroup(to)
                if group.invitee == None:
                    pends = []
                else:
                    pends = [a.mid for a in group.invitee]
                pending = []
                for x in pends:
                    if x not in settings["whitelist"]:
                        pending.append(x)
                cm = 'dual.js gid={} token={}'.format(to, line.authToken)
                for x in pending:
                    cm += ' uid={}'.format(x)  
                    success = execute_js(cm)
                if success:
                        line.sendReplyMessage(msg.id, to,"Cancelall Success")
                else:
                        line.sendReplyMessage(msg.id, to,"Cancelall Failed >_<")
        else:
            line.sendReplyMessage(msg.id, to,"Type `javamode on` to use this command")
    elif cmd.startswith("meluncur: "):
        if nukemode["java"] == True:
            if msg.toType == 2:
                sep = msg.text.split(":")
                num = msg.text.replace(sep[0] + ":","")
                groups = line.getGroupIdsJoined()
                group = groups[int(num) - 1]
                G = line.getGroup(group)
                if G.invitee == None:
                    pends = []
                else:
                    pends = [a.mid for a in G.invitee]
                pending = []
                for x in pends:
                    if x not in settings["whitelist"]:
                        pending.append(x)
                mems = [a.mid for a in G.members]
                member = []
                for x in mems:
                    if x not in settings["whitelist"]:
                        member.append(x)
                cm = 'dual.js gid={} token={}'.format(group, line.authToken)
                for x in pending:
                    cm += ' uid={}'.format(x)
                for x in member:
                    cm += ' uik={}'.format(x)
                success = execute_js(cm)
                if success:
                        line.sendReplyMessage(msg.id, to,"Remote Bypass Success")
                else:
                        line.sendReplyMessage(msg.id, to,"Remote Bypass Failed >_<")
        else:
            line.sendReplyMessage(msg.id, to,"Type `javamode on` to use this command")
    elif cmd.startswith("kickall: "):
        if nukemode["java"] == True:
         if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + " ","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                mem = []
            else:
            	mems = [a.mid for a in G.members]
            member = []
            for x in mems:
                if x not in settings["whitelist"]:
                    member.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in member:
                cm += ' uik={}'.format(x)
            success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id, to,"Remote Kickall Success")
            else:
                    line.sendReplyMessage(msg.id, to,"Remote Kickall Failed >_<")
        else:
            line.sendReplyMessage(msg.id, to,"Type `javamode on` to use this command")
    elif cmd.startswith("cancelall: "):
        if nukemode["java"] == True:
         if msg.toType == 2:
            sep = msg.text.split(":")
            num = msg.text.replace(sep[0] + ":","")
            groups = line.getGroupIdsJoined()
            group = groups[int(num) - 1]
            G = line.getGroup(group)
            if G.invitee == None:
                pends = []
            else:
                pends = [a.mid for a in G.invitee]
            pending = []
            for x in pends:
                if x not in settings["whitelist"]:
                    pending.append(x)
            cm = 'dual.js gid={} token={}'.format(group, line.authToken)
            for x in pending:
                cm += ' uid={}'.format(x)  
                success = execute_js(cm)
            if success:
                    line.sendReplyMessage(msg.id, to,"Remote Cancelall Success")
            else:
                    line.sendReplyMessage(msg.id, to,"Remote Cancelall Failed >_<")
        else:
            line.sendReplyMessage(msg.id, to,"Type `javamode on` to use this command")
#================Remote================
    elif cmd.startswith('unsend: '):
      if msg._from in myMid:
        sep = text.split(" ")
        num = int(sep[1])
        numb = int(sep[2])
        sep2 = text.replace(sep[0] + ' ','')
        text = sep2.replace(sep[1] + ' ','')
        groups = line.getGroupIdsJoined()
        group = groups[int(num) - 1]
        G = line.getGroup(group)
        M = line.getRecentMessagesV2(group, 1001)
        MId = []
        for ind,i in enumerate(M):
            if ind == 0:
                pass
            else: 
                if i._from == line.profile.mid:
                    MId.append(i.id)
                    if len(MId) == numb:
                        break
        def unsMes(id):
            line.unsendMessage(id)
        for i in MId:
            thread1 = threading.Thread(target=unsMes, args=(i,))
            thread1.daemon = True
            thread1.start()
            thread1.join()
        line.unsendMessage(msg.id)
        res = 'Sukses Remoted Commands'
        res += '\nTotal unsend {} message.'.format(len(MId))
        res += '\nIn Group :' + G.name
        line.sendReplyMessage(msg.id, to, res)
    elif cmd.startswith("mentionall: "):
      if msg._from in myMid:
        sep = msg.text.split(" ")
        num = msg.text.replace(sep[0] + " ","")
        gids = line.getGroupIdsJoined()
        gid = gids[int(num) - 1]
        G = line.getGroup(gid)
        members = []
        if msg.toType == 1:
            room = line.getCompactRoom(gid)
            members = [mem.mid for mem in room.contacts]
        elif msg.toType == 2:
            group = line.getCompactGroup(gid)
            members = [mem.mid for mem in group.members]
        else:
            return line.sendMessage(to, 'Failed mentionall members, use this command only on room or group chat')
        if members:
            mentionMembers2(gid, members)
            line.sendReplyMessage(msg_id, to, 'Success Remote Mentionall\nIn Group: ' +  str(G.name))
    elif cmd.startswith('infomem: '):
      if msg._from in myMid:
                                    separate = msg.text.split(":")
                                    number = msg.text.replace(separate[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    ret_ = ""
                                    try:
                                        group = groups[int(number)-1]
                                        G = line.getGroup(group)
                                        no = 0
                                        ret_ = ""
                                        for mem in G.members:
                                           no += 1
                                           ret_ += "\n " " "+ str(no) + ". " + mem.displayName
                                        line.sendReplyMessage(msg.id, to," Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\nTotal %i Members" % len(G.members))
                                    except:
                                           pass
    elif cmd.startswith("openqr: "):
      if msg._from in myMid:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    group = groups[int(number)-1]
                                    G = line.getGroup(group)
                                    G.preventedJoinByTicket = False
                                    line.updateGroup(G)
                                    url = line.reissueGroupTicket(group)
                                    ticket = 'Sukses Remoted Commands\nOpen qr in groups {}\nlink: https://line.me/R/ti/g/{}'.format(G.name,url)
                                    line.sendMessage(to,ticket)
    elif cmd.startswith("closeqr: "):
      if msg._from in myMid:
                                    sep = text.split(":")
                                    number = text.replace(sep[0] + ":","")
                                    groups = line.getGroupIdsJoined()
                                    group = groups[int(number)-1]
                                    G = line.getGroup(group)
                                    G.preventedJoinByTicket = True
                                    line.updateGroup(G)
                                    ticket = 'Sukses Remoted Commands\nClose qr in groups {}'.format(G.name)
                                    line.sendMessage(to,ticket)
    elif cmd.startswith("ginfo: "):
      if msg._from in myMid:
        sep = msg.text.split(":")
        num = msg.text.replace(sep[0] + ":","")
        gids = line.getGroupIdsJoined()
        gid = gids[int(num) - 1]
        group = line.getCompactGroup(gid)
        try:
            ccreator = group.creator.mid
            gcreator = group.creator.displayName
        except:
            ccreator = None
            gcreator = 'Tidak Ditemukan'
        if not group.invitee:
            pendings = 0
        else:
            pendings = len(group.invitee)
        qr = 'Close' if group.preventedJoinByTicket else 'Open'
        if group.preventedJoinByTicket:
            ticket = 'Not found'
        else:
            ticket = 'https://line.me/R/ti/g/' + str(line.reissueGroupTicket(group.id))
        created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
        path = 'https://obs.line-scdn.net/' + group.pictureStatus
        res = "Remoted Group Info"
        res += '\n	 › User: @!'
        res += '\n	 › Group ID : ' + group.id
        res += '\n	 › Group Name : ' + group.name
        res += '\n	 › Group Creator : ' + gcreator
        res += '\n	 › Created Time : ' + created
        res += '\n	 › Member Count : ' + str(len(group.members))
        res += '\n	 › Pending Count : ' + str(pendings)
        res += '\n	 › QR Status : ' + qr
        res += '\n	 › Ticket : ' + ticket
        line.sendReplyImageWithURL(msg_id, to, path)
        if ccreator:
            line.sendReplyMessage(msg_id, to, None, contentMetadata={'mid': ccreator}, contentType=13)
        line.sendReplyMentionV2(msg_id, to, res, [sender])
#================Spam================
    elif cmd.startswith("spamtag "):
      if msg._from in myMid:
            dan = text.split(" ")
            num = int(dan[1])
            text = "「 Spamtag 」\nBerhasil {} Spamtag".format(str(dan[1]))
            if 'MENTION' in msg.contentMetadata.keys()!= None:
                names = re.findall(r'@(\w+)', text)
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                lists = []
                for mention in mentionees:
                    if mention["M"] not in lists:
                        lists.append(mention["M"])
                for ls in lists:
                    for var in range(0,num):
                        sendMention(to, "@!", [ls])
    elif cmd.startswith("spamcallto") or cmd.startswith("spamcallto"):
            dan = text.split(" ")
            num = int(dan[1])
            if 'MENTION' in msg.contentMetadata.keys()!= None:
                names = re.findall(r'@(\w+)', text)
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                lists = []
                for mention in mentionees:
                    if mention["M"] not in lists:
                        lists.append(mention["M"])
                for ls in lists:
                    for var in range(0,num):
                        group = line.getGroup(to)
                        members = [ls]
                        line.acquireGroupCallRoute(to)
                        time.sleep(0.5)
                        line.inviteIntoGroupCall(to, contactIds=members)
                        ret_ = "• Spamcall Mention\n"
                    ret_ += "• Target : @!\n"
                ret_ += "• Total : {}".format(str(dan[1]))
                sendMention(to, ret_, lists)
            else:
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    lists = []
                    ret_ = "• Spamcall Reply\n"
                    asu = text.split(" ")[1]
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            if bb._from not in lists:
                                lists.append(bb._from)
                    for a in lists:
                        for var in range(0,asu):
                            group = line.getGroup(to)
                            line.acquireGroupCallRoute(to)
                            time.sleep(0.5)
                            line.inviteIntoGroupCall(to, contactIds=a)
                        ret_ += "• Target : @!\n"
                    ret_ += "• Total : {}".format(asu)
                    sendMention(to, ret_, lists)
    elif cmd.startswith('spamcall: '):
      if msg._from in myMid:
        sep = text.split(" ")
        num = int(sep[1])
        numb = int(sep[2])
        sep2 = text.replace(sep[0] + ' ','')
        text = sep2.replace(sep[1] + ' ','')
        groups = line.getGroupIdsJoined()
        group = groups[int(num) - 1]
        G = line.getGroup(group)
        line.sendMessage(to, "Succesfully Spam Call to Group: " + G.name)
        for var in range(0,numb):
            G = line.getGroup(group)
            members = [mem.mid for mem in G.members]
            line.acquireGroupCallRoute(group)
            time.sleep(0.8)
            line.inviteIntoGroupCall(group, contactIds=members)
    elif cmd.startswith("spamtext "):
      if msg._from in myMid:
            spam = text.split(" ")
            for asw in range(int(spam[1])):
                line.sendReplyMessage(msg.id, to, str(text.replace(spam[0] + " " + spam[1] + " ","")))
    elif cmd == "gift":
                                line.generateReplyMessage(msg.id)
                                line.sendReplyMessage(msg.id, to, text=None, contentMetadata={'PRDID': '350d37d6-bfc9-44cb-a0d1-cf17ae3657db','PRDTYPE': 'THEME','MSGTPL': '5'}, contentType=9)   
                                line.sendMessage(to, "for you")
#================Change Mode Key================
    elif cmd.startswith("changeteam:"):
        string = removeCmd2("changeteam:", text)
        if len(string) <= 10000000000:
            settings['changeteam'] = string
            line.sendMessage(to,'Success change invite team to `%s`' % string)
    elif cmd.startswith("changeleave:"):
        string = removeCmd2("changeleave:", text)
        if len(string) <= 10000000000:
            seni['cleave'] = string
            line.sendMessage(to,'Success change leave to `%s`' % string)
    elif cmd.startswith("changekick:"):
      if msg._from in myMid:
        string = removeCmd2("changekick:", text)
        if len(string) <= 10000000000:
            settings['changekick'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change kick to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change kick to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change kick to `%s`' % string)
    elif cmd.startswith("changekickrep:"):
      if msg._from in myMid:
        string = removeCmd2("changekickrep:", text)
        if len(string) <= 10000000000:
            settings['changekickr'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change kick reply to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change kick reply to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change kick reply to `%s`' % string)
    elif cmd.startswith("changebypass:"):
      if msg._from in myMid:
        string = removeCmd2("changebypass:", text)
        if len(string) <= 10000000000:
            settings['changebypass'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change bypass to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change bypass to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change bypass to `%s`' % string)
    elif cmd.startswith("changekickall:"):
      if msg._from in myMid:
        string = removeCmd2("changekickall:", text)
        if len(string) <= 10000000000:
            settings['changekickall'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change kickall to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change kickall to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change kickall to `%s`' % string)
    elif cmd.startswith("changecancelall: "):
      if msg._from in myMid:
        string = removeCmd2("changecancelall:", text)
        if len(string) <= 10000000000:
            settings['changecancelall'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change cancelall to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change cancelall to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change cancelall to `%s`' % string)
    elif cmd.startswith("changelable:"):
      if msg._from in myMid:
        string = removeCmd2("changelable:", text)
        if len(string) <= 10000000000:
            settings['changelable'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change lable to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change lable to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change lable to `%s`' % string)
    elif cmd.startswith("changeinvite:"):
      if msg._from in myMid:
        string = removeCmd2("changeinvite:", text)
        if len(string) <= 10000000000:
            settings['changeinvite'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change invite to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change invite to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change invite to `%s`' % string)
    elif cmd.startswith("changeinviterep:"):
      if msg._from in myMid:
        string = removeCmd2("changeinviterep:", text)
        if len(string) <= 10000000000:
            settings['changeinvites'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change invite color to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change invite to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change invite to `%s`' % string)
    elif cmd.startswith("changetagall:"):
      if msg._from in myMid:
        string = removeCmd2("changetagall:", text)
        if len(string) <= 10000000000:
            settings['changetagall'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change tagall to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change tagall to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change tagall to `%s`' % string)
    elif cmd.startswith("changecolor:"):
      if msg._from in myMid:
        string = removeCmd2("changecolor:", text)
        if len(string) <= 10000000000:
            settings['changecolor'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change background color to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change background color to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change background color to `%s`' % string)
    elif cmd.startswith("changecolorb:"):
      if msg._from in myMid:
        string = removeCmd2("changecolorb:", text)
        if len(string) <= 10000000000:
            settings['changecolorb'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change border color to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change border color to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change border color to `%s`' % string)
    elif cmd.startswith("changetext:"):
      if msg._from in myMid:
        string = removeCmd2("changetext:", text)
        if len(string) <= 10000000000:
            settings['changetext'] = string
      if settings["temp"] == True:
        SendTemp3(to,'Success change text color to `%s`' % string)
      else:
        if settings["footer"] == True:
            sendFooter(to,'Success change text color to `%s`' % string)
        else:
                line.sendReplyMessage(msg.id,to,'Success change text color to `%s`' % string)
    elif cmd.startswith("cmd fakecontact:"):
      if msg._from in myMid:
        string = removeCmd2("cmd fakecontact:", text)
        if len(string) <= 10000000000:
            mmin['fakemention13'] = string
            TEMPELER(to,'Success change cmd fake tag contact to `%s`' % string)
    elif cmd.startswith("cmd faketag:"):
        string = removeCmd2("cmd faketag:", text)
        if len(string) <= 10000000000:
            mmin['fakemention7'] = string
            TEMPELER(to,'Success change cmd fake tag stk to `%s`' % string)
    elif cmd.startswith("changeinvname:"):
        string = removeCmd2("changeinvname:", text)
        if len(string) <= 10000000000:
            seni['cinv'] = string
            TEMPELER(to,'Success change inv name  to `%s`' % string)
    elif cmd.startswith("changekill:"):
        string = removeCmd2("changekill:", text)
        if len(string) <= 10000000000:
            seni['ckill'] = string
            TEMPELER(to,'Success change kill  to `%s`' % string)
    elif cmd == "change picttemp":
      flagPict["status"] = True
      TEMPELER(to, "Type: Change Background Template\n • Detail: Is Waiting\n • Status: Waiting For Picture\nPlease send a picture...")
#================BATAS================                                    
    elif cmd == '.about':
      if msg._from in myMid:
        res = 'Type: Selfbot♪'
        res += '\n	 › Type : Selfbot'
        res += '\n	 › Version : 4.20'
        res += '\n	 › Library : linepy (Python)'
        res += '\n	 › Creator : T - G'
        if settings["temp"] == True:
            send_foo(to,res)
        else:
            if settings["footer"] == True:
                sendFooter(to,res)
            else:
                line.sendReplyMessage(msg.id,to,res)
    elif cmd == 'status':
      if msg._from in myMid:
        res = 'Type: Status♪'
        res += '\n	 › Auto Like : ' + bool_dict[settings['autolike']['status']][1]
        res += '\n	 › Auto Comment : ' + bool_dict[settings['autokomen']['status']][1]
        res += '\n	 › Auto Add : ' + bool_dict[settings['autoAdd']['status']][1]
        res += '\n	 › Auto Leave Mc : ' + bool_dict[mckontol['mckontol']][1]
        res += '\n	 › Auto Join : ' + bool_dict[settings['autoJoin']['status']][1]
        res += '\n	 › AutoJoin ticket : ' + bool_dict[settings['autoJoin']['ticket']][1]
        res += '\n	 › JoinPurge : ' + bool_dict[joinpurge['purgee']][1]
        res += '\n	 › AutoPurge : ' + bool_dict[joinpurge['purgebl']][1]
        res += '\n	 › Respongift : ' + bool_dict[wait['Mentiongift']][1]
        res += '\n	 › Auto Respond : ' + bool_dict[settings['autoRespond']['status']][1]
        res += '\n	 › Auto Respond Mention : ' + bool_dict[settings['autoRespondMention']['status']][1]
        res += '\n	 › Auto Read : ' + bool_dict[settings['autoRead']][1]
        res += '\n	 › Setting Key : ' + bool_dict[settings['setKey']['status']][1]
        res += '\n	 › Mimic : ' + bool_dict[settings['mimic']['status']][1]
        res += '\n	 › Mention Kick : ' + bool_dict[settings['mentionkick']][1]
        res += '\n	 › Greetings Join : ' + bool_dict[settings['greet']['join']['status']][1]
        res += '\n	 › Greetings Leave : ' + bool_dict[settings['greet']['leave']['status']][1]
        res += '\n	 › Detect Contact : ' + bool_dict[settings['detectcontact']][1]
        res += '\n	 › Check Contact : ' + bool_dict[settings['checkContact']][1]
        res += '\n	 › Check Post : ' + bool_dict[settings['checkPost']][1]
        res += '\n	 › Check Sticker : ' + bool_dict[settings['checkSticker']][1]
        res += '\n	 › Notifcall : ' + bool_dict[wait['notifcall']][1]
        res += '\n	 › Detectpost : ' + bool_dict[wait['Timeline']][1]
        res += '\n	 › Resendchat : ' + bool_dict[settings['unsendMessage']][1]
        res += '\n	 › Mode Template : ' + bool_dict[settings['temp']][1]
        res += '\n	 › Mode Footer : ' + bool_dict[settings['footer']][1]
        TEMPELER(to,res)
    elif cmd == "antitag on":
        settings["mentionkick"] = True
        line.sendMessage(to, 'Success activated antitag')
    elif cmd == "antitag off":
        settings["mentionkick"] = False
        line.sendMessage(to, 'Success deactivated antitag')
    elif cmd == 'abort':
      if msg._from in myMid:
        aborted = False
        if to in settings['changeGroupPicture']:
            settings['changeGroupPicture'].remove(to)
            line.sendMessage(to, 'Change group picture aborted')
            aborted = True
        if settings['changePictureProfile']:
            settings['changePictureProfile'] = False
            line.sendMessage(to, 'Change picture profile aborted')
            aborted = True
        if settings['changeCoverProfile']:
            settings['changeCoverProfile'] = False
            line.sendMessage(to, 'Change cover profile aborted')
            aborted = True
        if wait["wblacklist"]:
            wait["wblacklist"] = False
            line.sendMessage(to, 'Blacklist Contact aborted')
            aborted = True
        if wait["dblacklist"]:
            wait["dblacklist"] = False
            line.sendMessage(to, 'UnBlacklist Contact aborted')
            aborted = True
        if wait["wwhitelist"]:
            wait["wwhitelist"] = False
            line.sendMessage(to, 'Whitelist Contact aborted')
            aborted = True
        if wait["dwhitelist"]:
            wait["dwhitelist"] = False
            line.sendMessage(to, 'UnWhitelist Contact aborted')
            aborted = True
        if settings['changeTempPicture']['status']:
            settings['changeTempPicture']['status'] = False
            line.sendMessage(to, 'Change background template aborted')
            aborted = True
        if settings['invitekontak']:
            settings['invitekontak'] = False
            line.sendMessage(to, 'Invite contact aborted')
            aborted = True
        if not aborted:
            line.sendMessage(to, 'Failed abort, nothing to abort')
    elif cmd.startswith('error'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Error♪'
        res += '\nUsage : '
        res += '\n	 › {key}Error'
        res += '\n	 › {key}Error Logs'
        res += '\n	 › {key}Error Reset'
        res += '\n	 › {key}Error Detail <errid>'
        if cmd == 'error':
          if msg._from in myMid:
            line.sendReplyMessage(msg.id, to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif cond[0].lower() == 'logs':
            try:
                filee = open('errorLog.txt', 'r')
            except FileNotFoundError:
                return line.sendReplyMessage(msg.id, to, 'Failed display error logs, error logs file not found')
            errors = [err.strip() for err in filee.readlines()]
            filee.close()
            if not errors: return line.sendReplyMessage(msg.id, to, 'Failed display error logs, empty error logs')
            res = ' Error Logs'
            res += '\nList :'
            parsed_len = len(errors)//200+1
            no = 0
            for point in range(parsed_len):
                for error in errors[point*200:(point+1)*200]:
                    if not error: continue
                    no += 1
                    res += '\n %i. %s' % (no, error)
                    if error == errors[-1]:
                        res += '\n'
                if res:
                    if res.startswith('\n'): res = res[1:]
                    line.sendReplyMessage(msg.id, to, res)
                res = ''
        elif cond[0].lower() == 'reset':
            filee = open('errorLog.txt', 'w')
            filee.write('')
            filee.close()
            shutil.rmtree('tmp/errors/', ignore_errors=True)
            os.system('mkdir tmp/errors')
            line.sendMessage(to, 'Success reset error logs')
        elif cond[0].lower() == 'detail':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            errid = cond[1]
            if os.path.exists('tmp/errors/%s.txt' % errid):
                with open('tmp/errors/%s.txt' % errid, 'r') as f:
                    line.sendMessage(to, f.read())
            else:
                return line.sendMessage(to, 'Failed display details error, errorid not valid')
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif txt.startswith('setkey'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = ' Setting Key♪ '
        res += '\nStatus : ' + bool_dict[settings['setKey']['status']][1]
        res += '\nKey : ' + settings['setKey']['key'].title()
        res += '\nUsage : '
        res += '\n	 › Setkey'
        res += '\n	 › Setkey <on/off>'
        res += '\n	 › Setkey <key>'
        if txt == 'setkey':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res))
        elif texttl == 'on':
            if settings['setKey']['status']:
                line.sendMessage(to, 'Failed activate setkey, setkey already active')
            else:
                settings['setKey']['status'] = True
                line.sendMessage(to, 'Success activated setkey')
        elif texttl == 'off':
            if not settings['setKey']['status']:
                line.sendMessage(to, 'Failed deactivate setkey, setkey already deactive')
            else:
                settings['setKey']['status'] = False
                line.sendMessage(to, 'Success deactivated setkey')
        else:
            settings['setKey']['key'] = texttl
            line.sendMessage(to, 'Success change set key to (%s)' % textt)
    elif cmd.startswith('autoadd'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Auto Add♪'
        res += '\nStatus : ' + bool_dict[settings['autoAdd']['status']][1]
        res += '\nReply : ' + bool_dict[settings['autoAdd']['reply']][0]
        res += '\nReply Message : ' + settings['autoAdd']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoAdd'
        res += '\n	 › {key}AutoAdd <on/off>'
        res += '\n	 › {key}AutoAdd Reply <on/off>'
        res += '\n	 › {key}AutoAdd <message>'
        if cmd == 'autoadd':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoAdd']['status']:
                line.sendMessage(to, 'Autoadd already active')
            else:
                settings['autoAdd']['status'] = True
                line.sendMessage(to, 'Success activated autoadd')
        elif texttl == 'off':
            if not settings['autoAdd']['status']:
                line.sendMessage(to, 'Autoadd already deactive')
            else:
                settings['autoAdd']['status'] = False
                line.sendMessage(to, 'Success deactivated autoadd')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoAdd']['reply']:
                    line.sendMessage(to, 'Reply message autoadd already active')
                else:
                    settings['autoAdd']['reply'] = True
                    line.sendMessage(to, 'Success activate reply message autoadd')
            elif cond[1].lower() == 'off':
                if not settings['autoAdd']['reply']:
                    line.sendMessage(to, 'Reply message autoadd already deactive')
                else:
                    settings['autoAdd']['reply'] = False
                    line.sendMessage(to, 'Success deactivate reply message autoadd')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autoAdd']['message'] = textt
            line.sendMessage(to, 'Success change autoadd message to `%s`' % textt)
    elif cmd.startswith('autocomment'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Auto Comment♪'
        res += '\nStatus : ' + bool_dict[settings['autokomen']['status']][1]
        res += '\nReply Message : ' + settings['autokomen']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoLike'
        res += '\n	 › {key}Autocomment <on/off>'
        res += '\n	 › {key}Autocomment <message>'
        if cmd == 'autocomment':
          if msg._from in myMid:
            TEMPELER(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autokomen']['status']:
                TEMPELER(to, 'aktip dahhh')
            else:
                settings['autokomen']['status'] = True
                TEMPELER(to, 'Success activated autocomment')
        elif texttl == 'off':
            if not settings['autokomen']['status']:
                TEMPELER(to, 'gaaktip dahhh')
            else:
                settings['autokomen']['status'] = False
                TEMPELER(to, 'Success deactivated autocomment')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return TEMPELER(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autokomen']['reply']:
                    TEMPELER(to, 'Reply message autocomment already active')
                else:
                    settings['autokomen']['reply'] = True
                    TEMPELER(to, 'Success activate reply message autocomment')
            elif cond[1].lower() == 'off':
                if not settings['autokomen']['reply']:
                    TEMPELER(to, 'Reply message autocomment already deactive')
                else:
                    settings['autokomen']['reply'] = False
                    TEMPELER(to, 'Success deactivate reply message autocomment')
            else:
                TEMPELER(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autokomen']['message'] = textt
            TEMPELER(to, 'Success change autocomment message to `%s`' % textt)
    elif cmd.startswith('autolike'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Auto Like ♪'
        res += '\nStatus : ' + bool_dict[settings['autolike']['status']][1]
        res += '\nReply Message : ' + settings['autolike']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoComment'
        res += '\n	 › {key}AutoLike <on/off>'
        res += '\n	 › {key}AutoLike <message>'
        if cmd == 'autolike':
          if msg._from in myMid:
            TEMPELER(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autolike']['status']:
                TEMPELER(to, 'aktip dahhh')
            else:
                settings['autolike']['status'] = True
                TEMPELER(to, 'Success activated autolike')
        elif texttl == 'off':
            if not settings['autolike']['status']:
                TEMPELER(to, 'gaaktip dahhh')
            else:
                settings['autolike']['status'] = False
                TEMPELER(to, 'Success deactivated autolike')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return TEMPELER(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autolike']['reply']:
                    TEMPELER(to, 'Reply message autolike already active')
                else:
                    settings['autolike']['reply'] = True
                    TEMPELER(to, 'Success activate reply message autolike')
            elif cond[1].lower() == 'off':
                if not settings['autolike']['reply']:
                    TEMPELER(to, 'Reply message autolike already deactive')
                else:
                    settings['autolike']['reply'] = False
                    TEMPELER(to, 'Success deactivate reply message autolike')
            else:
                TEMPELER(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autolike']['message'] = textt
            TEMPELER(to, 'Success change autolike message to `%s`' % textt)
    elif cmd.startswith('autojoin'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Auto Join♪'
        res += '\nStatus : ' + bool_dict[settings['autoJoin']['status']][1]
        res += '\nReply : ' + bool_dict[settings['autoJoin']['reply']][0]
        res += '\nReply Message : ' + settings['autoJoin']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoJoin'
        res += '\n	 › {key}AutoJoin <on/off>'
        res += '\n	 › {key}AutoJoin Ticket <on/off>'
        res += '\n	 › {key}AutoJoin Reply <on/off>'
        res += '\n	 › {key}AutoJoin <message>'
        if cmd == 'autojoin':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoJoin']['status']:
                line.sendMessage(to, 'Autojoin already active')
            else:
                settings['autoJoin']['status'] = True
                line.sendMessage(to, 'Success activated autojoin')
        elif texttl == 'off':
            if not settings['autoJoin']['status']:
                line.sendMessage(to, 'Autojoin already deactive')
            else:
                settings['autoJoin']['status'] = False
                line.sendMessage(to, 'Success deactivated autojoin')
        elif cond[0].lower() == 'reply':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoJoin']['reply']:
                    line.sendMessage(to, 'Reply message autojoin already active')
                else:
                    settings['autoJoin']['reply'] = True
                    line.sendMessage(to, 'Success activate reply message autojoin')
            elif cond[1].lower() == 'off':
                if not settings['autoJoin']['reply']:
                    line.sendMessage(to, 'Reply message autojoin already deactive')
                else:
                    settings['autoJoin']['reply'] = False
                    line.sendMessage(to, 'Success deactivate reply message autojoin')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif cond[0].lower() == 'ticket':
            if len(cond) < 2:
                return line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
            if cond[1].lower() == 'on':
                if settings['autoJoin']['ticket']:
                    line.sendMessage(to, 'Autojoin ticket already active')
                else:
                    settings['autoJoin']['ticket'] = True
                    line.sendMessage(to, 'Success activate autojoin ticket')
            elif cond[1].lower() == 'off':
                if not settings['autoJoin']['ticket']:
                    line.sendMessage(to, 'Autojoin ticket already deactive')
                else:
                    settings['autoJoin']['ticket'] = False
                    line.sendMessage(to, 'Success deactivate autojoin ticket')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            settings['autoJoin']['message'] = textt
            line.sendMessage(to, 'Success change autojoin message to `%s`' % textt)
    elif cmd.startswith('autorespondmention'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = ' Auto Respond Mention♪'
        res += '\nStatus : ' + bool_dict[settings['autoRespondMention']['status']][1]
        res += '\nReply Message : ' + settings['autoRespondMention']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoRespondMention'
        res += '\n	 › {key}AutoRespondMention <on/off>'
        res += '\n	 › {key}AutoRespondMention <message>'
        if cmd == 'autorespondmention':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoRespondMention']['status']:
                line.sendMessage(to, 'Autorespondmention already active')
            else:
                settings['autoRespondMention']['status'] = True
                line.sendMessage(to, 'Success activated autorespondmention')
        elif texttl == 'off':
            if not settings['autoRespondMention']['status']:
                line.sendMessage(to, 'Autorespondmention already deactive')
            else:
                settings['autoRespondMention']['status'] = False
                line.sendMessage(to, 'Success deactivated autorespondmention')
        else:
            settings['autoRespondMention']['message'] = textt
            line.sendMessage(to, 'Success change autorespondmention message to `%s`' % textt)
    elif cmd.startswith('autorespond'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = ' Auto Respond♪'
        res += '\nStatus : ' + bool_dict[settings['autoRespond']['status']][1]
        res += '\nReply Message : ' + settings['autoRespond']['message']
        res += '\nUsage : '
        res += '\n	 › {key}AutoRespond'
        res += '\n	 › {key}AutoRespond <on/off>'
        res += '\n	 › {key}AutoRespond <message>'
        if cmd == 'autorespond':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['autoRespond']['status']:
                line.sendMessage(to, 'Autorespond already active')
            else:
                settings['autoRespond']['status'] = True
                line.sendMessage(to, 'Success activated autorespond')
        elif texttl == 'off':
            if not settings['autoRespond']['status']:
                line.sendMessage(to, 'Autorespond already deactive')
            else:
                settings['autoRespond']['status'] = False
                line.sendMessage(to, 'Success deactivated autorespond')
        else:
            settings['autoRespond']['message'] = textt
            line.sendMessage(to, 'Success change autorespond message to `%s`' % textt)
    elif cmd.startswith('autoread '):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['autoRead']:
                line.sendMessage(to, 'Autoread already active')
            else:
                settings['autoRead'] = True
                line.sendMessage(to, 'Success activated autoread')
        elif texttl == 'off':
            if not settings['autoRead']:
                line.sendMessage(to, 'Autoread already deactive')
            else:
                settings['autoRead'] = False
                line.sendMessage(to, 'Success deactivated autoread')
    elif cmd.startswith('checkcontact '):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['checkContact']:
                line.sendMessage(to, 'Checkcontact already active')
            else:
                settings['checkContact'] = True
                line.sendMessage(to, 'Success activated checkcontact')
        elif texttl == 'off':
            if not settings['checkContact']:
                line.sendMessage(to, 'Checkcontact already deactive')
            else:
                settings['checkContact'] = False
                line.sendMessage(to, 'Success deactivated checkcontact')
    elif cmd.startswith('detectcontact '):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['detectcontact']:
                line.sendMessage(to, 'Detect contact already active')
            else:
                settings['detectcontact'] = True
                line.sendMessage(to, 'Success activated detect contact')
        elif texttl == 'off':
            if not settings['detectcontact']:
                line.sendMessage(to, 'Detect contact already deactive')
            else:
                settings['detectcontact'] = False
                line.sendMessage(to, 'Success deactivated detect contact')
    elif cmd.startswith('checkpost '):
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['checkPost']:
                line.sendMessage(to, 'Checkpost already active')
            else:
                settings['checkPost'] = True
                line.sendMessage(to, 'Success activated checkpost')
        elif texttl == 'off':
            if not settings['checkPost']:
                line.sendMessage(to, 'Checkpost already deactive')
            else:
                settings['checkPost'] = False
                line.sendMessage(to, 'Success deactivated checkpost')
    elif cmd.startswith('checksticker '):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if texttl == 'on':
            if settings['checkSticker']:
                line.sendMessage(to, 'Checksticker already active')
            else:
                settings['checkSticker'] = True
                line.sendMessage(to, 'Success activated checksticker')
        elif texttl == 'off':
            if not settings['checkSticker']:
                line.sendMessage(to, 'Checksticker already deactive')
            else:
                settings['checkSticker'] = False
                line.sendMessage(to, 'Success deactivated checksticker')
    elif cmd == "changevp":
      if msg._from in myMid:
        settings["changevp"] = True
        text = "Type: Video Profile\n	 › Detail: Change Video Profile\n	 › Status: Waiting for Video\n	 › Please send a video"
        if settings["temp"] == True:
            SendTemp3(to,text)
        else:
            if settings["footer"] == True:
                sendFooter(to,text)
            else:
                line.sendReplyMessage(msg.id,to,text)
    elif cmd == 'invite:on':
      if msg._from in myMid:
        settings['invitekontak'] = True
      if settings["temp"] == True:
        SendTemp3(to,"Type: Invite Contact ♪\n	 › Please send a Contact")
      else:
        if settings["footer"] == True:
            sendFooter(to,"Type: Invite Contact ♪\n	 › Please send a Contact")
        else:
            line.sendReplyMessage(msg.id,to,"Type: Invite Contact ♪\n	 › Please send a Contact")
    elif cmd.startswith('myprofile'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        profile = line.getProfile()
        res = ' My Profile♪'
        res += '\nMID : ' + profile.mid
        res += '\nDisplay Name : ' + str(profile.displayName)
        res += '\nStatus Message : ' + str(profile.statusMessage)
        res += '\nUsage : '
        res += '\n	 › {key}MyProfile'
        res += '\n	 › {key}MyProfile MID'
        res += '\n	 › {key}MyProfile Name'
        res += '\n	 › {key}MyProfile Bio'
        res += '\n	 › {key}MyProfile Pict'
        res += '\n	 › {key}MyProfile Cover'
        res += '\n	 › {key}MyProfile Change Name <name>'
        res += '\n	 › {key}MyProfile Change Bio <bio>'
        res += '\n	 › {key}MyProfile Change Pict'
        res += '\n	 › {key}MyProfile Change Cover'
        if cmd == 'myprofile':
          if msg._from in myMid:
            if profile.pictureStatus:
                line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + profile.pictureStatus)
            cover = line.getProfileCoverURL(profile.mid)
            line.sendImageWithURL(to, str(cover))
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'mid':
            line.sendMessage(to, '[ MID ]\n' + str(profile.mid))
        elif texttl == 'name':
            line.sendMessage(to, '[ Display Name ]\n' + str(profile.displayName))
        elif texttl == 'bio':
            line.sendMessage(to, '[ Status Message ]\n' + str(profile.statusMessage))
        elif texttl == 'pict':
            if profile.pictureStatus:
                path = 'http://dl.profile.line-cdn.net/' + profile.pictureStatus
                line.sendImageWithURL(to, path)
                line.sendMessage(to, '[ Picture Status ]\n' + path)
            else:
                line.sendMessage(to, 'Failed display picture status, user doesn\'t have a picture status')
        elif texttl == 'cover':
            cover = line.getProfileCoverURL(profile.mid)
            line.sendImageWithURL(to, str(cover))
            line.sendMessage(to, '[ Cover Picture ]\n' + str(cover))
        elif texttl.startswith('change '):
            texts = textt[7:]
            textsl = texts.lower()
            if textsl.startswith('name '):
                name = texts[5:]
                if len(name) <= 20:
                    profile.displayName = name
                    line.updateProfile(profile)
                    line.sendMessage(to, 'Success change display name, changed to `%s`' % name)
                else:
                    line.sendMessage(to, 'Failed change display name, the length of the name cannot be more than 20')
            elif textsl.startswith('bio '):
                bio = texts[4:]
                if len(bio) <= 500:
                    profile.statusMessage = bio
                    line.updateProfile(profile)
                    line.sendMessage(to, 'Success change status message, changed to `%s`' % bio)
                else:
                    line.sendMessage(to, 'Failed change status message, the length of the bio cannot be more than 500')
            elif textsl == 'pict':
                settings['changePictureProfile'] = True
                line.sendMessage(to, 'Please send the image to set in picture profile, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
            elif textsl == 'cover':
                settings['changeCoverProfile'] = True
                line.sendMessage(to, 'Please send the image to set in cover profile, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith("clone "):
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        clone = ast.literal_eval(msg.contentMetadata['MENTION'])
                        clones = clone['MENTIONEES']
                        target = []
                        for clone in clones:
                            if clone["M"] not in target:
                               target.append(clone["M"])
                        for she in target:
                            BackupProfile = line.getContact(sender)
                            Save1 = "http://dl.profile.line-cdn.net/{}".format(BackupProfile.pictureStatus);Save2 = "{}".format(BackupProfile.displayName);ProfileMe["PictureMe"] = Save1;ProfileMe["NameMe"] = Save2
                            contact = line.getContact(she);ClonerV2(she)
                            line.sendMention(to, contact.mid, "「 Clone Profile 」\n", "\nStatus : Success");line.sendContact(to, str(BackupProfile.mid));line.sendContact(to, str(contact.mid))
    elif cmd == "unclone":
                    try:
                         myProfile = line.getProfile()
                         myName = line.getProfile()
                         myProfile.statusMessage = str(ProfileMe["myProfile"]["statusMessage"])
                         myProfile.pictureStatus = str(ProfileMe["myProfile"]["pictureStatus"])
                         myName.displayName = ProfileMe["NameMe"]
                         line.updateProfile(clientName)
                         path = line.downloadFileURL(ProfileMe["PictureMe"])
                         line.updateProfilePicture(path)
                         coverId = str(ProfileMe["myProfile"]["coverId"])
                         line.updateProfileCoverById(coverId)
                         BackupProfile = line.getContact(sender)
                         line.sendMention(to, BackupProfile.mid, "「 Unclone Profile 」\n", "\nStatus : Success");line.sendContact(to, str(BackupProfile.mid))
                    except Exception as error:
                         line.sendMessage(to, "Failed to Backup")
    elif cmd.startswith('profile'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        profile = line.getContact(to) if msg.toType == 0 else None
        res = ' Steal Profile♪'
        if profile:
            res += '\n MID : ' + profile.mid
            res += '\n Display Name : ' + str(profile.displayName)
            if profile.displayNameOverridden: res += '\n Display Name Overridden : ' + str(profile.displayNameOverridden)
            res += '\n Status Message : ' + str(profile.statusMessage)
        res += '\n Usage : '
        res += '\n	 › {key}Profile'
        res += '\n	 › {key}Profile Mid'
        res += '\n	 › {key}Profile Name'
        res += '\n	 › {key}Profile Bio'
        res += '\n	 › {key}Profile Pict'
        res += '\n	 › {key}Profile Cover'
        res += '\n	 › {key}Profile Steal Profile <mention>'
        res += '\n	 › {key}Profile Steal Mid <mention>'
        res += '\n	 › {key}Profile Steal Name <mention>'
        res += '\n	 › {key}Profile Steal Bio <mention>'
        res += '\n	 › {key}Profile Steal Pict <mention>'
        res += '\n	 › {key}Profile Steal Cover <mention>'
        if cmd == 'profile':
          if msg._from in myMid:
            if profile:
                if profile.pictureStatus:
                    line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + profile.pictureStatus)
                cover = line.getProfileCoverURL(profile.mid)
                line.sendImageWithURL(to, str(cover))
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'mid':
            if msg.toType != 0: return line.sendMessage(to, 'Failed display mid user, use this command only in personal chat')
            line.sendMessage(to, '[ MID ]\n' + str(profile.mid))
        elif texttl == 'name':
            if msg.toType != 0: return line.sendMessage(to, 'Failed display mid user, use this command only in personal chat')
            line.sendMessage(to, '[ Display Name ]\n' + str(profile.displayName))
        elif texttl == 'bio':
            if msg.toType != 0: return line.sendMessage(to, 'Failed display mid user, use this command only in personal chat')
            line.sendMessage(to, '[ Status Message ]\n' + str(profile.statusMessage))
        elif texttl == 'pict':
            if msg.toType != 0: return line.sendMessage(to, 'Failed display mid user, use this command only in personal chat')
            if profile.pictureStatus:
                path = 'http://dl.profile.line-cdn.net/' + profile.pictureStatus
                line.sendImageWithURL(to, path)
                line.sendMessage(to, '[ Picture Status ]\n' + path)
            else:
                line.sendMessage(to, 'Failed display picture status, user doesn\'t have a picture status')
        elif texttl == 'cover':
            if msg.toType != 0: return line.sendMessage(to, 'Failed display mid user, use this command only in personal chat')
            cover = line.getProfileCoverURL(profile.mid)
            line.sendImageWithURL(to, str(cover))
            line.sendMessage(to, '[ Cover Picture ]\n' + str(cover))
        elif texttl.startswith('steal '):
            texts = textt[6:]
            textsl = texts.lower()
            if textsl.startswith('profile '):
                if 'MENTION' in msg.contentMetadata.keys():
                    mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                    for mention in mentions['MENTIONEES']:
                        profile = line.getContact(mention['M'])
                        if profile.pictureStatus:
                            line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + profile.pictureStatus)
                        cover = line.getProfileCoverURL(profile.mid)
                        line.sendImageWithURL(to, str(cover))
                        res = ' Profile♪'
                        res += '\n MID : ' + profile.mid
                        res += '\n Display Name : ' + str(profile.displayName)
                        if profile.displayNameOverridden: res += '\n Display Name Overridden : ' + str(profile.displayNameOverridden)
                        res += '\n Status Message : ' + str(profile.statusMessage)
                        line.sendMessage(to, parsingRes(res))
                else:
                    line.sendMessage(to, 'Failed steal profile, no one user mentioned')
            elif textsl.startswith('mid '):
                res = ' MID♪'
                no = 0
                if 'MENTION' in msg.contentMetadata.keys():
                    mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                    if len(mentions['MENTIONEES']) == 1:
                        mid = mentions['MENTIONEES'][0]['M']
                        return line.sendMessage(to, '[ MID ]\n' + mid)
                    for mention in mentions['MENTIONEES']:
                        mid = mention['M']
                        no += 1
                        res += '\n %i. %s' % (no, mid)
                    line.sendMessage(to, parsingRes(res))
                else:
                    line.sendMessage(to, 'Failed steal mid, no one user mentioned')
            elif textsl.startswith('name '):
                res = ' Display Name♪'
                no = 0
                if 'MENTION' in msg.contentMetadata.keys():
                    mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                    if len(mentions['MENTIONEES']) == 1:
                        profile = line.getContact(mentions['MENTIONEES'][0]['M'])
                        return line.sendMessage(to, '[ Display Name ]\n' + str(profile.displayName))
                    for mention in mentions['MENTIONEES']:
                        mid = mention['M']
                        profile = line.getContact(mid)
                        no += 1
                        res += '\n %i. %s' % (no, profile.displayName)
                    line.sendMessage(to, parsingRes(res))
                else:
                    line.sendMessage(to, 'Failed steal display name, no one user mentioned')
            elif textsl.startswith('bio '):
                res = ' Status Message♪'
                no = 0
                if 'MENTION' in msg.contentMetadata.keys():
                    mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                    if len(mentions['MENTIONEES']) == 1:
                        profile = line.getContact(mentions['MENTIONEES'][0]['M'])
                        return line.sendMessage(to, '[ Status Message ]\n' + str(profile.statusMessage))
                    for mention in mentions['MENTIONEES']:
                        mid = mention['M']
                        profile = line.getContact(mid)
                        no += 1
                        res += '\n %i. %s' % (no, profile.statusMessage)
                    line.sendMessage(to, parsingRes(res))
                else:
                    line.sendMessage(to, 'Failed steal status message, no one user mentioned')
            elif textsl.startswith('pict '):
                res = ' Picture Status♪'
                no = 0
                if 'MENTION' in msg.contentMetadata.keys():
                    mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                    if len(mentions['MENTIONEES']) == 1:
                        profile = line.getContact(mentions['MENTIONEES'][0]['M'])
                        if profile.pictureStatus:
                            path = 'http://dl.profile.line-cdn.net/' + profile.pictureStatus
                            line.sendImageWithURL(to, path)
                            return line.sendMessage(to, '[ Picture Status ]\n' + path)
                        else:
                            return line.sendMessage(to, 'Failed steal picture status, user `%s` doesn\'t have a picture status' % profile.displayName)
                    for mention in mentions['MENTIONEES']:
                        mid = mention['M']
                        profile = line.getContact(mid)
                        no += 1
                        if profile.pictureStatus:
                            path = 'http://dl.profile.line-cdn.net/' + profile.pictureStatus
                            line.sendImageWithURL(to, path)
                            res += '\n %i. %s' % (no, path)
                        else:
                            res += '\n %i. Not Found' % no
                    line.sendMessage(to, parsingRes(res))
                else:
                    line.sendMessage(to, 'Failed steal picture status, no one user mentioned')
            elif textsl.startswith('cover '):
                res = ' Cover Picture♪'
                no = 0
                if 'MENTION' in msg.contentMetadata.keys():
                    mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                    if len(mentions['MENTIONEES']) == 1:
                        mid = mentions['MENTIONEES'][0]['M']
                        cover = line.getProfileCoverURL(mid)
                        line.sendImageWithURL(to, str(cover))
                        line.sendMessage(to, '[ Cover Picture ]\n' + str(cover))
                    for mention in mentions['MENTIONEES']:
                        mid = mention['M']
                        no += 1
                        cover = line.getProfileCoverURL(mid)
                        line.sendImageWithURL(to, str(cover))
                        res += '\n %i. %s' % (no, cover)
                    line.sendMessage(to, parsingRes(res))
                else:
                    line.sendMessage(to, 'Failed steal cover picture, no one user mentioned')
            else:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('mimic'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        targets = ''
        if settings['mimic']['target']:
            no = 0
            for target, status in settings['mimic']['target'].items():
                no += 1
                try:
                    name = line.getContact(target).displayName
                except TalkException:
                    name = 'Unknown'
                targets += '\n %i. %s//%s' % (no, name, bool_dict[status][1])
        else:
            targets += '\n Nothing'
        res = ' Mimic♪'
        res += '\n Status : ' + bool_dict[settings['mimic']['status']][1]
        res += '\n List :'
        res += targets
        res += '\n Usage : '
        res += '\n	 › {key}Mimic'
        res += '\n	 › {key}Mimic <on/off>'
        res += '\n	 › {key}Mimic Reset'
        res += '\n	 › {key}Mimic Add <mention>'
        res += '\n	 › {key}Mimic Del <mention>'
        if cmd == 'mimic':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl == 'on':
            if settings['mimic']['status']:
                line.sendMessage(to, 'Mimic already active')
            else:
                settings['mimic']['status'] = True
                line.sendMessage(to, 'Success activated mimic')
        elif texttl == 'off':
            if not settings['mimic']['status']:
                line.sendMessage(to, 'Mimic already deactive')
            else:
                settings['mimic']['status'] = False
                line.sendMessage(to, 'Success deactivated mimic')
        elif texttl == 'reset':
            settings['mimic']['target'] = {}
            line.sendMessage(to, 'Success reset mimic list')
        elif texttl.startswith('add '):
            res = ' Mimic♪'
            res += '\n Status : Add Target'
            res += '\n Added :'
            no = 0
            if 'MENTION' in msg.contentMetadata.keys():
                mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                for mention in mentions['MENTIONEES']:
                    mid = mention['M']
                    settings['mimic']['target'][mid] = True
                    no += 1
                    try:
                        name = line.getContact(mid).displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                if no == 0: res += '\n Nothing'
                line.sendMessage(to, res)
            else:
                line.sendMessage(to, 'Failed add mimic target, no one user mentioned')
        elif texttl.startswith('del '):
            res = ' Mimic♪'
            res += '\n Status : Del Target'
            res += '\n Deleted :'
            no = 0
            if 'MENTION' in msg.contentMetadata.keys():
                mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                for mention in mentions['MENTIONEES']:
                    mid = mention['M']
                    if mid in settings['mimic']['target']:
                        settings['mimic']['target'][mid] = False
                    no += 1
                    try:
                        name = line.getContact(mid).displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                if no == 0: res += '\n Nothing'
                line.sendMessage(to, res)
            else:
                line.sendMessage(to, 'Failed del mimic target, no one user mentioned')
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('broadcast'):
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cond = textt.split(' ')
        res = ' Broadcast♪'
        res += '\n Broadcast Type : '
        res += '\n 1 : Friends'
        res += '\n 2 : Groups'
        res += '\n 0 : All'
        res += '\n Usage : '
        res += '\n	 › {key}Broadcast'
        res += '\n	 › {key}Broadcast <type> <message>'
        if cmd == 'broadcast':
            line.sendMessage(to, parsingRes(res).format(key=setKey.title()))
        elif cond[0] == '1':
            if len(cond) < 2:
                return line.sendMessage(to, 'Failed broadcast, no message detected')
            bot = line.getAllContactIds()
            res = '「 Broadcast 」\n\n'
            res += textt[2:]
            targets = line.getAllContactIds()
            for target in targets:
                try:
                    line.sendMessage(target, res)
                except TalkException:
                    targets.remove(target)
                    continue
                time.sleep(0.8)
            line.sendMessage(to, 'Success broadcast to all friends, sent to %i friends' % len(targets))
        elif cond[0] == '2':
            if len(cond) < 2:
                return line.sendMessage(to, 'Failed broadcast, no message detected')
            bot = line.getGroupIdsJoined()
            res = '「 Broadcast 」\n\n'
            res += textt[2:]
            targets = line.getGroupIdsJoined()
            for target in targets:
                try:
                    line.sendMessage(target, res)
                except TalkException:
                    targets.remove(target)
                    continue
                time.sleep(0.8)
            line.sendMessage(to, 'Success broadcast to all groups, sent to %i groups' % len(targets))
        elif cond[0] == '0':
            if len(cond) < 2:
                return line.sendMessage(to, 'Failed broadcast, no message detected')
            res = '「 Broadcast 」\n\n'
            res += textt[2:]
            targets = line.getGroupIdsJoined() + line.getAllContactIds()
            for target in targets:
                try:
                    line.sendMessage(target, res)
                except TalkException:
                    targets.remove(target)
                    continue
                time.sleep(0.8)
            line.sendMessage(to, 'Success broadcast to all groups and friends, sent to %i groups and friends' % len(targets))
        else:
            line.sendMessage(to, parsingRes(res).format(key=setKey.title()))
    elif cmd.startswith("footergbc "):
      if msg._from in myMid or msg._from in Creator:
        bob = text.split(" ")
        hey = text.replace(bob[0] + " ", "")
        text = "「 Broadcast 」\n\n"
        text += "{}".format(hey)
        groups = line.getGroupIdsJoined()
        for gr in groups:
            data = {
                                    "type": "text",
                                    "text": "{}".format(text),
                                    "sentBy": {
                                        "label": "{}".format(line.getContact(myMid).displayName),
                                        "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
                                        "linkUrl": "https://line.me/ti/p/~mdz-"
                                    }
                                }
            sendTemplate(gr, data)
            time.sleep(0.8)
        line.sendReplyMessage(msg.id, to, 'Success broadcast to all groups, sent to %i groups' % len(groups))
    elif cmd.startswith('friendlist'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cids = line.getAllContactIds()
        cids.sort()
        cnames = []
        ress = []
        res = ' Friend List♪'
        res += '\n List:'
        if cids:
            contacts = []
            no = 0
            if len(cids) > 200:
                parsed_len = len(cids)//200+1
                for point in range(parsed_len):
                    for cid in cids[point*200:(point+1)*200]:
                        try:
                            contact = line.getContact(cid)
                            contacts.append(contact)
                        except TalkException:
                            cids.remove(cid)
                            continue
                        no += 1
                        res += '\n %i. %s' % (no, contact.displayName)
                        cnames.append(contact.displayName)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for cid in cids:
                    try:
                        contact = line.getContact(cid)
                        contacts.append(contact)
                    except TalkException:
                        cids.remove(cid)
                        continue
                    no += 1
                    res += '\n %i. %s' % (no, contact.displayName)
                    cnames.append(contact.displayName)
        else:
            res += '\n Nothing'
        res += '\n Usage : '
        res += '\n	 › {key}FriendList'
        res += '\n	 › {key}FriendList Info <num/name>'
        res += '\n	 › {key}FriendList Add <mention>'
        res += '\n	 › {key}FriendList Del <mention/num/name/all>'
        ress.append(res)
        if cmd == 'friendlist':
          if msg._from in myMid:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('info '):
            texts = textt[5:].split(', ')
            if not cids:
                return line.sendMessage(to, 'Failed display info friend, nothing friend in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    contact = contacts[num - 1]
                    if contact.pictureStatus:
                        line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + contact.pictureStatus)
                    cover = line.getProfileCoverURL(contact.mid)
                    line.sendImageWithURL(to, str(cover))
                    res = ' Contact Info♪'
                    res += '\n MID : ' + contact.mid
                    res += '\n Display Name : ' + str(contact.displayName)
                    if contact.displayNameOverridden: res += '\n Display Name Overridden : ' + str(contact.displayNameOverridden)
                    res += '\n Status Message : ' + str(contact.statusMessage)
                    line.sendMessage(to, parsingRes(res))
                elif name != None:
                    if name in cnames:
                        contact = contacts[cnames.index(name)]
                        if contact.pictureStatus:
                            line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + contact.pictureStatus)
                        cover = line.getProfileCoverURL(contact.mid)
                        line.sendImageWithURL(to, str(cover))
                        res = ' Contact Info♪'
                        res += '\n MID : ' + contact.mid
                        res += '\n Display Name : ' + str(contact.displayName)
                        if contact.displayNameOverridden: res += '\n Display Name Overridden : ' + str(contact.displayNameOverridden)
                        res += '\n Status Message : ' + str(contact.statusMessage)
                        line.sendMessage(to, parsingRes(res))
        elif texttl.startswith('add '):
            res = ' Friend List♪'
            res += '\n Status : Add Friend'
            res += '\n Added :'
            no = 0
            added = []
            if 'MENTION' in msg.contentMetadata.keys():
                mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                for mention in mentions['MENTIONEES']:
                    mid = mention['M']
                    if mid in cids or mid in added:
                        continue
                    no += 1
                    try:
                        line.findAndAddContactsByMid(mid)
                        name = line.getContact(mid).displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                    added.append(mid)
                if no == 0: res += '\n Nothing'
                line.sendMessage(to, res)
            else:
                line.sendMessage(to, 'Failed add contact to friend list, no one user mentioned')
        elif texttl.startswith('del '):
            texts = textt[4:].split(', ')
            if not cids:
                return line.sendMessage(to, 'Failed del contact from friend list, nothing friend in list')
            res = ' Friend List♪'
            res += '\n Status : Del Friend'
            res += '\n Deleted :'
            no = 0
            deleted = []
            if 'MENTION' in msg.contentMetadata.keys():
                mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                for mention in mentions['MENTIONEES']:
                    mid = mention['M']
                    if mid not in cids or mid in deleted:
                        continue
                    no += 1
                    try:
                        line.deleteContact(mid)
                        name = line.getContact(mid).displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                    deleted.append(mid)
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    contact = contacts[num - 1]
                    if contact.mid not in cids and contact.mid in deleted:
                        continue
                    no += 1
                    try:
                        line.deleteContact(contact.mid)
                        name = contact.displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                    deleted.append(contact.mid)
                elif name != None:
                    if name in cnames:
                        contact = contacts[cnames.index(name)]
                        if contact.mid not in cids and contact.mid in deleted:
                            continue
                        no += 1
                        try:
                            line.deleteContact(contact.mid)
                            name = contact.displayName
                        except TalkException:
                            name = 'Unknown'
                        res += '\n %i. %s' % (no, name)
                        deleted.append(contact.mid)
                    elif name.lower() == 'all':
                        for contact in contacts:
                            if contact.mid not in cids and contact.mid in deleted:
                                continue
                            no += 1
                            try:
                                line.deleteContact(contact.mid)
                                name = contact.displayName
                            except TalkException:
                                name = 'Unknown'
                            res += '\n %i. %s' % (no, name)
                            deleted.append(contact.mid)
                            time.sleep(0.8)
                    else:
                        line.sendMessage(to, 'Failed del friend with name `%s`, name not in list ♪' % name)
            if no == 0: res += '\n Nothing'
            line.sendMessage(to, res)
        else:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('blocklist'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        cids = line.getBlockedContactIds()
        cids.sort()
        cnames = []
        ress = []
        res = ' Block List♪'
        res += '\n List:'
        if cids:
            contacts = []
            no = 0
            if len(cids) > 200:
                parsed_len = len(cids)//200+1
                for point in range(parsed_len):
                    for cid in cids[point*200:(point+1)*200]:
                        try:
                            contact = line.getContact(cid)
                            contacts.append(contact)
                        except TalkException:
                            cids.remove(cid)
                            continue
                        no += 1
                        res += '\n %i. %s' % (no, contact.displayName)
                        cnames.append(contact.displayName)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for cid in cids:
                    try:
                        contact = line.getContact(cid)
                        contacts.append(contact)
                    except TalkException:
                        cids.remove(cid)
                        continue
                    no += 1
                    res += '\n %i. %s' % (no, contact.displayName)
                    cnames.append(contact.displayName)
        else:
            res += '\n Nothing'
        res += '\n Usage : '
        res += '\n	 › {key}BlockList'
        res += '\n	 › {key}BlockList Info <num/name>'
        res += '\n	 › {key}BlockList Add <mention>'
        res += '\n	 › {key}BlockList Del <mention/num/name/all>'
        ress.append(res)
        if cmd == 'blocklist':
          if msg._from in myMid:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('info '):
            texts = textt[5:].split(', ')
            if not cids:
                return line.sendMessage(to, 'Failed display info blocked user, nothing user in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    contact = contacts[num - 1]
                    if contact.pictureStatus:
                        line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + contact.pictureStatus)
                    cover = line.getProfileCoverURL(contact.mid)
                    line.sendImageWithURL(to, str(cover))
                    res = ' Contact Info♪'
                    res += '\n MID : ' + contact.mid
                    res += '\n Display Name : ' + str(contact.displayName)
                    if contact.displayNameOverridden: res += '\n Display Name Overridden : ' + str(contact.displayNameOverridden)
                    res += '\n Status Message : ' + str(contact.statusMessage)
                    line.sendMessage(to, parsingRes(res))
                elif name != None:
                    if name in cnames:
                        contact = contacts[cnames.index(name)]
                        if contact.pictureStatus:
                            line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + contact.pictureStatus)
                        cover = line.getProfileCoverURL(contact.mid)
                        line.sendImageWithURL(to, str(cover))
                        res = ' Contact Info♪'
                        res += '\n MID : ' + contact.mid
                        res += '\n Display Name : ' + str(contact.displayName)
                        if contact.displayNameOverridden: res += '\n Display Name Overridden : ' + str(contact.displayNameOverridden)
                        res += '\n Status Message : ' + str(contact.statusMessage)
                        line.sendMessage(to, parsingRes(res))
        elif texttl.startswith('add '):
            res = ' Block List♪'
            res += '\n Status : Add Block'
            res += '\n Added :'
            no = 0
            added = []
            if 'MENTION' in msg.contentMetadata.keys():
                mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                for mention in mentions['MENTIONEES']:
                    mid = mention['M']
                    if mid in cids or mid in added:
                        continue
                    no += 1
                    try:
                        line.blockContact(mid)
                        name = line.getContact(mid).displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                    added.append(mid)
                if no == 0: res += '\n Nothing'
                line.sendMessage(to, res)
            else:
                line.sendMessage(to, 'Failed block contact, no one user mentioned')
        elif texttl.startswith('del '):
            texts = textt[4:].split(', ')
            if not cids:
                return line.sendMessage(to, 'Failed unblock contact, nothing user in list')
            res = ' Block List♪'
            res += '\n Status : Del Block'
            res += '\n Deleted :'
            no = 0
            deleted = []
            if 'MENTION' in msg.contentMetadata.keys():
                mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                for mention in mentions['MENTIONEES']:
                    mid = mention['M']
                    if mid not in cids or mid in deleted:
                        continue
                    no += 1
                    try:
                        line.unblockContact(mid)
                        name = line.getContact(mid).displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                    deleted.append(mid)
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    contact = contacts[num - 1]
                    if contact.mid not in cids and contact.mid in deleted:
                        continue
                    no += 1
                    try:
                        line.unblockContact(contact.mid)
                        name = contact.displayName
                    except TalkException:
                        name = 'Unknown'
                    res += '\n %i. %s' % (no, name)
                    deleted.append(contact.mid)
                elif name != None:
                    if name in cnames:
                        contact = contacts[cnames.index(name)]
                        if contact.mid not in cids and contact.mid in deleted:
                            continue
                        no += 1
                        try:
                            line.unblockContact(contact.mid)
                            name = contact.displayName
                        except TalkException:
                            name = 'Unknown'
                        res += '\n %i. %s' % (no, name)
                        deleted.append(contact.mid)
                    elif name.lower() == 'all':
                        for contact in contacts:
                            if contact.mid not in cids and contact.mid in deleted:
                                continue
                            no += 1
                            try:
                                line.unblockContact(contact.mid)
                                name = contact.displayName
                            except TalkException:
                                name = 'Unknown'
                            res += '\n %i. %s' % (no, name)
                            deleted.append(contact.mid)
                            time.sleep(0.8)
                    else:
                        line.sendMessage(to, 'Failed unblock user with name `%s`, name not in list ♪' % name)
            if no == 0: res += '\n Nothing'
            line.sendMessage(to, res)
        else:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd == settings['changetagall']:
      if msg._from in myMid:
        members = []
        if msg.toType == 1:
            room = line.getCompactRoom(to)
            members = [mem.mid for mem in room.contacts]
        elif msg.toType == 2:
            group = line.getCompactGroup(to)
            members = [mem.mid for mem in group.members]
        else:
            return line.sendMessage(to, 'Failed mentionall members, use this command only on room or group chat')
        if members:
            mentionMembers(to, members)
    elif cmd == 'ginfo':
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed display group info, use this command only on group chat')
        group = line.getCompactGroup(to)
        try:
            ccreator = group.creator.mid
            gcreator = group.creator.displayName
        except:
            ccreator = None
            gcreator = 'Not found'
        if not group.invitee:
            pendings = 0
        else:
            pendings = len(group.invitee)
        qr = 'Close' if group.preventedJoinByTicket else 'Open'
        if group.preventedJoinByTicket:
            ticket = 'Not found'
        else:
            ticket = 'https://line.me/R/ti/g/' + str(line.reissueGroupTicket(group.id))
        created = time.strftime('%d-%m-%Y %H:%M:%S', time.localtime(int(group.createdTime) / 1000))
        path = 'http://dl.profile.line-cdn.net/' + group.pictureStatus
        res = '╭───[ Group Info ]'
        res += '\n├  ID : ' + group.id
        res += '\n├  Name : ' + group.name
        res += '\n├  Creator : ' + gcreator
        res += '\n├  Created Time : ' + created
        res += '\n├  Member : ' + str(len(group.members))
        res += '\n├  Pending : ' + str(pendings)
        res += '\n├  QR Status : ' + qr
        res += '\n├  Ticket : ' + ticket
        res += '\n╰───[ ｃｏｅｘｉｓｔ ]'
        line.sendImageWithURL(to, path)
        if ccreator:
            line.sendContact(to, ccreator)
        else:pass
        if settings["footer"] == True:
            sendFooter(to,res)
        else:
            if settings["footer"] == False:
                line.sendReplyMessage(msg.id,to, res)
    elif cmd == "glist":
                            textt = removeCmd(text, setKey)
                            texttl = textt.lower()
                            gid = line.getGroupIdsJoined()
                            sd = line.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = f"\n\nTotal {total} Groups"
                            cd += "\n\n「 Command 」\n\n› Mentionall: [num]\n› Meluncur: [num]\n› Kickall: [num]\n› Cancelall: [num]\n› Skill: [num|name]\n› Leave group [num]\n› Openqr: [num]\n› Closeqr: [num]\n› Infomem: [num]\n› Ginfo: [num]\n› Unsend: [num] [jumlh]\n› Spamcall: [num] [jumlh]"
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} /// {} ".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                line.generateReplyMessage(msg.id)
                                line.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
    elif cmd.startswith("leave group "):
                            gid = line.getGroupIdsJoined()
                            if len(cmd.split(" ")) == 3:
                                selection = AdityaSplitGood(cmd.split(' ')[2],range(1,len(gid)+1))
                                k = len(gid)//100
                                for a in range(k+1):
                                    if a == 0:eto='• Leave Group'
                                    else:eto=''
                                    text = ''
                                    no = 0
                                    for i in selection.parse()[a*100 : (a+1)*100]:
                                        line.leaveGroup(gid[i - 1])
                                        no+=1
                                        if no == len(selection.parse()):text+= "\n\t\t› {}. {}".format(i,line.getGroup(gid[i - 1]).name)
                                        else:text+= "\n\t\t› {}. {}".format(i,line.getGroup(gid[i - 1]).name)
                                    line.sendMessage(to,eto+text)
    elif cmd.startswith('invlist'):
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        gids = line.getGroupIdsInvited()
        gnames = []
        ress = []
        res = '• Type: Group Pendind List'
        res += '\n	 › List:'
        if gids:
            groups = line.getGroups(gids)
            no = 0
            if len(groups) > 200:
                parsed_len = len(groups)//200+1
                for point in range(parsed_len):
                    for group in groups[point*200:(point+1)*200]:
                        no += 1
                        res += '\n %i. %s//%i' % (no, group.name, len(group.members))
                        gnames.append(group.name)
                    if res:
                        if res.startswith('\n'): res = res[1:]
                        if point != parsed_len - 1:
                            ress.append(res)
                    if point != parsed_len - 1:
                        res = ''
            else:
                for group in groups:
                    no += 1
                    res += '\n %i. %s//%i' % (no, group.name, len(group.members))
                    gnames.append(group.name)
        else:
            res += '\n Nothing'
        res += '\n	 › Usage : '
        res += '\n	 ›{key}InvList'
        res += '\n	 ›{key}InvList Accept <num/name/all>'
        res += '\n	 ›{key}InvList Reject <num/name/all>'
        ress.append(res)
        if cmd == 'invlist':
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('accept '):
            texts = textt[7:].split(', ')
            accepted = []
            if not gids:
                return line.sendMessage(to, 'Failed accept group, nothing invitation group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in accepted:
                            line.sendMessage(to, 'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to, 'Success accept group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed accept group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in accepted:
                            line.sendMessage(to, 'Already accept group %s' % group.name)
                            continue
                        line.acceptGroupInvitation(group.id)
                        accepted.append(group.id)
                        line.sendMessage(to, 'Success accept group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in accepted:
                                continue
                            line.acceptGroupInvitation(gid)
                            accepted.append(gid)
                            time.sleep(0.8)
                        line.sendMessage(to, 'Success accept all invitation group ♪')
                    else:
                        line.sendMessage(to, 'Failed accept group with name `%s`, name not in list ♪' % name)
        elif texttl.startswith('reject '):
            texts = textt[7:].split(', ')
            rejected = []
            if not gids:
                return line.sendMessage(to, 'Failed reject group, nothing invitation group in list')
            for texxt in texts:
                num = None
                name = None
                try:
                    num = int(texxt)
                except ValueError:
                    name = texxt
                if num != None:
                    if num <= len(groups) and num > 0:
                        group = groups[num - 1]
                        if group.id in rejected:
                            line.sendMessage(to, 'Already reject group %s' % group.name)
                            continue
                        line.rejectGroupInvitation(group.id)
                        rejected.append(group.id)
                        line.sendMessage(to, 'Success reject group %s' % group.name)
                    else:
                        line.sendMessage(to, 'Failed reject group number %i, number out of range' % num)
                elif name != None:
                    if name in gnames:
                        group = groups[gnames.index(name)]
                        if group.id in rejected:
                            line.sendMessage(to, 'Already reject group %s' % group.name)
                            continue
                        line.rejectGroupInvitation(group.id)
                        rejected.append(group.id)
                        line.sendMessage(to, 'Success reject group %s' % group.name)
                    elif name.lower() == 'all':
                        for gid in gids:
                            if gid in rejected:
                                continue
                            line.rejectGroupInvitation(gid)
                            rejected.append(gid)
                            time.sleep(0.8)
                        line.sendMessage(to, 'Success reject all invitation group ♪')
                    else:
                        sendFooter(to, 'Failed reject group with name `%s`, name not in list ♪' % name)
        else:
            for res in ress:
                line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd == 'memberlist':
      if msg._from in myMid:
        if msg.toType == 1:
            room = line.getRoom(to)
            members = room.contacts
        elif msg.toType == 2:
            group = line.getGroup(to)
            members = group.members
        else:
            return line.sendMessage(to, 'Failed display member list, use this command only on room or group chat')
        if not members:
            return line.sendMessage(to, 'Failed display member list, no one contact')
        res = ' Member List♪'
        parsed_len = len(members)//200+1
        no = 0
        for point in range(parsed_len):
            for member in members[point*200:(point+1)*200]:
                no += 1
                res += '\n %i. %s' % (no, member.displayName)
                if member == members[-1]:
                    res += ''
            if res:
                if res.startswith('\n'): res = res[1:]
                line.sendMessage(to, res)
            res = ''
    elif cmd == 'pendinglist':
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed display pending list, use this command only on group chat')
        group = line.getGroup(to)
        members = group.invitee
        if not members:
            return line.sendMessage(to, 'Failed display pending list, no one contact')
        res = ' Pending List♪'
        parsed_len = len(members)//200+1
        no = 0
        for point in range(parsed_len):
            for member in members[point*200:(point+1)*200]:
                no += 1
                res += '\n %i. %s' % (no, member.displayName)
                if member == members[-1]:
                    res += ''
            if res:
                if res.startswith('\n'): res = res[1:]
                line.sendMessage(to, res)
            res = ''
    elif cmd == 'openqr':
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed open qr, use this command only on group chat')
        group = line.getCompactGroup(to)
        group.preventedJoinByTicket = False
        line.updateGroup(group)
        if settings["footer"] == True:
            sendFooter(to,'Success mek, Status open qr group')
        else:
            if settings["footer"] == False:
                line.sendReplyMessage(msg.id, to, 'Success mek, Status open qr group')
    elif cmd == 'closeqr':
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed close qr, use this command only on group chat')
        group = line.getCompactGroup(to)
        group.preventedJoinByTicket = True
        line.updateGroup(group)
        if settings["footer"] == True:
            sendFooter(to,'Success mek, Status close qr group')
        else:
            if settings["footer"] == False:
                line.sendReplyMessage(msg.id, to,'Success mek, Status close qr group')
    elif cmd.startswith("getmid "):
              if msg._from in myMid:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                ret_ = "「 Mid User 」"
                                for ls in lists:
                                    ret_ += "\n{}".format(str(ls))
                                line.generateReplyMessage(msg.id)
                                line.sendReplyMessage(msg.id, to, str(ret_))
    elif cmd.startswith("getpict "):
              if msg._from in myMid:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    mmk = line.getContact(ls)
                                    puki = "https://obs.line-scdn.net/" + mmk.pictureStatus
                                    imageFooter(msg.to,puki)
    elif cmd.startswith("getvideo "):
              if msg._from in myMid:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = line.getContact(ls)
                                    if contact.videoProfile == None:
                                    	continue
                                    path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus + "/vp"
                                    line.generateReplyMessage(msg.id)
                                    line.sendVideoWithURL(to, str(path))
    elif cmd.startswith("getcover "):
              if msg._from in myMid:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        path = line.getProfileCoverURL(ls)
                                        path = str(path)
                                        imageFooter(to, path)
    elif cmd.startswith("getname "):
              if msg._from in myMid:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = line.getContact(ls)
                                    try:
                                	    rename = contact.displayNameOverridden
                                    except:
                                	    rename = "「 Display Rename 」\nERROR"
                                    line.sendReplyMessage(msg.id,to, "「 Display Name 」\n" + contact.displayName + "\n「 Display Rename 」\n{}".format(rename))
    elif cmd.startswith("getbio "):
              if msg._from in myMid:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = line.getContact(ls)
                                    line.generateReplyMessage(msg.id)
                                    line.sendReplyMessage(msg.id, to, "{}".format(str(contact.statusMessage)))
    elif cmd.startswith("getprofile "):
              if msg._from in myMid:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = line.getContact(ls)
                                    cu = line.getProfileCoverURL(ls)
                                    path = str(cu)
                                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                    line.sendReplyMessage(msg.id,to,"Nama :\n" + contact.displayName + "\nMid :\n" + contact.mid + "\n\nBio :\n" + contact.statusMessage)
                                    line.sendReplyImageWithURL(msg_id,to,image)
                                    line.sendReplyImageWithURL(msg_id,to,path)
    elif cmd.startswith("getcontact "):
              if msg._from in myMid:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = line.getContact(ls)
                                    mi_d = contact.mid
                                    line.sendContact(to, mi_d)
    elif cmd.startswith('changegn '):
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed change group name, use this command only on group chat')
        group = line.getCompactGroup(to)
        gname = removeCmd(text, setKey)
        if len(gname) > 50:
            return line.sendMessage(to, 'Failed change group name, the number of names cannot exceed 50')
        group.name = gname
        line.updateGroup(group)
    elif cmd == 'changegp':
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed change group picture, use this command only on group chat')
        if to not in settings['changeGroupPicture']:
            settings['changeGroupPicture'].append(to)
            line.sendReplyMessage(msg.id, to, 'Please send the image, type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
        else:
            line.sendReplyMessage(msg.id, to, 'Command already active, please send the image or type `{key}Abort` if want cancel it.\nFYI: Downloading images will fail if too long upload the image'.format(key=setKey.title()))
    elif cmd == 'kickall':
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed kick all members, use this command only on group chat')
        group = line.getCompactGroup(to)
        if not group.members:
            return line.sendReplyMessage(msg.id, to, 'Failed kick all members, no member in list')
        for member in group.members:
            if member.mid == myMid:
                continue
            try:
                line.kickoutFromGroup(to, [member.mid])
            except TalkException as talk_error:
                return line.sendReplyMessage(msg.id, to, 'Failed kick all members, the reason is `%s`' % talk_error.reason)
        line.sendMessage(to, 'Success kick all members, totals %i members' % len(group.members))
    elif cmd == 'cancelall.':
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed cancel all pending members, use this command only on group chat')
        group = line.getCompactGroup(to)
        if not group.invitee:
            return line.sendMessage(to, 'Failed cancel all pending members, no pending member in list')
        for member in group.invitee:
            if member.mid == myMid:
                continue
            try:
                line.cancelGroupInvitation(to, [member.mid])
            except TalkException as talk_error:
                return line.sendMessage(to, 'Failed cancel all pending members, the reason is `%s`' % talk_error.reason)
        line.sendMessage(to, 'Success cancel all pending members, totals %i pending members' % len(pendings))
    elif cmd.startswith('lurk'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        if msg.toType in [1, 2] and to not in lurking:
            lurking[to] = {
                'status': False,
                'time': None,
                'members': [],
                'reply': {
                    'status': True,
                    'message': settings['defaultReplyReader']
                }
            }
        res = '⚔ Lurking♪'
        if msg.toType in [1, 2]: res += '\n Status : ' + bool_dict[lurking[to]['status']][1]
        if msg.toType in [1, 2]: res += '\n Reply Reader : ' + bool_dict[lurking[to]['reply']['status']][1]
        if msg.toType in [1, 2]: res += '\n Reply Reader Message : ' + lurking[to]['reply']['message']
        res += '\n Usage : '
        res += '\n	 › {key}Lurk'
        res += '\n	 › {key}Lurk <on/off>'
        res += '\n	 › {key}Lurk Result'
        res += '\n	 › {key}Lurk Reset'
        res += '\n	 › {key}Lurk ReplyReader <on/off>'
        res += '\n	 › {key}Lurk ReplyReader <message>'
        if cmd == 'lurk':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif msg.toType not in [1, 2]:
            return line.sendMessage(to, 'Failed execute command lurking, use this command only on room or group chat')
        elif texttl == 'on':
            if lurking[to]['status']:
                line.sendMessage(to, 'Lurking already active')
            else:
                lurking[to].update({
                    'status': True,
                    'time': datetime.now(tz=pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S'),
                    'members': []
                })
                line.sendMessage(to, 'Success activated lurking')
        elif texttl == 'off':
            if not lurking[to]['status']:
                line.sendMessage(to, 'Lurking already deactive')
            else:
                lurking[to].update({
                    'status': False,
                    'time': None,
                    'members': []
                })
                line.sendMessage(to, 'Success deactivated lurking')
        elif texttl == 'result':
            if not lurking[to]['status']:
                line.sendMessage(to, 'Failed display lurking result, lurking has not been activated')
            else:
                if not lurking[to]['members']:
                    line.sendMessage(to, 'Failed display lurking result, no one members reading')
                else:
                    members = lurking[to]['members']
                    res = ' Type: Lurking'
                    if msg.toType == 2: res += '\n Group Name : ' + line.getGroup(to).name
                    parsed_len = len(members)//200+1
                    no = 0
                    for point in range(parsed_len):
                        for member in members[point*200:(point+1)*200]:
                            no += 1
                            try:
                                name = line.getContact(member).displayName
                            except TalkException:
                                name = 'Unknown'
                            res += '\n %i. %s' % (no, name)
                            if member == members[-1]:
                                res += '\n'
                                res += '\n Time Set : ' + lurking[to]['time']
                        if res:
                            if res.startswith('\n'): res = res[1:]
                            line.sendMessage(to, res)
                        res = ''
        elif texttl == 'reset':
            if not lurking[to]['status']:
                line.sendMessage(to, 'Failed reset lurking, lurking has not been activated')
            else:
                lurking[to].update({
                    'status': True,
                    'time': datetime.now(tz=pytz.timezone('Asia/Jakarta')).strftime('%Y-%m-%d %H:%M:%S'),
                    'members': []
                })
                line.sendMessage(to, 'Success resetted lurking')
        elif texttl.startswith('replyreader '):
            texts = textt[12:]
            if texts == 'on':
                if lurking[to]['reply']['status']:
                    line.sendMessage(to, 'Reply reader already active')
                else:
                    lurking[to]['reply']['status'] = True
                    line.sendMessage(to, 'Success activated reply reader')
            elif texts == 'off':
                if not lurking[to]['reply']['status']:
                    line.sendMessage(to, 'Reply reader already deactive')
                else:
                    lurking[to]['reply']['status'] = False
                    line.sendMessage(to, 'Success deactivated reply reader')
            else:
                lurking[to]['reply']['message'] = texts
                line.sendMessage(to, 'Success set reply reader message to `%s`' % texts)
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
    elif cmd.startswith('greet'):
      if msg._from in myMid:
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        res = ' Type: Greet Message♪'
        res += '\n Greetings Join Status : ' + bool_dict[settings['greet']['join']['status']][1]
        res += '\n Greetings Join Message : ' + settings['greet']['join']['message']
        res += '\n Greetings Leave Status : ' + bool_dict[settings['greet']['leave']['status']][0]
        res += '\n Greetings Join Message : ' + settings['greet']['leave']['message']
        res += '\n Usage : '
        res += '\n	 › {key}Greet'
        res += '\n	 › {key}Greet Join <on/off>'
        res += '\n	 › {key}Greet Join <message>'
        res += '\n	 › {key}Greet Leave <on/off>'
        res += '\n	 › {key}Greet Leave <message>'
        if cmd == 'greet':
          if msg._from in myMid:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
        elif texttl.startswith('join '):
            texts = textt[5:]
            textsl = texts.lower()
            if textsl == 'on':
                if settings['greet']['join']['status']:
                    line.sendMessage(to, 'Greetings join already active')
                else:
                    settings['greet']['join']['status'] = True
                    line.sendMessage(to, 'Success activated greetings join')
            elif textsl == 'off':
                if not settings['greet']['join']['status']:
                    line.sendMessage(to, 'Greetings join already deactive')
                else:
                    settings['greet']['join']['status'] = False
                    line.sendMessage(to, 'Success deactivated greetings join')
            else:
                settings['greet']['join']['message'] = texts
                line.sendMessage(to, 'Success change greetings join message to `%s`' % texts)
        elif texttl.startswith('leave '):
            texts = textt[6:]
            textsl = texts.lower()
            if textsl == 'on':
                if settings['greet']['leave']['status']:
                    line.sendMessage(to, 'Greetings leave already active')
                else:
                    settings['greet']['leave']['status'] = True
                    line.sendMessage(to, 'Success activated greetings leave')
            elif textsl == 'off':
                if not settings['greet']['leave']['status']:
                    line.sendMessage(to, 'Greetings leave already deactive')
                else:
                    settings['greet']['leave']['status'] = False
                    line.sendMessage(to, 'Success deactivated greetings leave')
            else:
                settings['greet']['leave']['message'] = texts
                line.sendMessage(to, 'Success change greetings leave message to `%s`' % texts)
        else:
            line.sendMessage(to, parsingRes(res).format_map(SafeDict(key=setKey.title())))
#================Invite & Kick================ 
    elif cmd.startswith(settings['changeinvite']):
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                except:
                    line.sendReplyMessage(msg.id,to,"Limited")
    elif cmd.startswith(settings['changekick']):
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                except:
                    line.sendReplyMessage(msg.id,to,"Limited")
    elif cmd.startswith('vkick '):
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed vultra kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                    line.cancelGroupInvitation(to, [mid])
                    line.inviteIntoGroup(to, [mid])
                except:
                    line.sendReplyMessage(msg.id,to,"Limited")
    elif cmd.startswith('reinvite '):
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                except:
                    line.sendReplyMessage(msg.id,to,"Limited")
    elif cmd.startswith('mkick '):
      if msg._from in myMid:
        if msg.toType != 2: return line.sendMessage(to, 'Failed multi kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                if mid == myMid:
                    continue
                try:
                    line.kickoutFromGroup(to, [mid])
                    line.findAndAddContactsByMid(mid)
                    line.inviteIntoGroup(to, [mid])
                    line.cancelGroupInvitation(to, [mid])
                    line.inviteIntoGroup(to, [mid])
                    line.cancelGroupInvitation(to, [mid])
                    line.inviteIntoGroup(to, [mid])
                    line.cancelGroupInvitation(to, [mid])
                    line.inviteIntoGroup(to, [mid])
                    line.cancelGroupInvitation(to, [mid])
                    line.inviteIntoGroup(to, [mid])
                except:
                    line.sendReplyMessage(msg.id,to,"Limited")
    elif cmd.startswith(settings['changekickr']):
        if msg._from in myMid:
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            line.kickoutFromGroup(to, [bb._from])
                            break
                else:
                    line.sendMessage(to, 'you must reply the message')
    elif cmd.startswith(settings['changeinvites']):
        if msg._from in myMid:
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            line.findAndAddContactsByMid(bb._from)
                            line.inviteIntoGroup(to, [bb._from])
                            break
                else:
                    line.sendMessage(to, 'you must reply the message')
    elif cmd.startswith("name"):
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            contact = line.getContact(bb._from)
                            try:
                                rename = contact.displayNameOverridden
                            except:
                                rename = "「 Display Rename 」\nEMPTY"
                            TEMPELER(to, "「 Display Name 」\n" + contact.displayName + "\n「 Display Rename 」\n{}".format(rename))
                            break
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd.startswith("pict"):
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            duar = line.getContact(bb._from)
                            mmk = "https://obs.line-scdn.net/" + duar.pictureStatus
                            imageFooter(msg.to,mmk)
                            break
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd.startswith("bio"):
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            b = line.getContact(bb._from).statusMessage
                            line.sendReplyMessage(msg.id,to, b)
                            break
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd.startswith("mid"):
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            b = line.getContact(bb._from).mid
                            line.sendReplyMessage(msg.id,to, b)
                            break
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd.startswith("cover"):
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            cover = line.getProfileCoverURL(bb._from)
                            imageFooter(to, cover)
                            break
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd.startswith("video"):
                if msg.relatedMessageId is not None:
                    aa = line.getRecentMessagesV2(to, 1001)
                    for bb in aa:
                        if bb.id in msg.relatedMessageId:
                            contact = line.getContact(bb._from)
                            if contact.videoProfile == None:
                                continue
                            mmk = "https://obs.line-scdn.net/" + contact.pictureStatus + "/vp"
                            line.sendVideoWithURL(to, mmk)
                else:
                    line.sendReplyMessage(msg.id,to, 'you must reply the message')
    elif cmd.startswith(seni["ckill"]):
        if msg.toType != 2: return TEMPELER(to, 'Failed kick member, use this command only on group chat')
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                mid = mention['M']
                imnoob = 'kickall.js gid={} token={}'.format(to, line.authToken)
                if mid == myMid:
                    continue
                try:
                    imnoob += " uik={}".format(mid)
                    execute_js(imnoob)
                except:
                    TEMPELER(to,"Limited")
        else:
            sep = removeCmd(text,setKey)
            group = line.getGroup(to)
            targets = []
            targets2 = []
            if group.invitee:
                for i in group.invitee:
                    if line.getContact(i.mid).displayNameOverridden != None:
                        if sep.lower() in line.getContact(i.mid).displayNameOverridden.lower():
                            targets2.append(i.mid)
                    else:
                        if sep.lower() in line.getContact(i.mid).displayName.lower():
                            targets2.append(i.mid)
            for i in group.members:
                if line.getContact(i.mid).displayNameOverridden != None:
                    if sep.lower() in line.getContact(i.mid).displayNameOverridden.lower():
                        targets.append(i.mid)
                else:
                    if sep.lower() in line.getContact(i.mid).displayName.lower():
                        targets.append(i.mid)
            if targets2 != []:
                exc = f"dual.js gid={to} token={line.authToken} app=desktopwin"
                for i in targets2:
                    exc += f" uid={i}"
                for i in targets:
                    exc += f" uik={i}"
                execute_js(exc)
            if targets != []:
                exc = f"kickall.js gid={to} token={line.authToken} app=desktopwin"
                for i in targets:
                    exc += f" uik={i}"
                execute_js(exc)
    elif cmd.startswith("fancy "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " " + sep[1] + " ", "")
                            if int(sep[1]) == 1:
                              fancy1(to, txt)
                            elif int(sep[1]) == 2:
                              fancy2(to, txt)
                            elif int(sep[1]) == 3:
                              fancy3(to, txt)
                            elif int(sep[1]) == 4:
                              fancy4(to, txt)
                            elif int(sep[1]) == 5:
                              fancy5(to, txt)
                            elif int(sep[1]) == 6:
                              fancy6(to, txt)
                            elif int(sep[1]) == 7:
                              fancy7(to, txt)
                            elif int(sep[1]) == 8:
                              fancy8(to, txt)
                            elif int(sep[1]) == 9:
                              fancy9(to, txt)
                            elif int(sep[1]) == 10:
                              fancy10(to, txt)
                            elif int(sep[1]) == 11:
                              fancy11(to, txt)
                            elif int(sep[1]) == 12:
                              fancy12(to, txt)
                            elif int(sep[1]) == 13:
                              fancy13(to, txt)
                            elif int(sep[1]) == 14:
                              fancy14(to, txt)
                            elif int(sep[1]) == 15:
                              fancy15(to, txt)
                            elif int(sep[1]) == 16:
                              fancy16(to, txt)
                            elif int(sep[1]) == 17:
                              fancy17(to, txt)
                            elif int(sep[1]) == 18:
                              fancy18(to, txt)
                            elif int(sep[1]) == 19:
                              fancy19(to, txt)
                            elif int(sep[1]) == 20:
                              fancy20(to, txt)
                            elif int(sep[1]) == 21:
                              fancy21(to, txt)
                            elif int(sep[1]) == 22:
                              fancy22(to, txt)
    elif cmd == "purge on":
      if msg._from in myMid:
                            if msg.toType == 2:
                                group = line.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                for tag in settings["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    line.sendReplyMessage(msg.id,to, "Blacklist not detected!")
                                    return
                                for jj in lists:
                                    line.kickoutFromGroup(to,[jj])
                                line.sendReplyMessage(msg.id, to,"Blacklist has been purge")
    elif cmd == "purgejs":
      if msg._from in myMid:
                            if msg.toType == 2:
                                group = line.getGroup(to)
                                nama = [contact.mid for contact in group.members]
                                lists = []
                                imnoob = 'kickall.js gid={} token={}'.format(to, line.authToken)
                                for tag in settings["blacklist"]:
                                    lists+=filter(lambda str: str == tag, nama)
                                if lists == []:
                                    line.sendReplyMessage(msg.id,to, "Blacklist not detected!")
                                    return
                                for jj in lists:
                                        imnoob += " uik={}".format(jj)
                                execute_js(imnoob)
                                line.sendReplyMessage(msg.id, to,"Blacklist has been purge")
#================ETC FEATURE================
#================Feature================
    elif cmd.startswith("youtubemp3"):
                            link = removeCmd("youtubemp3", text)
                            youtubeMp3(to, link)
    elif cmd.startswith("youtubemp4"):
                            link = removeCmd("youtubemp4", text)
                            youtubeMp4(to, link)
    elif cmd == "mysticker":
                            a = line.shop.getActivePurchases(start=0, size=1000, language='ID', country='ID').productList
                            c = "List Download Sticker:"
                            no = 0
                            for b in a:
                                no +=1
                                c += "\n"+str(no)+". "+b.title[:21]+" ID:"+str(b.packageId)
                            k = len(c)//10000
                            for aa in range(k+1):
                                line.sendMessage(to,'{}'.format(c[aa*10000 : (aa+1)*10000]))
    elif cmd.startswith("lirik "):
                            sep = text.split(" ")
                            mude = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            query = f"{mude}"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/lyric="+query
                            data = json.loads(requests.get(url,headers=headers).text)
                            ret = "Lyrics : "+str(data["result"]["title"])
                            ret += "\n\n• Artis : "+str(data["result"]["artist"])
                            ret += "\n• Lyrics : "+str(data["result"]["lyric"])
                            line.sendMessage(to, str(ret))
    elif cmd.startswith("tiktokuser "):
                            sep = text.split(" ")
                            mude = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            query = f"{mude}"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/tiktok="+query
                            data = json.loads(requests.get(url,headers=headers).text)
                            ret = "「 Tiktok Profile 」\n"
                            ret += "\n• Username : "+str(data["result"]["username"])
                            ret += "\n• FullName  : "+str(data["result"]["fullname"])
                            ret += "\n• Like  : "+str(data["result"]["likes"])
                            ret += "\n• Bio : "+str(data["result"]["biography"])
                            ret += "\n• Followers  : "+str(data["result"]["followers"])
                            ret += "\n• Following  : "+str(data["result"]["following"])
                            ret += "\n• Link Profile   : "+str(data["result"]["profileUrl"])
                            line.sendImageWithURL(to, data["result"]["pictureUrl"])
                            line.sendMessage(to, str(ret))
    elif cmd.startswith("instauser "):
                            sep = text.split(" ")
                            user = text.replace(sep[0] + " ","")
                            r = requests.get(f"http://apitrojans.xyz/instagram/user?username={user}&apikey=IGoyNR")
                            ini = json.loads(r.text)
                            data = ini['result']
                            if data["bio"] == "":biography = "None"
                            else:biography = data["bio"]
                            if data["private"] != True:Privasi = "Disabled"
                            else:Privasi = "Enabled" 
                            result = "    「 Instagram Profile 」\n\n» Profile Name: {}\n» Username: {}\n» Profile Bio: {}\n» Followers: {}\n» Following: {}\n» Private: {}\n» Total Post: {}\n» Link URL: http://instagram.com/{}".format(data['fullname'],data['username'],biography,data['followers'],data['following'],Privasi,data["media"],user)
                            line.sendImageWithURL(to,data['profile_img'])
                            line.sendReplyMessage(msg.id,to,result)
    elif cmd.startswith("instapost "):
                            sep = text.split(" ")
                            mude = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            query = f"{mude}"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/instapost="+query
                            data = json.loads(requests.get(url,headers=headers).text)
                            for frisca in data["result"]["postData"]:
                                if frisca["type"] == "video":
                                    line.sendVideoWithURL(to, frisca["postUrl"])
                                else:
                                    line.sendImageWithURL(to, frisca["postUrl"])
    elif cmd.startswith("twitteruser "):
                            sep = text.split(" ")
                            mude = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            query = f"{mude}"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/twitter="+query
                            data = json.loads(requests.get(url,headers=headers).text)
                            ret = "「 Twitter Profile 」\n"
                            ret += "\n• Username : "+str(data["result"]["username"])
                            ret += "\n• FullName  : "+str(data["result"]["fullname"])
                            ret += "\n• Tweet  : "+str(data["result"]["tweet"])
                            ret += "\n• Bio : "+str(data["result"]["biography"])
                            ret += "\n• Followers  : "+str(data["result"]["follower"])
                            ret += "\n• Following  : "+str(data["result"]["following"])
                            line.sendImageWithURL(to, data["result"]["avatar"])
                            line.sendMessage(to, str(ret))
    elif cmd.startswith("porn "):
                            sep = text.split(" ")
                            okep = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            headers = {"apikey": apikey}
                            main = json.loads(requests.get(f"https://api.imjustgood.com/porn={okep}",headers=headers).text)
                            ret = "「 Porn Movie 」\n"
                            ret += "\n• Duration : "+str(main["result"]["duration"])
                            ret += "\n• Title : "+str(main["result"]["title"])
                            ret += "\n• Quality : "+str(main["result"]["quality"])
                            line.sendReplyMessage(msg.id, to, ret)
                            data = {
                                "type": "video",
                                'originalContentUrl': main['result']['videoUrl'],
                                'previewImageUrl': main['result']['thumbnail'],
                            }
                            sendTemplate(to, data)
    elif cmd == "detect url tiktok on":
                            seni["dtiktok"] = True
                            TEMPELER(to, "Success activated detect url tiktok")
    elif cmd == "detect url tiktok off":
                            seni["dtiktok"] = False
                            TEMPELER(to, "Success deactivate detect url tiktok")
    elif cmd == "detect url instagram on":
                            seni["dinsta"] = True
                            TEMPELER(to, "Success activated detect url instagram")
    elif cmd == "detect url instagram off":
                            seni["dinsta"] = False
                            TEMPELER(to, "Success deactivate detect url instagram")
    elif cmd == "random hentai":
                            apikey = "imjustgood"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/hentai"
                            data = json.loads(requests.get(url,headers=headers).text)
                            for me in data["result"]:
                                line.sendImageWithURL(to, me)
    elif cmd.startswith("wikipedia "):
                            sep = text.split(" ")
                            mude = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            query = f"{mude}"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/wikipedia="+query
                            data = json.loads(requests.get(url,headers=headers).text)
                            ret = "「 WikiPedia 」\n"
                            ret += "\n• Result : "+str(data["result"])
                            line.sendMessage(to, str(ret))
    elif cmd.startswith("zodiac "):
                            sep = text.split(" ")
                            mude = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            query = f"{mude}"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/zodiac="+query
                            data = json.loads(requests.get(url,headers=headers).text)
                            ret = "「 Zodiac Today 」\n"
                            ret += "\n• Date : "+str(data["result"]["date"])
                            ret += "\n• Couple : "+str(data["result"]["couple"])
                            ret += "\n• Pairs : "+str(data["result"]["love"]["couple"])
                            ret += "\n• Singel : "+str(data["result"]["love"]["single"])
                            ret += "\n• Finance : "+str(data["result"]["money"])
                            ret += "\n• Lucky Number : "+str(data["result"]["number"])
                            ret += "\n• Public : "+str(data["result"]["public"])
                            line.sendImageWithURL(to, data["result"]["image"])
                            line.sendMessage(to, str(ret))
    elif cmd.startswith("artinama "):
                            sep = text.split(" ")
                            mude = text.replace(sep[0] + " ","")
                            apikey = "imjustgood"
                            query = f"{mude}"
                            headers = {"apikey": apikey}
                            url = "https://api.imjustgood.com/nama="+query
                            data = json.loads(requests.get(url,headers=headers).text)
                            ret = "Arti Nama : "+str(data["result"]["name"])
                            ret += "\n\n• Definisi : "+str(data["result"]["definition"])
                            ret += "\n• Deskripsi : "+str(data["result"]["description"])
                            line.sendMessage(to, str(ret))
    elif cmd == "neko":
                            host = ["http://api-melodicxt-2.herokuapp.com","http://api-melodicxt-3.herokuapp.com"]
                            api = random.choice(host)
                            a = requests.get(api+"/api/random/neko?apiKey=administrator")
                            data = a.json()
                            line.sendReplyImageWithURL(msg.id, to, data["result"]["result"])
    elif cmd == "hentai":
                            main = json.loads(requests.get("http://api-melodicxt-2.herokuapp.com/api/random/hentai?apiKey=administrator").text)
                            line.sendReplyImageWithURL(msg.id, to, main["result"]["result"])
    elif cmd == "nsfwneko":
                            main = json.loads(requests.get("http://api-melodicxt-2.herokuapp.com/api/random/nsfwneko?apiKey=administrator").text)
                            line.sendReplyImageWithURL(msg.id, to, main["result"]["result"])
    elif cmd == "wallpaper":
                            host = ["http://api-melodicxt-2.herokuapp.com","http://api-melodicxt-3.herokuapp.com"]
                            api = random.choice(host)
                            main = json.loads(requests.get(api+"/api/random/wallpaper?apiKey=administrator").text)
                            line.sendReplyImageWithURL(msg.id, to, main["result"]["result"])
    elif cmd == "traps":
                            main = json.loads(requests.get("http://api-melodicxt-2.herokuapp.com/api/random/trap?apiKey=administrator").text)
                            line.sendReplyImageWithURL(msg.id, to, main["result"]["result"])
    elif cmd.startswith("imagetext "):
                            sep = text.split(" ")
                            anu = text.replace(sep[0] + " ","")
                            host = ["http://api-melodicxt-2.herokuapp.com","http://api-melodicxt-3.herokuapp.com"]
                            api = random.choice(host)
                            main = json.loads(requests.get(api+f"/api/img-text?text={anu}&apiKey=administrator").text)
                            line.sendImageWithURL(to,main["result"]["result"])
    elif cmd.startswith("nulis "):
                            sep = text.split(" ")
                            anu = text.replace(sep[0] + " ","")
                            host = ["http://api-melodicxt-2.herokuapp.com","http://api-melodicxt-3.herokuapp.com"]
                            api = random.choice(host)
                            main = json.loads(requests.get(api+f"/api/joki-nulis?text={anu}&apiKey=administrator").text)
                            line.sendImageWithURL(to,main["result"]["result"])
    elif cmd.startswith("tiktokvid "):
                            sep = text.split(" ")
                            anu = text.replace(sep[0] + " ","")
                            host = ["http://api-melodicxt-2.herokuapp.com","http://api-melodicxt-3.herokuapp.com"]
                            api = random.choice(host)
                            main = json.loads(requests.get(api+f"/api/tiktok/downloader?url={anu}&apiKey=administrator").text)
                            data = {
                                            'type': 'video',
                                            'originalContentUrl': main["data"]["no_watermark"],
                                            'previewImageUrl': main["data"]["no_watermark"],
                            }
                            sendTemplate(to, data)
    elif cmd.startswith("xnxx "):
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                cond = query.split("-")
                                search = str(cond[0])
                                r = requests.get(f"http://apitrojans.xyz/xnxx/search?query={search}&apikey=IGoyNR")
                                data = json.loads(r.text)
                                if len(cond) == 1:
                                    num = 0
                                    ret = "Result Porn\n"
                                    for neko in data:
                                        num += 1
                                        ret += "\n {}. {}".format(str(num), str(neko["title"]))
                                    ret += "\n\nFor See Video Please Type :\nExample : Xnxx {}-1".format(str(search))
                                    line.sendReplyMessage(msg.id, to, str(ret))
                                elif len(cond) == 2:
                                    num = int(cond[1])
                                    if num <= len(data):
                                        neko = data[num - 1]
                                        if data != []:
                                            ret = "Detail Porn\n"
                                            ret += "\n Title : "+str(neko["title"])
                                            data = {
                                                            'type': 'video',
                                                            'originalContentUrl': neko['streamURL'],
                                                            'previewImageUrl': neko['thumbnail'],
                                            }
                                            line.sendReplyMessage(msg.id, to, str(ret))
                                            sendTemplate(to, data)
    elif cmd.startswith("cancel "):
                            sep = text.split(" ")
                            midn = text.replace(sep[0] + " ", "")
                            hmm = text.lower()
                            group = line.getGroup(to)
                            if group.invitee is None or group.invitee == []:
                                line.sendMessage(to, "「 RESPON 」\nNothing member in pending")
                            else:
                                targets = []
                                invitee = [contact.mid for contact in group.invitee]
                                for x in group.invitee:
                                    contact = line.getContact(x)
                                if contact.displayNameOverridden is not None:
                                    if midn in contact.displayNameOverridden.lower():
                                        if x != myMid:
                                            targets.append(contact.mid)
                                    elif midn in contact.displayName.lower():
                                        if x != myMid:
                                            targets.append(contact.mid)
                                elif midn in contact.displayName.lower():
                                     if x != myMid:
                                        targets.append(contact.mid)
                            if targets == []:
                                return line.sendMessage(to, "「 RESPON 」\n I cant found name " + midn)
                            for target in targets:
                                line.cancelGroupInvitation(to, [target])
    elif cmd.startswith(seni["cinv"]):
                            sep = text.split(" ")
                            name = text.replace(sep[0] + " ", "")
                            if name == '':
                                return
                            friend = line.getAllContactIds()
                            list = []
                            for teman in friend:
                                contact = line.getContact(teman)
                                if contact.displayNameOverridden is not None:
                                    if name in contact.displayNameOverridden.lower():
                                        list.append(contact.mid)
                                    else:
                                        if name in contact.displayName.lower():
                                            list.append(contact.mid)
                                else:
                                    if name in contact.displayName.lower():
                                        list.append(contact.mid)
                            if list:
                                for a in list:
                                    line.inviteIntoGroup(to, [a])
                            else:
                                line.sendReplyMessage(msg.id, to, "'{}' not found".format(name)) 
    elif cmd.startswith("skill: "):
        if msg.toType == 2:
            stopcoli = cmd.split(": ")[1]
            sam = stopcoli.split(" | ")
            grup = sam[0]
            nama = sam[1]
            name = nama.split(',')
            if name == "":pass
            else:
                groups = line.getGroupIdsJoined()
                if groups is not None:
                    if int(grup) <= len(groups):
                        groupid = groups[int(grup) - 1]
                        Z = line.getGroup(groupid)
                        A = [a.mid for a in Z.members]
                        if Z.invitee == None:B = []
                        else:B = [a.mid for a in Z.invitee]
                        pend = []
                        mem = []
                        for nama in name:
                            if Z.invitee != None:
                                for pendingan in B:
                                    contact = line.getContact(pendingan)
                                    if contact.displayNameOverridden is not None:
                                        if nama in contact.displayNameOverridden.lower():
                                            if pendingan != myMid:
                                                pend.append(contact.mid)
                                        else:
                                            if nama in contact.displayName.lower():
                                                if pendingan != myMid:
                                                    pend.append(contact.mid)
                                    else:
                                        if nama in contact.displayName.lower():
                                            if pendingan != myMid:
                                                pend.append(contact.mid)
                            for member in A:
                                contact = line.getContact(member)
                                if contact.displayNameOverridden is not None:
                                    if nama in contact.displayNameOverridden.lower():
                                        if member != myMid:
                                            mem.append(contact.mid)
                                    else:
                                        if nama in contact.displayName.lower():
                                            if member != myMid:
                                                mem.append(contact.mid)
                                else:
                                    if nama in contact.displayName.lower():
                                        if member != myMid:
                                            mem.append(contact.mid)
                        try:
                            imnoob = 'dual.js gid={} token={}'.format(groupid, line.authToken)
                            if pend == [] and mem == []:line.sendMessage(receiver,"{} not found".format(nama))
                            else:
                                for abc in pend:imnoob += ' uid={}'.format(abc)
                                for aca in mem:imnoob += " uik={}".format(aca)
                                success = execute_js(imnoob)
                                if success:line.sendMessage(to, "Success kill name {} in ".format(nama) + Z.name)
                                else:line.sendMessage(to, "Detected an error")
                        except Exception as e:line.sendMessage(to,str(e))
                else:line.sendMessage(to, "Your groups are below that numbers")
    elif cmd.startswith("rename "):
      if msg.relatedMessageId is not None:
        aa = line.getRecentMessagesV2(receiver, 1001)
        gid = line.getAllContactIds()
        res = "• Type: Rename Friend"
        no = 0
        target = []
        namauser = text.split("| ")[1]
        for bb in aa:
            if bb.id in msg.relatedMessageId:
                if myMid != bb._from:
                    no += 1
                    a = line.getContact(bb._from).displayName
                    if bb._from not in gid:
                        line.findAndAddContactsByMid(bb._from)
                        time.sleep(0.8)
                        res += "\n\tSuccess rename " + a + " to " + namauser
                        target.append(bb._from)
                        break
                    else:
                        res += "\n\tSuccess rename " + a + " to " + namauser
                        target.append(bb._from)
                        break
        TEMPELER(to, res)
        for a in target:
            line.renameContact(a,namauser)
      else:
          if 'MENTION' in msg.contentMetadata.keys():
              key = eval(msg.contentMetadata["MENTION"])
              key["MENTIONEES"][0]["M"]
              gid = line.getAllContactIds()
              res = "• Type: Rename Friend"
              no = 0
              target = []
              namauser = text.split("| ")[1]
              for x in key["MENTIONEES"]:
                  if myMid != x["M"]:
                      no += 1
                      a = line.getContact(x["M"]).displayName
                      if x["M"] not in gid:
                          line.findAndAddContactsByMid(x["M"])
                          time.sleep(0.5)
                          res += "\n\tSuccess rename " + a + " to " + namauser
                          target.append(x["M"])
                      else:
                          res += "\n\tSuccess rename " + a + " to " + namauser
                          target.append(x["M"])
              TEMPELER(to,res)
              for a in target:
                  line.renameContact(a,namauser)
    elif cmd == "renamelist":
        res = "• Display Rename\n"
        gid = line.getAllContactIds()
        no = 0
        target = []
        for a in gid:
            b = line.getContact(a)
            if b.displayNameOverridden is not None:
                target.append(a)
        if len(target) == 0:line.sendMessage(to, "No friends are renamed")
        else:
            for c in target:
                b = line.getContact(c)
                no += 1
                res += "\n\t" + str(no) + ". " + b.displayName + " › " + b.displayNameOverridden
            line.sendMessage(to, res)
    elif cmd == "cek rename":
        res = "• Detect Rename\n"
        G = line.getGroup(to)
        A = [G.mid for G in G.members]
        if G.invitee == {}:B = {}
        else:B = [G.mid for G in G.invitee]
        target = []
        no = 0
        for a in A:
            b = line.getContact(a)
            if b.displayNameOverridden is not None:
                target.append(a)
        for a in B:
            b = line.getContact(a)
            if b.displayNameOverridden is not None:
                target.append(a)
        if len(target) == 0:line.sendMessage(to, "No friends are renamed")
        else:
            for c in target:
                b = line.getContact(c)
                no += 1
                res += "\n\t" + str(no) + ". " + b.displayName + " › " + b.displayNameOverridden
            line.sendMessage(to, res)
#=====================================================================
#                              \\ COMMAND SPAM //
#=====================================================================
    elif cmd.startswith('spam 1 '):
                            try:
                                msg.text = line.mycmd(msg.text,wait)
                                j = int(msg.text.split(' ')[2])
                                a = [line.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                                h = [line.sendReplyMessage(msg.id,to,b) for b in a]
                            except:pass
    elif cmd.startswith('spam 2 '):
                            msg.text = line.mycmd(msg.text,wait)
                            j = int(msg.text.split(' ')[2])
                            a = [line.adityasplittext(msg.text,'s').replace('{} '.format(j),'')]*j
                            try:group = line.getGroup(to);nama = [contact.mid for contact in group.members];b = [line.sendContact(to,random.choice(nama)) for b in a]
                            except:nama = [to,to];b = [line.sendContact(to,random.choice(nama)) for b in a]
    elif txt == "appname":
      if msg._from in myMid:
      	line.sendMessage(to, "Appname :\n" + str(line.server.APP_NAME))
    elif cmd.startswith(".cek "):
        sep = text.split(" ")
        itil = text.replace(sep[0] + " ","")
        line.sendMessage(msg.to, None, contentMetadata={'mid': itil}, contentType=13)
    elif cmd.startswith("uns "):
      if msg._from in myMid:
        sep = msg.text.split(" ")
        args = msg.text.replace(sep[0] + " ","")
        mes = int(sep[1])
        M = line.getRecentMessagesV2(to, 1001)
        MId = []
        for ind,i in enumerate(M):
            if ind == 0:
                pass
            else:
                if i._from == line.profile.mid:
                    MId.append(i.id)
                    if len(MId) == mes:
                        break
        def unsMes(id):
            line.unsendMessage(id)
        for i in MId:
            thread1 = threading.Thread(target=unsMes, args=(i,))
            thread1.daemon = True
            thread1.start()
            thread1.join()
        line.unsendMessage(msg.id)
    elif cmd.startswith('resendchat '):
        textt = removeCmd(text, setKey)
        texttl = textt.lower()
        G = line.getGroup(to)
        if texttl == 'on':
            if settings["unsendMessage"]:
                TEMPELER(to, 'Resend Chat already active')
            else:
                settings["unsendMessage"] = True
                TEMPELER(to, '「 Notifikasi 」\nResend Chat berhasil diaktifkan\nDi Group ' +  str(G.name))
        elif texttl == 'off':
            if not settings["unsendMessage"]:
                TEMPELER(to, 'Resend Chat already deactive')
            else:
                settings["unsendMessage"] = False
                TEMPELER(to, '「 Notifikasi 」\nResend Chat berhasil dimatikan\nDi Group ' +  str(G.name))
    elif cmd.startswith("urlpict "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    line.sendReplyMessage(msg.id,to,"http://dl.profile.line.naver.jp/" + line.getContact(ls).pictureStatus)
    elif cmd.startswith("lastseen ") and msg.toType == 2:
            if 'MENTION' in msg.contentMetadata.keys() != None:
                names = re.findall(r'@(\w+)', msg.text)
                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                mentionees = mention['MENTIONEES']
                for mention in mentionees:
                    if mention['M'] in lastseen["find"]:
                        line.sendMentionV2(to, "@!{}".format(lastseen["username"][mention['M']]), [mention['M']])
                    else:
                        line.sendMentionV2(to, "Oops!!\nI can't found @!",[mention['M']])
    elif cmd.startswith("find "):
        if 'MENTION' in msg.contentMetadata.keys():
            mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
            for mention in mentions['MENTIONEES']:
                profile = line.getContact(mention['M'])
                aa = line.getGroupIdsJoined()
                target = profile.mid
                lacak = "";num = 1
                for x in aa:
                    member = [c.mid for c in line.getGroup(x).members]
                    if target in member:
                        lacak += "\n{}. {}".format(num,line.getGroup(x).name)
                        num = (num+1)
                if lacak == "":line.sendReplyMessage(msg_id, to,"not found")
                else:
                    pesan = "  [  Locate  ]\nUser : {}\nGroup Joined:{}".format(line.getContact(target).displayName, lacak)
                    line.sendReplyMessage(msg_id, to, pesan)
    elif cmd == "clear mention":
        if msg._from in myMid:
            del tagme['ROM'][to]
            line.sendReplyMessage(msg.id, to, "「 Clear Mention 」\nBerhasil menghapus data Mention di group: {}".format(line.getGroup(to).name))
    elif cmd == "cek mention":
        if msg._from in myMid:
            if to in tagme['ROM']:
                moneys = {}
                msgas = ''
                for a in tagme['ROM'][to].items():
                    moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu']] if a[1] is not None else idnya
                sort = sorted(moneys)
                sort.reverse()
                sort = sort[0:]
                msgas = '「 Mention Me 」'
                h = []
                no = 0
                for m in sort:
                    has = ''
                    nol = -1
                    for kucing in moneys[m][0]:
                        nol+=1
                        has+= '\nline://nv/chatMsg?chatId={}&messageId={} \n{}'.format(to,kucing,humanize.naturaltime(datetime.fromtimestamp(moneys[m][1][nol]/1000)))
                    h.append(m)
                    no+=1
                    if m == sort[0]:
                        msgas+= '\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                    else:
                        msgas+= '\n\n{}. @!{}x{}'.format(no,len(moneys[m][0]),has)
                sendMention(to, msgas, h)
            else:
                msgas = 'Sorry @!In {} nothink get a mention'.format(line.getGroup(to).name)
                sendMention(to, msgas, [sender])
    if cmd.startswith('createnote ') or cmd == 'mentionnote':NoteCreate(to,cmd,msg)
    elif cmd == "notifcall on" or text.lower() == 'rpanggilan on':
                          if msg._from in myMid:
                            if wait["selfbot"] == True:
                                wait["notifcall"] = True
                                line.sendMessage(msg.to," Respon Panggilan diaktifkan")
    elif cmd == "notifcall off" or text.lower() == 'rpanggilan off':
                          if msg._from in myMid:
                            if wait["selfbot"] == True:
                                wait["notifcall"] = False
                                line.sendMessage(msg.to," Respon Panggilan dinonaktifkan")
    elif cmd == "detectpost on" or text.lower() == 'timeline on':
                          if wait["selfbot"] == True:
                            if msg._from in myMid:
                                wait["Timeline"] = True
                                line.sendMessage(msg.to,"detectpost timeline on")

    elif cmd == "detectpost off" or text.lower() == 'timeline off':
                          if wait["selfbot"] == True:
                            if msg._from in myMid:
                                wait["Timeline"] = False
                                line.sendMessage(msg.to,"detectpost timleline off ")
    elif cmd == "respongift on" or text.lower() == 'respongift on':
                          if wait["selfbot"] == True:
                            if msg._from in myMid:
                                wait["Mentiongift"] = True
                                line.sendMessage(msg.to,"Auto respon gift diaktifkan")

    elif cmd == "respongift off" or text.lower() == 'respongift off':
                          if wait["selfbot"] == True:
                            if msg._from in myMid:
                                wait["Mentiongift"] = False
                                line.sendMessage(msg.to,"Auto respon gift dinonaktifkan")
    elif cmd == 'sider off':
        if msg._from in myMid:
                                if msg.to in cctv['point']:
                                    cctv['cyduk'][msg.to]=False
                                    wait["Sider"] = False
                                    G = line.getGroup(to)
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    res = '「 Sider Off 」'
                                    res += '\nSider berhasil Dimatikan'
                                    res += '\nDi Group : ' +  str(G.name)
                                    res += '\nTanggal :'  + datetime.strftime(timeNow,'%d-%m-%Y')
                                    res += '\nJam : ' +  datetime.strftime(timeNow,'%H:%M:%S')
                                    if settings["temp"] == True:
                                        SendTemp3(to,res)
                                    else:
                                        if settings["footer"] == True:
                                            sendFooter(to,res)
                                        else:
                                            line.sendReplyMessage(msg.id, to,res)
                                else:
                                    if settings["temp"] == True:
                                        SendTemp3(to,'「 Sider Off 」\n Sudah Tidak Aktif')
                                    else:
                                        if settings["footer"] == True:
                                            sendFooter(to,'「 Sider Off 」\n Sudah Tidak Aktif')
                                        else:
                                            line.sendReplyMessage(msg.id, to,'「 Sider Off 」\n Sudah Tidak Aktif')
    elif cmd == 'sider on':
        if msg._from in myMid:
                                try:
                                    tz = pytz.timezone("Asia/Jakarta")
                                    G = line.getGroup(msg.to)
                                    timeNow = datetime.now(tz=tz)
                                    del cctv['point'][msg.to]
                                    del cctv['sidermem'][msg.to]
                                    del cctv['cyduk'][msg.to]
                                except:
                                        pass
                                        cctv['point'][msg.to] = msg.id
                                        cctv['sidermem'][msg.to] = ""
                                        cctv['cyduk'][msg.to]=True
                                        wait["Sider"] = True
                                        res = '「 Sider On 」'
                                        res += '\nSider berhasil Diaktifkan'
                                        res += '\nDi Group : ' + str(G.name)
                                        res += '\nTanggal : ' + datetime.strftime(timeNow,'%d-%m-%Y')
                                        res += '\nJam : ' +  datetime.strftime(timeNow,'%H:%M:%S')
                                        if settings["temp"] == True:
                                            SendTemp3(to,res)
                                        else:
                                            if settings["footer"] == True:
                                                sendFooter(to,res)
                                            else:
                                                line.sendReplyMessage(msg.id, to,res)
    elif txt.startswith("exec"):
                            if msg._from in myMid:
                                try:
                                    sep = text.split("\n")
                                    txt = text.replace(sep[0] + "\n","")
                                    exec(txt)
                                except Exception as e:
                                    line.sendMessage(to,str(e))
    elif cmd == 'clearchat':
        if msg._from in myMid:
                    line.removeAllMessages(to)
                    if settings["temp"] == True:
                        SendTemp3(to,"All Chat Cleared")
                    else:
                        if settings["footer"] == True:
                            line.sendMessage(to,"All Chat Cleared")
                        else:
                            line.sendReplyMessage(msg.id, to,"All Chat Cleared")
    elif cmd == 'autoleavemc on':
                    mckontol["mckontol"] = True
                    line.sendMessage(to, "Auto leave mc actived")
    elif cmd == 'autoleavemc off':
                    mckontol["mckontol"] = False
                    line.sendMessage(to, "Auto leave mc non actived")
    elif cmd == 'joinpurge on':
                    joinpurge["purgee"] = True
                    line.sendMessage(to, "Auto join purge actived")
    elif cmd == 'joinpurge off':
                    joinpurge["purgee"] = False
                    line.sendMessage(to, "Auto join purge non actived")
    elif cmd == 'autopurge on':
                    joinpurge["purgebl"] = True
                    line.sendMessage(to, "Auto kick blacklist actived")
    elif cmd == 'autopurge off':
                    joinpurge["purgebl"] = False
                    line.sendMessage(to, "Auto kick blacklist non actived")
    elif cmd == 'get call':
                            a = line.getGroupCall(to)
                            print(a)
                            k = len(a.memberMids)//20
                            for i in range(k+1):
                                try:
                                    if i == 0:aa = '「 Group Call 」\n\tGroup: {}\n\tCall started in: {}'.format(line.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.started)//1000)));no = i
                                    else:aa = '「 Group Call 」\n\tGroup: {}\n\tCall started in: {}'.format(line.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.starter)//1000)));no=i*20
                                    ret = aa
                                    for b in a.memberMids[i*20 : (i+1)*20]:
                                        no += 1
                                        c = a.hostMids
                                        if a.mediaType == 1:typenya = 'Free Call Group'
                                        if a.mediaType == 2:typenya = 'Video Call Group'
                                        if no == len(a.memberMids):ret+='\n\t{}. @!\n• Type: {}\n• Host: @!'.format(no,typenya)
                                        else:ret+='\n\t{}. @!'.format(no)
                                    line.sendMention(to, ret,"",a.memberMids[i*20 : (i+1)*20]+[c])
                                except:
                                    if a.mediaType == 3:typenya = 'Group Live'
                                    if i == 0:aa = '╭「 Group Live 」─\n│In {}\n│Live started in: {}\n│   ⌬ Member watch:'.format(line.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.started)//1000)));no = i
                                    else:aa = '├「 Group Live 」─\n│In {}\n│Live started in: {}\n│   ⌬ Member Watch:'.format(line.getGroup(to).name,humanize.naturaltime(datetime.fromtimestamp(int(a.starter)//1000)));no=i*20
                                    ret = aa
                                    for b in a.memberMids[i*20 : (i+1)*20]:
                                        no += 1
                                        c = a.hostMids
                                        if no == len(a.memberMids):ret+='\n╰{}. @!\n  ⌬ Type: {}\nHost: @!'.format(no,typenya)
                                        else:ret+='\n│{}. @!'.format(no)
                                    line.sendMention(to, ret,"",a.memberMids[i*20 : (i+1)*20]+[c])
    elif cmd == "get announ":
                            msg.text = line.mycmd(msg.text,wait)
                            to = msg.to
                            a = line.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                line.sendMention(to, 'Sorry @!In {} nothink get a Announcements'.format(line.getGroup(to).name),' 「 Announcements 」\n', [line.getProfile().mid])
                                return
                            no = 0
                            c = ' 「 Announcements 」'
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            for b in a:
                                if b.creatorMid not in h:
                                    h.append(b.creatorMid)
                                    no += 1
                                    c += "\n{}. @! #{}x".format(no,str(a).count(b.creatorMid))
                                line.sendMention(msg.to,c,'',h)
    elif cmd.startswith("get announ "):
                            msg.text = line.mycmd(msg.text,wait)
                            to = msg.to
                            a = line.getChatRoomAnnouncements(msg.to)
                            if a == []:
                                line.sendMention(to, 'Sorry @!In {} nothink get a Announcements'.format(line.getGroup(to).name),' 「 Announcements 」\n', [line.getProfile().mid])
                                return
                            c = ' 「 Announcements 」'
                            no = 0
                            h = []
                            ds = [a[b].creatorMid for b in range(len(a)) if a[b].creatorMid not in h]
                            if len(msg.text.split(' ')) == 3:
                                sd = ds[int(msg.text.split(' ')[2])-1]
                            c+= '\nCreate by: @!'
                            no=0
                            for b in a:
                                if b.contents.link != None:
                                    if b.creatorMid in sd:
                                        no+=1
                                if 'line://nv/chatMsg?chatId=' in b.contents.link:sdg = '{}'.format(b.contents.link)
                                else:sdg = '{}'.format(b.contents.text)
                                if no == 1:c+= '\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                                else:c+= '\n\n{}. 「 {} 」\n{}'.format(no,humanize.naturaltime(datetime.fromtimestamp(b.createdTime/1000)),sdg)
                            line.sendMention(msg.to,c,'',[sd])
    elif cmd == "get note":
                            try:
                                    data = line.getGroupPost(to)
                                    if data['result'] != []:
                                        try:
                                            no = 0
                                            b = []
                                            a = " 「 Groups 」\nType: Get Note"
                                            for i in data['result']['feeds']:
                                                b.append(i['post']['userInfo']['writerMid'])
                                                try:
                                                    for aasd in i['post']['contents']['textMeta']:b.append(aasd['mid'])
                                                except:pass
                                                no += 1
                                                gtime = i['post']['postInfo']['createdTime']
                                                try:g = i['post']['contents']['text'].replace('@','@!')
                                                except:g="None"
                                                if no == 1:sddd = '\n'
                                                else:sddd = '\n\n'
                                                a +="{}{}. Penulis : @!\nDescription: {}\nTotal Like: {}\nCreated at: {}\n".format(sddd,no,g,i['post']['postInfo']['likeCount'],humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                            a +="Status: Success Get "+str(data['result']['homeInfo']['postCount'])+" Note"
                                            line.sendMention(to,a,'',b)
                                        except Exception as e:
                                            return line.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                            except Exception as e:print(e)
    elif cmd.startswith("get note "):
                            try:
                                    data = line.getGroupPost(to)
                                    try:
                                        music = data['result']['feeds'][int(cmd.split(' ')[2]) - 1]
                                        b = [music['post']['userInfo']['writerMid']]
                                        try:
                                            for a in music['post']['contents']['textMeta']:b.append(a['mid'])
                                        except:pass
                                        try:
                                            g= "\n\nDescription:\n"+str(music['post']['contents']['text'].replace('@','@!'))
                                        except:
                                            g=""
                                        a="\n   Total Like: "+str(music['post']['postInfo']['likeCount'])
                                        a +="\n   Total Comment: "+str(music['post']['postInfo']['commentCount'])
                                        gtime = music['post']['postInfo']['createdTime']
                                        a +="\n   Created at: "+str(humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                        a += g
                                        zx = ""
                                        zxc = " 「 Groups 」\nType: Get Note\n   Penulis : @!"+a
                                        try:
                                            line.sendMention(to,zxc,'',b)
                                        except Exception as e:
                                            line.sendMessage(to, str(e))
                                        try:
                                            for c in music['post']['contents']['media']:
                                                params = {'userMid': line.getProfile().mid, 'oid': c['objectId']}
                                                s = line.server.urlEncode(line.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                                if 'PHOTO' in c['type']:
                                                    try:
                                                        line.sendMessage(to," 「 Note 」\nPlease wait, while send your picture...")
                                                        line.sendImageWithURL(to,s)
                                                    except:pass
                                                else:
                                                    pass
                                                if 'VIDEO' in c['type']:
                                                    try:
                                                        line.sendMessage(to," 「 Note 」\nPlease wait, while send your videos...")
                                                        data={
                                                        'type': 'video',
                                                        'originalContentUrl': s,
                                                        'previewImageUrl': "https://i.ibb.co/5RFj4NF/IMG-20200828-143935.png"
                                                         }
                                                        sendTemplate(to, data)
                                                    except:pass
                                                else:
                                                    pass
                                        except:
                                            pass
                                    except Exception as e:
                                        return line.sendMessage(to,"「 Auto Respond 」\n"+str(e))
                            except Exception as e:print(e)
    elif cmd.startswith("spamcall "):
                                if msg.toType == 2:
                                    sep = text.split(" ")
                                    strnum = text.replace(sep[0] + " ","")
                                    num = int(strnum)
                                    line.sendMessage(to, "Succesfully Spam Call to Group")
                                    for var in range(0,num):
                                       group = line.getGroup(to)
                                       members = [mem.mid for mem in group.members]
                                       line.acquireGroupCallRoute(to)
                                       time.sleep(0.5)
                                       line.inviteIntoGroupCall(to, contactIds=members)
def executeOp(op):
    try:
        print ('++ Operation : ( %i ) %s' % (op.type, OpType._VALUES_TO_NAMES[op.type].replace('_', ' ')))
        if op.type == 5:
           if settings['autoAdd']['status']:
#                 line.findAndAddContactsByMid(op.param1)
            if settings['autoAdd']['reply']:
                if '@!' not in settings['autoAdd']['message']:
                    line.sendMessage(op.param1, settings['autoAdd']['message'])
                else:
                    line.sendMentionV2(op.param1, settings['autoAdd']['message'], [op.param1])
        if op.type == 11 or op.type == 122:
            if op.param1 in settings["protectqr"]:
                try:
                    if line.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in settings["whitelist"]:
                            settings["blacklist"].append(op.param2)
                            line.reissueGroupTicket(op.param1)
                            X = line.getCompactGroup(op.param1)
                            X.preventedJoinByTicket = True
                            line.updateGroup(X)
                            line.kickoutFromGroup(op.param1,[op.param2])
                except:
                    pass
        if op.type == 13 or op.type == 124:
            if settings['autoJoin']['status'] and myMid in op.param3:
                line.acceptGroupInvitation(op.param1)
                if settings['autoJoin']['reply']:
                    if '@!' not in settings['autoJoin']['message']:
                        line.sendMessage(op.param1, settings['autoJoin']['message'])
                    else:
                        line.sendMentionV2(op.param1, settings['autoJoin']['message'], [op.param2])
        if op.type == 13 or op.type == 124:
            if op.param3 in myMid:
                if joinpurge["purgee"] == True:
                            line.acceptGroupInvitation(op.param1)
                            group = line.getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.members]
                            matched_list = []
                            imnoob = 'kickall.js gid={} token={}'.format(op.param1, line.authToken)
                            for tag in settings['blacklist']:
                                matched_list+=filter(lambda str: str == tag, gMembMids)
                            if matched_list == []:
                                line.kickoutFromGroup(op.param1,[tag])
                                return
                            for jj in matched_list:
                                imnoob += " uik={}".format(jj)
                            execute_js(imnoob)
            if op.param3 in settings["blacklist"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        anu = line.getCompactGroup(op.param1)
                        if anu.invitee is not None:
                            pipo = [a.mid for a in anu.invitee]
                            for target in pipo:
                                if target in op.param3:
                                    try:
                                        line.kickoutFromGroup(op.param1,[op.param2])
                                        line.cancelGroupInvitation(op.param1,[target])
                                    except:
                                        pass
                    except:pass
                else:pass
                if op.param2 not in settings["blacklist"]:
                    if op.param2 not in settings["whitelist"]:
                        settings['blacklist'].append(op.param2)
                    else:pass
                else:pass
            if op.param1 in settings["protectinvite"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        if op.param2 not in settings['blacklist']:
                            settings['blacklist'].append(op.param2)
                        else:pass
                        try:
                            line.kickoutFromGroup(op.param1,[op.param2])                                         
                        except:pass
                        mbul = line.getGroup(op.param1)
                        no = 0
                        for a in mbul.invitee:
                            if a.mid in op.param3:
                                if no > 10:pass
                                else:
                                    try:
                                        no = (no+1)
                                        line.cancelGroupInvitation(op.param1,[a.mid])
                                        time.sleep(0.04)
                                    except:pass
                        for b in mbul.members:
                            if b.mid in op.param3:
                                try:
                                    line.kickoutFromGroup(op.param1,[b.mid])
                                except:pass
                    except:pass
                else:pass
        if op.type == 15 or op.type == 128:
            if settings['greet']['leave']['status']:
                if '@!' not in settings['greet']['leave']['message']:
                    line.sendMessage(op.param1, settings['greet']['leave']['message'].format(name=line.getCompactGroup(op.param1).name))
                else:
                    line.sendMentionV2(op.param1, settings['greet']['leave']['message'].format(name=line.getCompactGroup(op.param1).name), [op.param2])
        if op.type == 17 or op.type == 130:
            if settings['greet']['join']['status']:
                if '@!' not in settings['greet']['join']['message']:
                    line.sendMessage(op.param1, settings['greet']['join']['message'].format(name=line.getCompactGroup(op.param1).name))
                else:
                    line.sendMentionV2(op.param1, settings['greet']['join']['message'].format(name=line.getCompactGroup(op.param1).name), [op.param2])
            if op.param2 in settings["blacklist"]:
                try:
                    group = line.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    line.kickoutFromGroup(op.param1,[op.param2])
                    line.updateGroup(group)
                    group.preventedJoinByTicket = True
                    line.updateGroup(group)
                except Exception as e:
                    group = line.getGroup(op.param1)
                    group.preventedJoinByTicket = True
                    line.kickoutFromGroup(op.param1,[op.param2])
                    line.updateGroup(group)
            if op.param1 in settings["protectjoin"]:
                if op.param2 not in settings["whitelist"]:
                    settings["blacklist"].append(op.param2)
                    try:
                        if op.param3 not in settings["blacklist"]:
                        	line.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
        if op.type == 19 or op.type == 133:
          if op.param3 in myMid:
            if op.param2 not in settings["blacklist"]:
                settings["blacklist"].append(op.param2)
                group = line.profile.mid
                nameGroup = line.getGroup(op.param1).name
                jam = pytz.timezone("Asia/Jakarta")
                jamSek = datetime.now(tz=jam)
                jamm = datetime.strftime(jamSek, '%d-%m-%Y')
                jammm = datetime.strftime(jamSek,'%H:%M:%S')
                contact = line.getContact(myMid)
                kiker = line.getContact(op.param2)
                res = "Type: Notifikasi Kick♪"
                res += "\n	 › In Group: {}".format(nameGroup)
                res += "\n	 › Date: {}".format(jamm)
                res += "\n	 › Time: {}".format(jammm)
                res += "\n	 › Victim : {}".format(contact.displayName)
                res += "\n	 › Kicker: {}".format(kiker.displayName)
                res += "\n	 › 👇Contact Kicker👇"
                line.sendMessage(group,res)
                line.sendContact(group, op.param2)
          if op.param3 in settings["whitelist"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param1 in settings["protectkick"]:
                if op.param2 not in settings["whitelist"]:
                    settings["blacklist"].append(op.param2)
                    line.kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass
        if op.type == 32 or op.type == 126:
          if op.param3 in settings["whitelist"]:
                if op.param2 not in settings["whitelist"]:
                    try:
                        line.findAndAddContactsByMid(op.param3)
                        line.kickoutFromGroup(op.param1,[op.param2])
                        line.inviteIntoGroup(op.param1,[op.param3])
                    except:pass
          if op.param1 in settings["protectcancel"]:
                if op.param2 not in settings["whitelist"]:
                    settings["blacklist"].append(op.param2)
                    line.kickoutFromGroup(op.param1,[op.param2])
        if op.type == 25 or op.type == 26:
            print ("++ Operation : ( [25:26]) AUTOLIKE MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != line.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
            if msg.contentType == 16:
            	if msg.toType in (2,1,0):
                    if settings['autokomen']['status']:
                        if msg.contentMetadata['serviceType'] in ['GB', 'NT', 'MH']:
                            if msg.contentMetadata['serviceType'] in ['GB', 'NT']:
                                contact = line.getContact(sender)
                                author = contact.displayName
                            else:
                                author = msg.contentMetadata['serviceName']
                            posturl = msg.contentMetadata['postEndUrl']
                            rep = posturl.replace("line://home/post?userMid=","")
                            sep = rep.split("&postId=")
                            line.createComment(sender, sep[1], settings['autokomen']['message'])
                    if settings['autolike']['status']:
                        if msg.contentMetadata['serviceType'] in ['GB', 'NT', 'MH']:
                            if msg.contentMetadata['serviceType'] in ['GB', 'NT']:
                                contact = line.getContact(sender)
                                author = contact.displayName
                            else:
                                author = msg.contentMetadata['serviceName']
                            posturl = msg.contentMetadata['postEndUrl']
                            TEMPELER(to,settings['autolike']['message'])
                            rep = posturl.replace("line://home/post?userMid=","")
                            sep = rep.split("&postId=")
                            line.likePost(sender, sep[1], 1001)
        if op.type == 22 or op.type == 24:
            if mckontol["mckontol"] == True:
                line.sendMessage(op.param1,"MC MC TAI ANJING")
                line.leaveRoom(op.param1)
        if op.type == 25:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            cmd      = command(text)
            setKey   = settings['setKey']['key'] if settings['setKey']['status'] else ''
            if text in tmp_text:
                return tmp_text.remove(text)
            if msg.contentType == 0:
                if '/ti/g/' in text and settings['autoJoin']['ticket']:
                    regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = regex.findall(text)
                    tickets = []
                    gids = line.getGroupIdsJoined()
                    for link in links:
                        if link not in tickets:
                            tickets.append(link)
                    for ticket in tickets:
                        try:
                            group = line.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            line.sendMessage(to, 'I\'m already on group ' + group.name)
                            continue
                        line.acceptGroupInvitationByTicket(group.id, ticket)
                        if settings['autoJoin']['reply']:
                            if '@!' not in settings['autoJoin']['message']:
                                line.sendMessage(to, settings['autoJoin']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoJoin']['message'], [sender])
                        line.sendMessage(to, 'Success join to group ' + group.name)
                try:
                    executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey)
                except TalkException as talk_error:
                    logError(talk_error)
                    if talk_error.code in [7, 8, 20]:
                        sys.exit(1)
                    line.sendMessage(to, 'Execute command error, ' + str(talk_error))
                    time.sleep(3)
                except Exception as error:
                    logError(error)
                    line.sendMessage(to, 'Execute command error, ' + str(error))
                    time.sleep(3)
            if flagPict["status"] == True:
                    try:
                        path = line.downloadObjectMsg(msg_id, saveAs="tmp/flag-{}.bin".format(myMid))
                        jdl = ""
                        for x in range(10):
                            a = random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890")
                            jdl += a
                        files = {'image': open(path, 'rb'), 'name': jdl}
                        link = "https://api.imgbb.com/1/upload?key=45bfda7c55c882fb106fc752b38f47e8"
                        r = requests.post(link, files=files).text
                        print(r)
                        url = json.loads(r)["data"]["url"]      
                        line.deleteFile("tmp/flag-{}.bin".format(myMid))
                        dataTemp["pict"] = url
                        flagPict["status"] = False
                        line.sendMessage(to, "Type: Change Wallpaper\n • Detail: Change Wallpaper Temp\n • Status: Succes..")                            
                    except:
                        pass
            elif msg.contentType == 1: # Content type is image
                if settings['changePictureProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/picture.jpg')
                    line.updateProfilePicture(path)
                    line.sendMessage(to, 'Success change picture profile')
                    settings['changePictureProfile'] = False
                elif settings['changeCoverProfile']:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/cover.jpg')
                    line.updateProfileCover(path)
                    line.sendMessage(to, 'Success change cover profile')
                    settings['changeCoverProfile'] = False
                elif to in settings['changeGroupPicture'] and msg.toType == 2:
                    path = line.downloadObjectMsg(msg_id, saveAs='tmp/grouppicture.jpg')
                    line.updateGroupPicture(to, path)
                    line.sendMessage(to, 'Success change group picture')
                    settings['changeGroupPicture'].remove(to)
            elif msg.contentType == 2: #content type video
                if settings["changevp"] == True:
                    contact = line.getProfile()
                    pict = "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                    path = line.downloadFileURL(pict)
                    path1 = line.downloadObjectMsg(msg_id)
                    settings["changevp"] = False
                    changevideopp(path, path1)
                    line.sendMessage(to, "Success change Video Profile")
            elif msg.contentType == 7: # Content type is sticker
                if settings['checkSticker']:
                    res = 'Sticker Info'
                    res += '\n Sticker ID : ' + msg.contentMetadata['STKID']
                    res += '\n Sticker Packages ID : ' + msg.contentMetadata['STKPKGID']
                    res += '\n Sticker Version : ' + msg.contentMetadata['STKVER']
                    res += '\n Sticker Link : line://shop/detail/' + msg.contentMetadata['STKPKGID']
                    line.sendMessage(to, parsingRes(res))
                if sygmude["cabutstk"] == True:
                    sygmude["cbtID"] = msg.contentMetadata['STKID']
                    sygmude["cbtVER"] = msg.contentMetadata['STKVER']
                    sygmude["cabsID"] = msg.contentMetadata['STKPKGID']
                    line.sendMessage(to, "Succes Add Leave Sticker \nSTKID : {}\nSTKVER : {}\nSTKPKGID : ".format(str(sygmude["cbtID"]), str(sygmude["cbtVER"]), str(sygmude["cabsID"])))
                    sygmude["cabutstk"] = False
                if sygmude["cmdfakemention"] == True:
                    sygmude["cmdID"] = msg.contentMetadata['STKID']
                    sygmude["cmdVER"] = msg.contentMetadata['STKVER']
                    sygmude["cmddID"] = msg.contentMetadata['STKPKGID']
                    line.sendMessage(to, "Succes Add Cmd Fake mention \nSTKID : {}\nSTKVER : {}\nSTKPKGID : ".format(str(sygmude["cmdID"]), str(sygmude["cmdVER"]), str(sygmude["cmddID"])))
                    sygmude["cmdfakemention"] = False
                if sygmude["addfakemention"] == True:
                    sygmude["fstkID"] = msg.contentMetadata['STKID']
                    sygmude["fstkVER"] = msg.contentMetadata['STKVER']
                    sygmude["fpkgID"] = msg.contentMetadata['STKPKGID']
                    line.sendMessage(to, "Succes Add Fake mention \nSTKID : {}\nSTKVER : {}\nSTKPKGID : ".format(str(sygmude["fstkID"]), str(sygmude["fstkVER"]), str(sygmude["fpkgID"])))
                    sygmude["addfakemention"] = False
                if sygmude["fakemention"] == True and sender == myMid:
                    if msg.contentMetadata['STKID'] == sygmude["fstkID"] and msg.contentMetadata['STKVER'] == sygmude["fstkVER"] and msg.contentMetadata['STKPKGID'] == sygmude["fpkgID"]:
                        stk_id = sygmude["fstkID"]
                        stk_ver = sygmude["fstkVER"]
                        pkg_id = sygmude["fpkgID"]
                        mids = []
                        G = line.getGroup(to)
                        mems = [a.mid for a in G.members]
                        if mems != []:
                            for t in mems:
                                mids.append(t)
                        if myMid in mems:
                            mids.remove(myMid)
                        target = len(mids)//140+1
                        text = " << fake mention >>"
                        mention = "@iyusNiBous\n"
                        no = 0
                        for x in range(target):
                            mentioness = []
                            for mid in mids[x*140:(x+1)*140]:
                                no += 1
                                text += "    • . %i %s"%(no, mention)
                                slen = len(text) - 12
                                elen = len(text) + 3
                                mentioness.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
                            if mentioness:
                                try:
                                    msg.contentMetadata["STKID"] = int(stk_id)+1
                                    msg.contentMetadata['STKVER'] = stk_ver
                                    msg.contentMetadata['STKPKGID'] = pkg_id
                                    stkid = str(msg.contentMetadata["STKID"])
                                    sver = msg.contentMetadata['STKVER']
                                    spkg = msg.contentMetadata['STKPKGID']
                                    line.sendMessage2(to, text, {'MENTION': json.dumps({'MENTIONEES': mentioness}),'STKID': stkid, 'STKVER': sver, 'STKPKGID': spkg}, 7)
                                except Exception as e:print(e)
                if sygmude["fakemention"] == True and sender == myMid:
                    if msg.contentMetadata['STKID'] == sygmude["cmdID"] and msg.contentMetadata['STKVER'] == sygmude["cmdVER"] and msg.contentMetadata['STKPKGID'] == sygmude["cmddID"]:
                        stk_id = sygmude["fstkID"]
                        stk_ver = sygmude["fstkVER"]
                        pkg_id = sygmude["fpkgID"]
                        mids = []
                        G = line.getGroup(to)
                        mems = [a.mid for a in G.members]
                        if mems != []:
                            for t in mems:
                                mids.append(t)
                        if myMid in mems:
                            mids.remove(myMid)
                        target = len(mids)//140+1
                        text = " << fake mention >>"
                        mention = "@iyusNiBous\n"
                        no = 0
                        for x in range(target):
                            mentioness = []
                            for mid in mids[x*140:(x+1)*140]:
                                no += 1
                                text += "    • . %i %s"%(no, mention)
                                slen = len(text) - 12
                                elen = len(text) + 3
                                mentioness.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
                            if mentioness:
                                try:
                                    msg.contentMetadata["STKID"] = int(stk_id)+1
                                    msg.contentMetadata['STKVER'] = stk_ver
                                    msg.contentMetadata['STKPKGID'] = pkg_id
                                    stkid = str(msg.contentMetadata["STKID"])
                                    sver = msg.contentMetadata['STKVER']
                                    spkg = msg.contentMetadata['STKPKGID']
                                    line.sendMessage2(to, text, {'MENTION': json.dumps({'MENTIONEES': mentioness}),'STKID': stkid, 'STKVER': sver, 'STKPKGID': spkg}, 7)
                                except Exception as e:print(e)
                if nukemode["kickstk"] == True:
                    nukemode["kickID"] = msg.contentMetadata['STKID']
                    nukemode["kickVER"] = msg.contentMetadata['STKVER']
                    nukemode["kckgID"] = msg.contentMetadata['STKPKGID']
                    line.sendMessage(to, "Succes Add Kick Reply Sticker \nSTKID : {}\nSTKVER : {}\nSTKPKGID : ".format(str(nukemode["kickID"]), str(nukemode["kickVER"]), str(nukemode["kckgID"])))
                    nukemode["kickstk"] = False
                if nukemode["invitestk"] == True:
                    nukemode["invID"] = msg.contentMetadata['STKID']
                    nukemode["invVER"] = msg.contentMetadata['STKVER']
                    nukemode["invtID"] = msg.contentMetadata['STKPKGID']
                    line.sendMessage(to, "Succes Add Invite Reply Sticker \nSTKID : {}\nSTKVER : {}\nSTKPKGID : ".format(str(nukemode["invID"]), str(nukemode["invVER"]), str(nukemode["invtID"])))
                    nukemode["invitestk"] = False
                if msg.contentMetadata['STKID'] == nukemode["kickID"] and msg.contentMetadata['STKVER'] == nukemode["kickVER"] and msg.contentMetadata['STKPKGID'] == nukemode["kckgID"]:
                    if msg.toType == 2:
                        if msg.relatedMessageId is not None:
                            aa = line.getRecentMessagesV2(to, 1001)
                            for bb in aa:
                                if bb.id in msg.relatedMessageId:
                                    line.kickoutFromGroup(to, [bb._from])
                                    break
                        else:
                            line.sendReplyMessage(msg.id,to, 'you must reply the message')
                if msg.contentMetadata['STKID'] == nukemode["invID"] and msg.contentMetadata['STKVER'] == nukemode["invVER"] and msg.contentMetadata['STKPKGID'] == nukemode["invtID"]:
                    if msg.toType == 2:
                        if msg.relatedMessageId is not None:
                            aa = line.getRecentMessagesV2(to, 1001)
                            for bb in aa:
                                if bb.id in msg.relatedMessageId:
                                    line.findAndAddContactsByMid(bb._from)
                                    line.inviteIntoGroup(to, [bb._from])
                                    break
                        else:
                            line.sendReplyMessage(msg.id,to, 'you must reply the message')
                if sygmude["leavestk"] == True and sender == myMid:
                    if msg.contentMetadata['STKID'] == sygmude["cbtID"] and msg.contentMetadata['STKVER'] == sygmude["cbtVER"] and msg.contentMetadata['STKPKGID'] == sygmude["cabsID"]:
                        if msg.toType == 2:
                            group = line.getGroup(to)
                            line.leaveGroup(to)
                        else:
                            TEMPELER(to,"Please activated this command")
            elif msg.contentType == 13: # Content type is contact
                if settings['checkContact']:
                    mid = msg.contentMetadata['mid']
                    try:
                        contact = line.getContact(mid)
                    except:
                        return line.sendMessage(to, 'Failed get details contact with mid ' + mid)
                    res = 'Details Contact'
                    res += '\n MID : ' + mid
                    res += '\n Display Name : ' + str(contact.displayName)
                    if contact.displayNameOverridden: res += '\n Display Name Overridden : ' + str(contact.displayNameOverridden)
                    res += '\n Status Message : ' + str(contact.statusMessage)
                    if contact.pictureStatus:
                        line.sendImageWithURL(to, 'http://dl.profile.line-cdn.net/' + contact.pictureStatus)
                    cover = line.getProfileCoverURL(mid)
                    line.sendImageWithURL(to, str(cover))
                    line.sendMessage(to, parsingRes(res))
                if settings['detectcontact']:
                  if msg._from in myMid:
                    mid = msg.contentMetadata['mid']
                    try:
                        contact = line.getContact(mid)
                    except:
                        return line.sendMessage(to, 'Failed get detected contact with mid ' + mid)
                    contact = []
                    if len(contact) >= 3:
                        try:
                            G = line.getGroup(msg.to)
                            line.sendMessage(msg.to, "Dasar Kicker")
                            line.kickoutFromGroup(msg.to,[sender])
                        except:pass
                if settings['invitekontak']:
                    mid = msg.contentMetadata['mid']
                    try:
                        G = line.getGroup(to)
                        contact = line.getContact(mid)
                        line.findAndAddContactsByMid(mid)
                        line.inviteIntoGroup(to, [mid])
                        settings["invitekontak"] = False
                    except:
                        return line.sendMessage(to, 'Failed Invite contact with mid ' + mid)
                    res = 'Type: Invite Contact♪\n	 › Detail: Invite Via Contact\n	 › Status: Success Invite Contact'
                    if settings["temp"] == True:
                        SendTemp3(to,res)
                    else:
                        if settings["footer"] == True:
                            sendFooter(to,res)
                        else:
                            line.sendReplyMessage(msg.id, to,res)
                if msg._from in myMid:
                    if wait["wblacklist"] == True:
                        if msg.contentMetadata["mid"] in settings["blacklist"]:
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Blacklist 」\nContact Already In Blacklist -_-")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Blacklist 」\nContact Already In Blacklist -_-")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nContact Already In Blacklist -_-")
                        else:
                            settings["blacklist"].append(msg.contentMetadata["mid"])
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Blacklist 」\nSuccess Add Contact To Blacklist ^_^")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Blacklist 」\nSuccess Add Contact To Blacklist ^_^")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nSuccess Add Contact To Blacklist ^_^")
                    if wait["dblacklist"] == True:
                        if msg.contentMetadata["mid"] in settings["blacklist"]:
                            settings["blacklist"].remove(msg.contentMetadata["mid"])
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Blacklist 」\nSuccess Delete Contact From Blacklist ^_^")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Blacklist 」\nSuccess Delete Contact From Blacklist ^_^")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nSuccess Delete Contact From Blacklist ^_^")
                        else:
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Blacklist 」\nContact Not In Blacklist -_-")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Blacklist 」\nContact Not In Blacklist -_-")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Blacklist 」\nContact Not In Blacklist -_-")
                    if wait["wwhitelist"] == True:
                        if msg.contentMetadata["mid"] in settings["whitelist"]:
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Whitelist 」\nContact Already In Whitelist -_-")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Whitelist 」\nContact Already In Whitelist -_-")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nContact Already In Whitelist -_-")
                        else:
                            settings["whitelist"].append(msg.contentMetadata["mid"])
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Whitelist 」\nSuccess Add Contact To Whitelist ^_^")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Whitelist 」\nSuccess Add Contact To Whitelist ^_^")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nSuccess Add Contact To Whitelist ^_^")
                    if wait["dwhitelist"] == True:
                        if msg.contentMetadata["mid"] in settings["whitelist"]:
                            settings["whitelist"].remove(msg.contentMetadata["mid"])
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Whitelist 」\nSuccess Delete Contact From Whitelist ^_^")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Whitelist 」\nSuccess Delete Contact From Whitelist ^_^")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nSuccess Delete Contact From Whitelist ^_^")
                        else:
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Whitelist 」\nContact Not In Whitelist -_-")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Whitelist 」\nContact Not In Whitelist -_-")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Whitelist 」\nContact Not In Whitelist -_-")
                    if wait["wteam"] == True:
                        if msg.contentMetadata["mid"] in settings["team"]:
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Team 」\nContact Already In Team -_-")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Team 」\nContact Already In Team -_-")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Team 」\nContact Already In Team -_-")
                        else:
                            settings["team"].append(msg.contentMetadata["mid"])
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Team 」\nSuccess Add Contact To Team ^_^")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Team 」\nSuccess Add Contact To Team ^_^")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Team 」\nSuccess Add Contact To Team ^_^")
                    if wait["dteam"] == True:
                        if msg.contentMetadata["mid"] in settings["team"]:
                            settings["team"].remove(msg.contentMetadata["mid"])
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Team 」\nSuccess Delete Contact From Team ^_^")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Team 」\nSuccess Delete Contact From Team ^_^")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Team 」\nSuccess Delete Contact From Team ^_^")
                        else:
                            if settings["temp"] == True:
                                SendTemp3(to,"「 Team 」\nContact Not In Team -_-")
                            else:
                                if settings["footer"] == True:
                                    sendFooter(to,"「 Team 」\nContact Not In Team -_-")
                                else:
                                    line.sendReplyMessage(msg.id, to,"「 Team 」\nContact Not In Team -_-")
                if mmin["addfakementionc"] == True:
                    mmin["fakementionc"] = msg.contentMetadata["mid"]
                    line.sendMessage(to,"Contact successfully added to Faketag Contact")
                    mmin["addfakementionc"] = False
            elif msg.contentType == 14: #Type file
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"file":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 16: # Content type is album/note
                if settings['checkPost']:
                    if msg.contentMetadata['serviceType'] in ['GB', 'NT', 'MH']:
                        if msg.contentMetadata['serviceType'] in ['GB', 'NT']:
                            contact = line.getContact(sender)
                            author = contact.displayName
                        else:
                            author = msg.contentMetadata['serviceName']
                        posturl = msg.contentMetadata['postEndUrl']
                        res = 'Details Post'
                        res += '\n Creator : @!'
                        res += '\n Post Link : ' + posturl
                        sendMention(to,res,[contact.mid])
        elif op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()
            if settings['autoRead']:
                line.sendChatChecked(to, msg_id)
            if msg.contentType == 0:
                if msg.toType != 0 and msg.toType == 2:
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        names = re.findall(r'@(\w+)', text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                            if myMid in mention["M"]:
                                if line.getProfile().mid in mention["M"]:
                                    if to not in tagme['ROM']:
                                        tagme['ROM'][to] = {}
                                    if sender not in tagme['ROM'][to]:
                                        tagme['ROM'][to][sender] = {}
                                    if 'msg.id' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['msg.id'] = []
                                    if 'waktu' not in tagme['ROM'][to][sender]:
                                        tagme['ROM'][to][sender]['waktu'] = []
                                    tagme['ROM'][to][sender]['msg.id'].append(msg.id)
                                    tagme['ROM'][to][sender]['waktu'].append(msg.createdTime)
                    if 'MENTION' in msg.contentMetadata.keys() != None:
                      if wait["Mentiongift"] == True:
                        name = re.findall(r'@(\w+)', msg.text)
                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = mention['MENTIONEES']
                        for mention in mentionees:
                             if mention ['M'] in myMid:
                                idth = ["a0768339-c2d3-4189-9653-2909e9bb6f58","ec4a14ea-7437-407b-aee7-96b1cbbc1b4b","f35bd31f-5ec7-4b2f-b659-92adf5e3d151","ba1d5150-3b5f-4768-9197-01a3f971aa34","2b4ccc45-7309-47fe-a006-1a1edb846ddb","168d03c3-dbc2-456f-b982-3d6f85f52af2","d4f09a5f-29df-48ac-bca6-a204121ea165","517174f2-1545-43b9-a28f-5777154045a6","762ecc71-7f71-4900-91c9-4b3f213d8b26","2df50b22-112d-4f21-b856-f88df2193f9e"]
                                plihth = random.choice(idth)
                                jenis = ["5","6","7","8"]
                                plihjenis = random.choice(jenis)
                                line.sendMessage(msg.to, "Yang suka ngetag minta di gift yaa!?\nCek di chat, udah aku gift tuh...")
                                line.sendMessage(msg._from, None, contentMetadata={"PRDID":plihth,"PRDTYPE":"THEME","MSGTPL":plihjenis}, contentType=9)
                                break
                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                        if msg._from not in myMid:
                            if settings["mentionkick"] == True:
                                name = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    if myMid in mention["M"]:
                                        if line.getProfile().mid in mention["M"]:
                                            sendMention(to,"siapa lu ? @!", [msg._from])
                                            line.kickoutFromGroup(msg.to, [msg._from])
                                            break
                if settings["unsendMessage"]:
                	try:
                	    bool_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 1: # Content type is image
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"image":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 2: #content type video
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"video":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 3:
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"audio":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            if msg.contentType == 6:
                  if wait["notifcall"] == True:
                    if msg._from not in myMid:
                        try:
                            contact = line.getContact(sender)
                            group = line.getGroup(msg.to)
                            cover = line.getProfileCoverURL(sender)
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            if msg.toType == 2:
                                b = msg.contentMetadata['GC_EVT_TYPE']
                                c = msg.contentMetadata["GC_MEDIA_TYPE"]
                                if c == 'AUDIO' and b == "S":
                                    arg = "• ᴄᴀʟʟ ᴀᴜᴅɪᴏ"
                                    arg += "\n• ᴛʏᴘᴇ {} ᴄᴀʟʟ".format(c) 
                                    arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                    arg += "\n• ɢᴄ: {}".format(str(group.name))
                                    arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                    arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                    arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    line.sendMessage(msg.to,arg)
                                if c == 'VIDEO' and b == "S":
                                    arg = "• ᴄᴀʟʟ ᴠɪᴅᴇᴏ"
                                    arg += "\n• ᴛʏᴘᴇ {} ᴄᴀʟʟ".format(c) 
                                    arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                    arg += "\n• ɢᴄ: {}".format(str(group.name))
                                    arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                    arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                    arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    line.sendMessage(msg.to,arg)
                                if c == 'LIVE' and b == "S":
                                    arg = "• ᴄᴀʟʟ ʟɪᴠᴇ"
                                    arg += "\n• ᴛʏᴘᴇ {} ᴄᴀʟʟ".format(c) 
                                    arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                    arg += "\n• ɢᴄ: {}".format(str(group.name))
                                    arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                    arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                    arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                    line.sendMessage(msg.to,arg)
                                else:
                                    mills = int(msg.contentMetadata["DURATION"])
                                    seconds = (mills/1000)%60
                                    if c == "AUDIO" and b == "E":
                                        arg = "• ᴄᴀʟʟ ᴀᴜᴅɪᴏ"
                                        arg += "\n• ᴅɪᴀᴋʜɪʀɪ {} ᴄᴀʟʟ".format(c)
                                        arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                        arg += "\n• ɢᴄ: {}".format(str(group.name))
                                        arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                        arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                        arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                        arg += "\n• ᴅʀ: {}".format(seconds)
                                        line.sendMessage(msg.to,arg)
                                    if c == "VIDEO" and b == "E":
                                        arg = "• ᴄᴀʟʟ ᴠɪᴅᴇᴏ"
                                        arg += "\n• ᴅɪᴀᴋʜɪʀɪ {} ᴄᴀʟʟ".format(c)
                                        arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                        arg += "\n• ɢᴄ: {}".format(str(group.name))
                                        arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                        arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                        arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                        arg += "\n• ᴅʀ: {}".format(seconds)
                                        line.sendMessage(msg.to,arg)
                                    if c == "LIVE" and b == "E":
                                        arg = "• ᴄᴀʟʟ ʟɪᴠᴇ"
                                        arg += "\n• ᴅɪᴀᴋʜɪʀɪ {} ᴄᴀʟʟ".format(c)
                                        arg += "\n• ɴᴍ: {}".format(str(contact.displayName)) 
                                        arg += "\n• ɢᴄ: {}".format(str(group.name))
                                        arg += "\n• ʜʀ: {}".format(timeNow.strftime('%A'))
                                        arg += "\n• ᴊᴍ: {}".format(datetime.strftime(timeNow,'%H:%M:%S'))
                                        arg += "\n• ᴛɢ: {}".format(datetime.strftime(timeNow,'%d-%m-%Y'))
                                        arg += "\n• ᴅʀ: {}".format(seconds)
                                        line.sendMessage(msg.to,arg)
                        except Exception as error:
                            print (error)
            elif msg.contentType == 7: # Content type is sticker
                if settings["unsendMessage"]:
                	try:
                	    sticker = msg.contentMetadata["STKID"]
                	    link = "http://dl.stickershop.line.naver.jp/stickershop/v1/sticker/{}/android/sticker.png".format(sticker)
                	    bool_dict[msg.id] = {"from":msg._from,"sticker":link,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 13: # Content type is contact
                if settings["unsendMessage"]:
                	try:
                	    mid = msg.contentMetadata["mid"]
                	    bool_dict[msg.id] = {"from":msg._from,"mid":mid,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 14: #Type file
                if settings["unsendMessage"]:
                	try:
                	    path = line.downloadObjectMsg(msg_id)
                	    bool_dict[msg.id] = {"from":msg._from,"file":path,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            elif msg.contentType == 16:
                    if wait["Timeline"] == True:
                            ret_ = "「 ᴅᴇᴛᴀɪʟ ᴘᴏsᴛɪɴɢᴀɴ 」"
                            if msg.contentMetadata["serviceType"] == "GB":
                                contact = line.getContact(sender)
                                auth = "\n• ˢᵏℹ༓ᴘᴇɴᴜʟɪs : {}".format(str(contact.displayName))
                            else:
                                auth = "\n• ˢᵏℹ ༓ᴘᴇɴᴜʟɪs : {}".format(str(msg.contentMetadata["serviceName"]))
                            ret_ += auth
                            if "stickerId" in msg.contentMetadata:
                                stck = "\n• ˢᵏℹ༓sᴛɪᴄᴋᴇʀ : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                ret_ += stck
                            if "mediaOid" in msg.contentMetadata:
                                object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                if msg.contentMetadata["mediaType"] == "V":
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• ˢᵏℹ༓ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        murl = "\n• ˢᵏℹ༓Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• ˢᵏℹ༓Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        murl = "\n• ˢᵏℹ༓Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                    ret_ += murl
                                else:
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        ourl = "\n• ˢᵏℹ༓Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                    else:
                                        ourl = "\n• ˢᵏℹ༓Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                ret_ += ourl
                            if "text" in msg.contentMetadata:
                                text = "\n• ˢᵏℹ༓Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                purl = "\n• ˢᵏℹ༓Post URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += purl
                                ret_ += text
                                url = msg.contentMetadata['postEndUrl']
                            line.sendMessage(to, str(ret_))
                            line.likePost(purl[25:58], purl[66:], likeType=1005)
                            line.createComment(purl[25:58], purl[66:], wait["comment"])
            elif msg.contentType == 15: #Type location
                if settings["unsendMessage"]:
                	try:
                	    if msg.location != None:
                	        bool_dict[msg.id] = {"location":msg.location,"from":msg._from,"createdTime":msg.createdTime}
                	    else:
                	        bool_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
                if '/ti/g/' in text and settings['autoJoin']['ticket']:
                    regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = regex.findall(text)
                    tickets = []
                    gids = line.getGroupIdsJoined()
                    for link in links:
                        if link not in tickets:
                            tickets.append(link)
                    for ticket in tickets:
                        try:
                            group = line.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            line.sendMessage(to, 'I\'m already on group ' + group.name)
                            continue
                        line.acceptGroupInvitationByTicket(group.id, ticket)
                        if settings['autoJoin']['reply']:
                            if '@!' not in settings['autoJoin']['message']:
                                line.sendMessage(to, settings['autoJoin']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoJoin']['message'], [sender])
                        line.sendMessage(to, 'Success join to group ' + group.name)
            if "https://vt.tiktok.com" in msg.text.lower():
                            if seni["dtiktok"] == True:
                                nm = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                                nm1 = re.findall(nm, text)
                                nm2 = []
                                for nm3 in nm1:
                                    if nm3 not in nm2:
                                        nm2.append(nm3)
                                for nm4 in nm2:
                                    nm5 = nm4
                                    try:
                                        api = BEAPI('iyus1414')
                                        res = api.tiktokPost(nm5)
                                        try:
                                            line.sendVideoWithURL(to, res['result']['aweme_detail']['video']['play_addr_h264']['url_list'][0])
                                        except:
                                            line.sendVideoWithURL(to, res['result']['aweme_detail']['video']['play_addr']['url_list'][0])
                                    except Exception as e:
                                        line.sendMessage(to, "{}".format(e))
            if "https://www.instagram.com" in msg.text.lower():
                            if seni["dinsta"] == True:
                                nm = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                                nm1 = re.findall(nm, text)
                                nm2 = []
                                for nm3 in nm1:
                                    if nm3 not in nm2:
                                        nm2.append(nm3)
                                for nm4 in nm2:
                                    nm5 = nm4
                                    try:
                                        api = BEAPI('iyus1414')
                                        res = api.instaPost(nm5)
                                        if 'True' in str(res['result']['media'][0]['is_video']):
                                            line.sendVideoWithURL(to, res['result']['media'][0]['video'])
                                        else:
                                            line.sendImageWithURL(to, res['result']['media'][0]['img'])
                                    except Exception as e:
                                        TEMPELER(to, "{}".format(e))
            if msg.contentType == 0: # Content type is text
                if settings['mimic']['status']:
                    if sender in settings['mimic']['target'] and settings['mimic']['target'][sender]:
                        try:
                            line.sendMessage(to, text, msg.contentMetadata)
                            tmp_text.append(text)
                        except:
                            pass
                if msg._from not in myMid:
                  if apalo["talkban"] == True:
                    if msg._from in apalo["tban"]:
                        try:
                            line.kickoutFromGroup(to, [msg._from])
                        except:
                            try:
                                line.kickoutFromGroup(to, [msg._from])
                            except:
                                line.kickoutFromGroup(to, [msg._from])
                if settings['autoRespondMention']['status']:
                    if msg.toType in [1, 2] and 'MENTION' in msg.contentMetadata.keys() and sender != myMid and msg.contentType not in [6, 7, 9]:
                        mentions = ast.literal_eval(msg.contentMetadata['MENTION'])
                        mentionees = [mention['M'] for mention in mentions['MENTIONEES']]
                        if myMid in mentionees:
                            if line.getProfile().displayName in text:
                                if '@!' not in settings['autoRespondMention']['message']:
                                    line.sendMessage(to, settings['autoRespondMention']['message'])
                                else:
                                    line.sendMentionV2(to, settings['autoRespondMention']['message'], [sender])
                if settings['autoRespond']['status']:
                    if msg.toType == 0:
                        contact = line.getContact(sender)
                        if contact.attributes != 32 and 'MENTION' not in msg.contentMetadata.keys():
                            if '@!' not in settings['autoRespond']['message']:
                                line.sendMessage(to, settings['autoRespond']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoRespond']['message'], [sender])
            elif msg.contentType == 15: #Type location
                if settings["unsendMessage"]:
                	try:
                	    if msg.location != None:
                	        bool_dict[msg.id] = {"location":msg.location,"from":msg._from,"createdTime":msg.createdTime}
                	    else:
                	        bool_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                	except Exception as e:
                	    print (e)
            try:
                Name = line.getContact(msg._from).mid
                group = line.getGroup(msg.to).name
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                hr = timeNow.strftime("%A")
                bln = timeNow.strftime("%m")
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): bln = bulan[k-1]
                readTime = timeNow.strftime('%H.%M')
                readTime2 = hr
                readTime3 = timeNow.strftime('%d') + "-" + bln + "-" + timeNow.strftime('%Y')
                lastseen["username"][Name] = "was lastseen\nin group ' " + group + " '\nat time " + readTime + " WIB\non " + readTime2 + ", " + readTime3
                lastseen['find'][msg._from] = True
            except:
                pass
        if op.type == 55:
            if op.param2 in settings["blacklist"]:
                if joinpurge["purgebl"] == True:
                    if op.param2 not in settings["whitelist"]:
                        line.kickoutFromGroup(op.param1,[op.param2])
        if op.type == 55:
            if op.param1 in lurking:
                if lurking[op.param1]['status'] and op.param2 not in lurking[op.param1]['members']:
                    lurking[op.param1]['members'].append(op.param2)
                    if lurking[op.param1]['reply']['status']:
                        if '@!' not in lurking[op.param1]['reply']['message']:
                            line.sendMessage(op.param1, lurking[op.param1]['reply']['message'])
                        else:
                            line.sendMentionV2(op.param1, lurking[op.param1]['reply']['message'], [op.param2])
            try:
                Name = line.getContact(op.param2).mid
                group = line.getGroup(op.param1).name
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                hr = timeNow.strftime("%A")
                bln = timeNow.strftime("%m")
                for i in range(len(day)):
                    if hr == day[i]: hasil = hari[i]
                for k in range(0, len(bulan)):
                    if bln == str(k): bln = bulan[k-1]
                readTime = timeNow.strftime('%H.%M')
                readTime2 = hr
                readTime3 = timeNow.strftime('%d') + "-" + bln + "-" + timeNow.strftime('%Y')
                lastseen["username"][Name] = "was lastseen\nin group ' " + group + " '\nat time " + readTime + " WIB\non " + readTime2 + ", " + readTime3
                lastseen['find'][op.param2] = True

                if cctv['cyduk'][op.param1]==True:
                    if op.param1 in cctv['point']:
                        pelaku = op.param2
                        kontak = line.getContact(op.param2)
                        text = settings["defaultReplyReader"]
                        Name = line.getContact(op.param2).displayName
                        if Name in cctv['sidermem'][op.param1]:
                            pass
                        else:
                                cctv['sidermem'][op.param1] += "\n> " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        line.sendMessageMusic(op.param1, kontak.displayName, 'sider puskun aja😜', 'line.me/ti/p/~mdz-', "https://obs.line-apps.com/os/p/{}".format(str(kontak.mid)))
                                        #sendMention(op.param1, "Kak @! jelek, sider mulu",[op.param2])
                                        #line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + line.getContact(op.param2).picturePath)
                                        #sendReader(op.param1,pelaku,'Read')
                                    else:
                                        line.sendMessageMusic(op.param1, kontak.displayName, 'sider jomblo ya😜', 'line.me/ti/p/~mdz-', "https://obs.line-apps.com/os/p/{}".format(str(kontak.mid)))
                                        #sendMention(op.param1, "Kak @! sider mulu, jomblo ya ka?",[op.param2])
                                        #line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + line.getContact(op.param2).picturePath)
                                        #sendReader(op.param1,pelaku,'Read')
                                else:
                                    line.sendMessageMusic(op.param1, kontak.displayName, 'jadi sider biar apa😒', 'line.me/ti/p/~mdz-', "https://obs.line-apps.com/os/p/{}".format(str(kontak.mid)))
                                    #sendMention(op.param1, "Kak @! Jangan Sider dong",[op.param2])
                                    #line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + line.getContact(op.param2).picturePath)
                                    #sendReader(op.param1,pelaku,'Read')
                    else:
                        pass
                else:
                    pass
            except:
                pass
        if op.type == 65:
            if settings["unsendMessage"]:
                trop = op.param1
                msg_id = op.param2
                if msg_id in bool_dict:
                    if "text" in bool_dict[msg_id]:
                        trops = line.getContact(bool_dict[msg_id]["from"])
                        tz = pytz.timezone("Asia/Jakarta")
                        timeNow = datetime.now(tz=tz)
                        tro_ = "# Unsend Message"
                        tro_ += "\nSender : @!"
                        tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                        tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                        tro_ += "\nType : Text"
                        tro_ += "\nText : {}".format(bool_dict[msg_id]["text"])
                        line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                        del bool_dict[msg_id]
                    else:
                        if "image" in bool_dict[msg_id]:
                            trops = line.getContact(bool_dict[msg_id]["from"])
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            tro_ = "# Unsend Message"
                            tro_ += "\nSender : @!"
                            tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                            tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                            tro_ += "\nType : Image"
                            line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                            line.sendImage(trop, bool_dict[msg_id]["image"])
                            del bool_dict[msg_id]
                        else:
                            if "video" in bool_dict[msg_id]:
                                trops = line.getContact(bool_dict[msg_id]["from"])
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                tro_ = "# Unsend Message"
                                tro_ += "\nSender : @!"
                                tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                tro_ += "\nType : Video"
                                line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                line.sendVideo(trop, bool_dict[msg_id]["video"])
                                del bool_dict[msg_id]
                            else:
                                if "audio" in bool_dict[msg_id]:
                                        trops = line.getContact(bool_dict[msg_id]["from"])
                                        tz = pytz.timezone("Asia/Jakarta")
                                        timeNow = datetime.now(tz=tz)
                                        tro_ = "# Unsend Message"
                                        tro_ += "\nSender : @!"
                                        tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                        tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                        tro_ += "\nType : Audio"
                                        line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                        line.sendAudio(trop, bool_dict[msg_id]["audio"])
                                        del bool_dict[msg_id]
                                else:
                                    if "sticker" in bool_dict[msg_id]:
                                            trops = line.getContact(bool_dict[msg_id]["from"])
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            tro_ = "# Unsend Message"
                                            tro_ += "\nSender : @!"
                                            tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                            tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                            tro_ += "\nType : Sticker"
                                            line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                            line.sendImageWithURL(trop, bool_dict[msg_id]["sticker"])
                                            del bool_dict[msg_id]
                                    else:
                                        if "mid" in bool_dict[msg_id]:
                                                trops = line.getContact(bool_dict[msg_id]["from"])
                                                tro_ = "# Unsend Message"
                                                tro_ += "\nSender : @!"
                                                tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                                tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                                tro_ += "\nType : Contact"
                                                line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                                line.sendContact(trop, bool_dict[msg_id]["mid"])
                                                del bool_dict[msg_id]
                                        else:
                                            if "location" in bool_dict[msg_id]:
                                                    trops = line.getContact(bool_dict[msg_id]["from"])
                                                    tro_ = "# Unsend Message"
                                                    tro_ += "\nSender : @!"
                                                    #tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                                    #tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                                    tro_ += "\nType : Location"
                                                    line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                                    line.sendLocation(trop, bool_dict[msg_id]["location"])
                                                    del bool_dict[msg_id]
                                            else:
                                                if "file" in bool_dict[msg_id]:
                                                        trops = line.getContact(bool_dict[msg_id]["from"])
                                                        tro_ = "# Unsend Message"
                                                        tro_ += "\nSender : @!"
                                                        tro_ += "\nTanggal : {}".format(str(datetime.strftime(timeNow,'%d-%m-%Y')))
                                                        tro_ += "\nJam : {}".format(str(datetime.strftime(timeNow,'%H:%M:%S')))
                                                        tro_ += "\nType : File"
                                                        line.sendReplyMentionV2(msg_id, trop, tro_,[trops.mid])
                                                        line.sendFile(trop, bool_dict[msg_id]["file"])
                                                        del bool_dict[msg_id]
    except TalkException as talk_error:
        logError(talk_error)
        if talk_error.code in [7, 8, 20]:
            sys.exit(1)
    except KeyboardInterrupt:
        sys.exit('##---- KEYBOARD INTERRUPT -----##')
    except Exception as error:
        logError(error)
def runningProgram():
    if settings['restartPoint'] is not None:
        try:
            TEMPELER(settings['restartPoint'], 'Bot can operate again ♪')
        except TalkException:
            pass
        settings['restartPoint'] = None
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
        except TalkException as talk_error:
            logError(talk_error)
            if talk_error.code in [7, 8, 20]:
                sys.exit(1)
            continue
        except KeyboardInterrupt:
            sys.exit('##---- KEYBOARD INTERRUPT -----##')
        except Exception as error:
            logError(error)
            continue
        if ops:
            for op in ops:
                executeOp(op)
                oepoll.setRevision(op.revision)
if __name__ == '__main__':
    print ('##---- RUNNING PROGRAM -----##')
    runningProgram()
